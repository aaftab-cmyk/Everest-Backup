// note: avaliableStatus is used for validation if record is not deleted tell them to dalete the recor



if (window.innerWidth < 900) {
  console.log(window.innerWidth);
  $('.test').removeClass('col-md-2').addClass('col-md-3');
}
else {
  $('.test').removeClass('col-md-3').addClass('col-md-2');
}

$("#Approve").css("display", "none");
//$("#Submit").css("display", "none");
Vue.component('v-select', VueSelect.VueSelect);
var isMobile = window.orientation > -1;
var Device = isMobile ? 'Mobile' : 'Not mobile';

$("#mobile").css("display", "none");
//$("#ORCHide").css("display","none");
 
if (Device == 'Mobile') {
  console.log("mobile");
  $(".web").css("display", "none");
  $("#mobile").css("display", "block");
}
var conn_name = "modulesall";
// zoho embedded app
var productMaster = {};
var rowId = 1;
var vm = new Vue({
  el: "#app",
  data: {
    validTill: null,
    orderType: null,
    Ordertypelist: [],
    distributorChannel: null,
    distributorChnlList: [],
    reasonType: null,
    reasonTypeList: [],
    division: null,
    divisionList: [],
    pricelist: "10/FC STOCKIEST",
    priceMasterList: [],
    lorryType: null,
    lorryTypeList: [],
    incoTerm: null,
    incoTermList: [],
    ORC1: null,
    ORC2: null,
    orcList: [],
    plant: null,
    Mainobject: {},
    Total: 0,
    CEPrice: 0,
    noTaxable: 0,
    saleOffice: null,
    selected: "",
    distButDetails: [],
    distButTOTDetails: [],
    moduleName: "",
    show: "false",
    rwoCount: 0,
    contactList: [],
    BtpVar: null,
    StpVar: null,
    productMainList: [],
    productOptionList: [],
    checkValidateCount: 1,
    distributorTypeList: [],
    plantList: [],
    LoginUserID: null,
    LoginUserType: null,
    roofMatGroup: null,
    roofMatGroupList: [],
    roofExtMatGroup: null,
    roofExtMatGroupList: [],
    filterMaterial: null,
    filterMaterialList: [],
    testObject: [],
    pageCall: 1,
    partFilterList: [],
    partFilter: null,
    mainRecordDetails: null,
    locationShips: null,
    orderStatus: "In Draft",
    dealerid: null,
    filterQuantity: null,
    roofRevExtMatGroupList: [],
    roofRevExtMatGroup: null,
    roofColorList: [],
    roofColor: null,
    l1Approve: null,
    l2Approve: null,
    l3Approve: null,
    Notes: null,
    ORC1_value: null,
    ORC2_value: null,
    checkavaliableStatus: false,
    PurchNoC: null,
    filterTodLineItem: null,
    filterCePrice: null,
    FreightPerTon: null,
    Feight_Per_Ton: null,
    FooterCEAmount: null,
    FooterInBillDiscount: null,
    FooterListAmount: null,
    FooterNSPperMT: null,
    FooterORC1Amount: null,
    FooterORC2Amount: null,
    FooterOrderAmount: null,
    FooterTODAmount: null,
    FooterTaxAmount: null,
    FooterTotalFreight: null,
    FooterWeightinMT: null,
    l1_role: null,
    l2_role: null,
    l3_role: null,
    currentLoginRole: null,
    filter: null,
    URLDirect: null,
    overallObject: []
  },
  // watch:{
  //   division(newvalue,oldvalue){
  //     vm.plant=null;
  //     vm.Mainobject=[];

  //   },
  // },
  methods: {

    quantityCheck() {
      if (vm.filterQuantity == 0) {
        vm.filterQuantity = 1;
      }
    },
    prefill(index, event = '') {
      console.log("prefill am after close")
      console.log(vm.Mainobject);
      duplicate = false;
      for (const [key, value] of Object.entries(vm.Mainobject)) {
        //null check because after the close icon in line item its call the function
        console.log(event);
        if (event != "") {
          if (index != key) {
            if (value.productId == event.id) {
              duplicate = true;
              break
            }
          }
        }
      }

      //console.log(duplicate)
      if (duplicate == false) {
        ZOHO.CRM.API.getRecord({ Entity: "Material_Master", RecordID: event.id })
          .then(function (response) {
            var unitPrice = 10;
            //vm.Mainobject[index].price = response.data[0].Unit_Price;
            vm.Mainobject[index].price = unitPrice;
            vm.Mainobject[index].orderQuantity = 1;
            vm.Mainobject[index].cePrice = unitPrice;
            $("#row_qun" + index).val(1);
            $("#cePrice" + index).val(unitPrice);
            vm.Total += 1 * parseFloat(unitPrice);
            vm.CEPrice += 1 * parseFloat(unitPrice);

            vm.Mainobject[index].totalListPrice = parseFloat(vm.Mainobject[index].price) * parseFloat($("#row_qun" + index).val());
            vm.Mainobject[index].totalCEPrice = parseFloat($("#cePrice" + index).val()) * parseFloat($("#row_qun" + index).val());
            //row id
            if (event != '') {
              vm.Mainobject[index].productId = event.id;
            }
            vm.$forceUpdate();
          })
      }
      else {
        swal({
          title: "Duplicate Record Was Found",
          // text: "",
          icon: "warning",
          buttons: true,
          dangerMode: true,
          buttons: {
            confirm: "OK",
            // cancel: 'No'
          },
        })
          .then((e) => {
            if (e) {
              vm.Mainobject[index].part = null;
              vm.Mainobject[index].partList = [];
              vm.$forceUpdate();
            }
          });
      }

    },
    searchProduct(search, rowID) {
      vm.productOptionList = [];
      console.log("coming in");
      if (search.length > 3) {
        console.log(rowID);
        console.log(search);
        var queryParams = "(((Name:starts_with:" + search + ")or(Material_Description:starts_with:" + search + ")))";
        ZOHO.CRM.API.searchRecord({ Entity: "Material_Master", Type: "criteria", Query: queryParams, page: 1, per_page: 100 })
          .then(function (response) {
            console.log(response);
            var parts = [];
            vm.productOptionList = [];
            if (response.status !== 204) {
              response.data.forEach(element => {
                console.log(element);
                var myOption = {};
                myOption.displayName = element.Name + " - " + element.Material_Description;
                myOption.name = element.Material_Description;
                myOption.id = element.id;
                parts.push(myOption)
                //vm.productOptionList.push(myOption.displayName);
              });
              //vm.productMainList[rowID] = parts;
              vm.Mainobject[rowID].partList = parts;
              console.log(rowID);
            }
          })
      }
      vm.$forceUpdate();
    },
    addItem() {
      vm.rwoCount = vm.rwoCount + 1;
      if (vm.rwoCount > 50) {
        swal({
          title: "Line Item Limit Exist",
          text: "  ",
          icon: "error",
          timer: 1000,
          buttons: false,
        });
      }
      else {
        vm.checkavaliableStatus = false;
        console.log(rowId);

        newObject = { "name": null, "price": null, "orderQuantity": null, "gstPer": null, "gstValue": null, "noOfQua": null, "avaliableStatus": null, "cePrice": null, "totalListPrice": null, "totalCEPrice": null, "partList": [], "productId": null, "part": null, "descriptionName": null, "TOD": null, "approve1": "-", "approve2": "-", "approve3": "-", "Total_Discont": null, "Tod_Amount": null, "totalOrderAmount": null, "BUN": null, "mm_Alternate_UOM": null, "cnDiscountPerUOm": null, "TotalFreight": null, "TotalDiscount": null, "TotalCNDiscount": null, "Tonnage": null, "Tax_slab": null, "TAX": null, "STR_Fright": null, "ORC2_value": null, "ORC2Amount": null, "ORC1_value": null, "ORC1Amount": null, "NetOderValue": null, "NSP": null, "MM_Alternate_M2N": null, "InBillDiscountPer": null, "InBillDiscount": null, "GrossWeigtPerPice": null, "Freight": null, "cnDiscountPercetage": null, "TodValuePerUOM": null };
        console.log(newObject);
        newObject["ID"] = rowId;
        vm.Mainobject[rowId] = newObject;
        rowId++;
        $("#CheckValidate").css("display", "block")
        //$("#Submit").css("display", "none");
        vm.$forceUpdate();
      }
    },
    deleteRow(id) {
      console.log(id)
      swal({
        title: "Are you sure?",
        text: "Do want to Delete",
        icon: "warning",
        buttons: true,
        dangerMode: true,
        buttons: {
          confirm: "Yes",
          cancel: 'No'
        },
      })
        .then((willDelete) => {
          if (willDelete) {
            vm.rwoCount = vm.rwoCount - 1;

            swal({
              title: "Deleted Sucessfully",
              text: "  ",
              icon: "success",
              timer: 1000,
              buttons: false,
            });
            delete vm.Mainobject[id];
            vm.$forceUpdate();
          }
        });
      vm.$forceUpdate();
    },
    placeOrder() {

    },
    reset() {
      window.location.reload();
    },
    //check in sap
    async CheckValidate(status = "False", param = '') {
      console.log(status)
      if (JSON.stringify(vm.Mainobject) === '{}') {
        swal({
          title: "",
          text: "Please add one line item for Check the order",
          icon: "warning",
          button: "OK",
        });
        return false;
      }
      if (status == true) {
        ///alert('sss');
        var row = 1;
        requestDataForSAP = {
          "Distribution_Channel": "10/FOR DOMESTIC",
          "Status": status,
          "Division": vm.division,
          "Inco_term": vm.incoTerm,
          "Lorry_Type": vm.lorryType,
          "Plant": vm.plant,
          "BTP": vm.BtpVar,
          "STP": vm.StpVar,
          "Price_List": vm.pricelist,
          "ORC1_value": vm.ORC1_value,
          "ORC2_value": vm.ORC2_value,
          "Sales_Order_type": vm.orderType,
          "SO_reason_type": vm.reasonType,
          "lineItem": vm.Mainobject
        };
        // var func_name = "checkAvailabilitySAP1";
        var func_name = "testorder13897";
        
        var req_data = {
          "arguments": JSON.stringify(requestDataForSAP)
        };
        await ZOHO.CRM.FUNCTIONS.execute(func_name, req_data)
          .then(function (response) {
            console.log(response);
            var output = response.details.output;
            if (output != "error") {
              jsonParse = JSON.parse(output);
              console.log(jsonParse);
              //Footer Level Data
              vm.FooterCEAmount = jsonParse.data.FooterCEAmount;
              vm.FooterInBillDiscount = jsonParse.data.FooterInBillDiscount;
              vm.FooterListAmount = jsonParse.data.FooterListAmount;
              vm.FooterNSPperMT = jsonParse.data.FooterNSPperMT;
              vm.FooterORC1Amount = jsonParse.data.FooterORC1Amount;
              vm.FooterORC2Amount = jsonParse.data.FooterORC2Amount;
              vm.FooterOrderAmount = jsonParse.data.FooterOrderAmount;
              vm.FooterTODAmount = jsonParse.data.FooterTODAmount;
              vm.FooterTaxAmount = jsonParse.data.FooterTaxAmount;
              vm.FooterTotalFreight = jsonParse.data.FooterTotalFreight;
              vm.FooterWeightinMT = jsonParse.data.FooterWeightinMT;
              vm.FreightPerTon = jsonParse.data.Feight_Per_Ton;

              jsonParse.data.lineItem.forEach(element => {
                materialCode = element.materialCode;
                CondValue = element.listPrice;
                colorCode = element.Status;
                CEAmount = element.CEAmount;
                ListAmount = element.ListAmount;
                OrderAmount = element.OrderAmount;
                TodAmount = element.TodAmount;
                TodDiscount = element.TodDiscount;

                for (key in vm.Mainobject) {
                  console.log(vm.Mainobject[key]);
                  if (materialCode == vm.Mainobject[key].part.materialCode) {
                    $("#aval1_" + key).css("display", "none");
                    $("#aval2_" + key).css("display", "none");
                    vm.Mainobject[key].price = parseFloat(CondValue).toFixed(2);
                    if (colorCode == 1) {
                      vm.Mainobject[key].avaliableStatus = 1;
                      $("#aval1_" + key).css("display", "block");
                    }
                    else {
                      vm.Mainobject[key].avaliableStatus = 0;
                      $("#aval2_" + key).css("display", "block");
                    }


                    vm.Mainobject[key].totalListPrice = element.ListAmount;
                    vm.Mainobject[key].totalCEPrice = element.CEAmount;
                    vm.Mainobject[key].totalOrderAmount = element.OrderAmount;
                    vm.Mainobject[key].Tod_Amount = element.TodAmount;
                    vm.Mainobject[key].Total_Discont = element.TodDiscount;
                    vm.Mainobject[key].BUN = element.BUN;
                    vm.Mainobject[key].mm_Alternate_UOM = element.mm_Alternate_UOM;
                    vm.Mainobject[key].cnDiscountPerUOm = element.cnDiscountPerUOm;
                    vm.Mainobject[key].TotalFreight = element.TotalFreight;
                    vm.Mainobject[key].TotalDiscount = element.TotalDiscount;
                    vm.Mainobject[key].TotalCNDiscount = element.TotalCNDiscount;
                    vm.Mainobject[key].Tonnage = element.Tonnage;
                    vm.Mainobject[key].Tax_slab = element.Tax_slab;
                    vm.Mainobject[key].TAX = element.TAX;
                    vm.Mainobject[key].STR_Fright = element.STR_Fright;
                    vm.Mainobject[key].ORC2_value = element.ORC2_value;
                    vm.Mainobject[key].ORC2Amount = element.ORC2Amount;
                    vm.Mainobject[key].ORC1_value = element.ORC1_value;
                    vm.Mainobject[key].ORC1Amount = element.ORC1Amount;
                    vm.Mainobject[key].NetOderValue = element.NetOderValue;
                    vm.Mainobject[key].NSP = element.NSP;
                    vm.Mainobject[key].MM_Alternate_M2N = element.MM_Alternate_M2N;
                    vm.Mainobject[key].InBillDiscountPer = element.InBillDiscountPer;
                    vm.Mainobject[key].InBillDiscount = element.InBillDiscount;
                    vm.Mainobject[key].GrossWeigtPerPice = element.GrossWeigtPerPice;
                    vm.Mainobject[key].Freight = element.Freight;
                    vm.Mainobject[key].cnDiscountPercetage = element.cnDiscountPercetage;
                    vm.Mainobject[key].TodValuePerUOM = element.TodValuePerUOM;
                    vm.Mainobject[key].SupplyQty = element.SupplyQty;
                    
                  }
                }
              });

              vm.$forceUpdate();

              vm.show = "false";
              document.getElementById("transscreen").style.display = "none";

              if (param) {
                if (vm.checkavaliableStatus) {
                  vm.Submit();
                }
                else {
                  swal({
                    title: "Did You Click The Check Availability Button",
                    // text: "",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                    buttons: {
                      confirm: "Yes",
                      cancel: 'No'
                    },
                  })
                    .then((e) => {
                      if (e) {
                        vm.Submit();
                      }
                    });
                }
              }
            }
            else {
              swal({
                title: "Contact IT Team, Facing Problem in Check Availability",
                text: " ",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                buttons: {
                  // confirm: "OK",
                  // cancel: 'No'
                },
              })
              vm.show = "false";
              document.getElementById("transscreen").style.display = "none";
            }

          })
        vm.checkValidateCount = 1;
        vm.checkavaliableStatus = true;
      }
    },
    accDistSearch(search, loading) {
      console.log(search);
      console.log(loading);

      queryParams = "(Account_Name:starts_with:" + search + ")"
      //api call to search account details and store in main object
      ZOHO.CRM.API.searchRecord({ Entity: "Accounts", Type: "criteria", Query: queryParams, page: 1, per_page: 100 })
        .then(function (data) {
          console.log(data);
          var myOption = {};
          var distButTOTDetails = [];
          if (data.status !== 204) {

            data.data.forEach(element => {
              var myOption = {};
              myOption.name = element.Account_Name;
              myOption.id = element.id;
              distButTOTDetails.push(myOption);
              distButDetails.push(myOption);

            });
          }
          else {
            loading(false);
          }
        })
    },
    saveAsDraft() {
      vm.show = "true";
      document.getElementById("transscreen").style.display = "block";
      console.error("save as draft")
      console.log(vm.Mainobject);
      orc1 = null;
      orc2 = null;
      plant = null;
      StpVar = null;
      BtpVar = null;
      saleOffice = null;
      if (this.ORC1) {
        orc1 = { "id": this.ORC1.id }
      }
      if (this.ORC2) {
        orc2 = { "id": this.ORC2.id }
      }

      if (this.plant != null) {
        plant = { "id": this.plant.id }
      }
      if (this.StpVar != null) {
        StpVar = { "id": this.StpVar.id }
      }
      if (this.BtpVar != null) {
        BtpVar = { "id": this.BtpVar.id }
      }
      if (this.saleOffice != null) {
        saleOffice = { "id": this.saleOffice.id }
      }
      // 
      var myObject = {
        "ORC1": orc1,
        "ORC2": orc2
      };
      // 
      var recordData = {
        "Distribution_Channel": "10/FOR DOMESTIC",
        "Status": "In Draft",
        "Division": this.division,
        "Inco_term": this.incoTerm,
        "Lorry_Type": this.lorryType,
        "Location_for_shipping": this.locationShips,
        "BU_Type": vm.LoginUserType,
        // "ORC1": orc1,
        // "ORC2": orc2,
        "ORC1_Value": this.ORC1_value,
        "ORC2_Value": this.ORC2_value,
        "PlantCode": vm.plant,
        "Price_List": this.pricelist,
        "Sales_Order_type": this.orderType,
        "Ship_to_party": StpVar,
        "Sold_to_party": BtpVar,
        "SO_reason_type": this.reasonType,
        "Sales_Office": saleOffice,
        // "Total": parseFloat(vm.Total),
        // "TotalCE_Price": parseFloat(vm.CEPrice),
        "Remarks": this.Notes,
        "Purchase_No": vm.PurchNoC
      };

      console.log(recordData);

      ZOHO.CRM.API.insertRecord({ Entity: "Order_Management", APIData: recordData, Trigger: ["workflow"] }).then(async function (response) {
        var status = response.data[0].code;

        if (status == "SUCCESS") {
          var orderMainModuleId = response.data[0].details.id;
          vm.mainRecordDetails = orderMainModuleId;
          var recordStatus = true;
          // To insert ORC Value in order managemnt Added by Anuj On 02-08-2023
          var req_data = {
            "parameters": { "data": [myObject], "trigger": ["approval","blueprint"] },
            "method": "PUT",
            "url": "https://www.zohoapis.in/crm/v2/Order_Management/"+ orderMainModuleId,
          };
          console.log(req_data);
          // 
          await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
            .then(function (response) {
              console.log(response)
              var status = response.details.statusMessage.data[0].code;
              if (status != "SUCCESS") {
                recordStatus = false;
              }
            });
            // 
          if (JSON.stringify(vm.Mainobject) === '{}') {
            swal({
              title: "Save as Draft",
              // text: "",
              icon: "success",
              buttons: true,
              dangerMode: true,
              buttons: {
                confirm: "OK",
                // cancel: 'No'
              },
            })
              .then((e) => {
                if (e) {
                  //vm.reset()

                  //window.open("https://crmplus.zoho.in/everestindustrieslimited/index.do/cxapp/crm/org60012502525/tab/CustomModule15/"+orderMainModuleId,"_parent");
                  window.open(vm.URLDirect + "CustomModule15/" + orderMainModuleId, "_parent");
                  ZOHO.CRM.UI.Popup.closeReload();
                }
              });

          }
          else {
            // insert in order line item one by one.
            for (key in vm.Mainobject) {

              if (vm.Mainobject[key].productId) {
                console.log(vm.Mainobject[key])

                if (vm.Mainobject[key].cePrice == '') {
                  ceprice = parseFloat(vm.Mainobject[key].price);
                }
                else {
                  ceprice = parseFloat(vm.Mainobject[key].cePrice);
                }

                myObject = {};
                myObject.List_Price = parseFloat(vm.Mainobject[key].price);
                myObject.Quantity = parseFloat(vm.Mainobject[key].orderQuantity);
                // myObject.Customer_Expected_Price = parseInt(vm.Mainobject[key].cePrice);
                myObject.Customer_Expected_Price = parseFloat(ceprice);
                myObject.Customer_Expected_Price_Total = parseFloat(vm.Mainobject[key].orderQuantity) * parseFloat(ceprice);
                myObject.Material_Code = { "id": vm.Mainobject[key].productId };
                myObject.Order_Management_ID = { "id": orderMainModuleId }
                myObject.TOD = parseFloat(vm.Mainobject[key].TOD).toString();
                if(vm.Mainobject[key].SupplyQty){
                myObject.SAP_Quantity = parseFloat(vm.Mainobject[key].SupplyQty);
                }
                if(vm.Mainobject[key].avaliableStatus){
                  if(vm.Mainobject[key].avaliableStatus == 1){
                    myObject.Red_Green_Indicator = "Green"; 
                  }else{
                    myObject.Red_Green_Indicator = "Red"; 
                  }
      
                }
                myObject.Required_Quantity = parseFloat(vm.Mainobject[key].orderQuantity);

                myObject.Approve_Status = "In Draft";
                console.log(myObject);

                await ZOHO.CRM.API.insertRecord({ Entity: "Order_Line_Items", APIData: myObject, Trigger: ["workflow"] }).then(function (response) {
                  console.log(response);
                });

              }
            }

            if (recordStatus == true) {
              swal({
                title: "Save as Draft",
                // text: "",
                icon: "success",
                buttons: true,
                dangerMode: true,
                buttons: {
                  confirm: "OK",
                  // cancel: 'No'
                },
              })
                .then((e) => {
                  if (e) {
                    //vm.reset()

                    //window.open("https://crmplus.zoho.in/everestindustrieslimited/index.do/cxapp/crm/org60012502525/tab/CustomModule15/"+orderMainModuleId,"_parent");
                    window.open(vm.URLDirect + "CustomModule15/" + orderMainModuleId, "_parent");
                    ZOHO.CRM.UI.Popup.closeReload();
                  }
                });
              // vm.reset();
              // ZOHO.CRM.UI.Popup.closeReload();
              // //window.open("https://crmplus.zoho.in/everestindustrieslimited/index.do/cxapp/crm/org60012502525/tab/CustomModule15/"+orderMainModuleId,"_parent");
              // window.open(vm.URLDirect+"CustomModule15/"+orderMainModuleId,"_parent");
            }
          }
        }
      });
    },
    Submit() {
      subFormObject = [];
      vm.show = "true";
      document.getElementById("transscreen").style.display = "block";


      if (JSON.stringify(vm.Mainobject) === '{}') {
        swal({
          title: "",
          text: "Please add one line item for sumbit the order",
          icon: "warning",
          button: "OK",
        });
        vm.show = "false";
        document.getElementById("transscreen").style.display = "none";
      }
      else {

        var l1 = parseFloat(vm.l1Approve);
        var l2 = parseFloat(vm.l2Approve);
        var l3 = parseFloat(vm.l3Approve);
        var status = "Auto Approved"
        var lineitemStatus = "Auto Approved";

        for (key in vm.Mainobject) {
          todDiscountValue = parseFloat(vm.Mainobject[key].Total_Discont);
          if (vm.currentLoginRole == vm.l1_role) {
            if (todDiscountValue >= l1) {
              status = "L1 Approval Pending"
              lineitemStatus = "L1 Pending";
            }
          }
          else if (vm.currentLoginRole == vm.l2_role) {
            if (todDiscountValue >= l2) {
              status = "L1 Approval Pending"
              lineitemStatus = "L1 Pending";
            }
          }
          else if (vm.currentLoginRole == vm.l3_role || vm.currentLoginRole == "CEO") {
            status = "Auto Approved"
            lineitemStatus = "Auto Approved";
          }
          else {
            if (todDiscountValue > 0) {
              status = "L1 Approval Pending"
              lineitemStatus = "L1 Pending";
            }
          }
        }

        console.log(status);

        console.log(status);
        orc1 = null;
        orc2 = null;
        plant = null;
        StpVar = null;
        BtpVar = null;
        saleOffice = null;
        if (this.ORC1) {
          orc1 = { "id": this.ORC1.id }
        }
        if (this.ORC2) {
          orc2 = { "id": this.ORC2.id }
        }
        if (this.plant != null) {
          plant = { "id": this.plant.id }
        }
        if (this.StpVar != null) {
          StpVar = { "id": this.StpVar.id }
        }
        if (this.BtpVar != null) {
          BtpVar = { "id": this.BtpVar.id }
        }
        if (this.saleOffice != null) {
          saleOffice = { "id": this.saleOffice.id }
        }

        // 
        var myObject = {
          "ORC1": orc1,
          "ORC2": orc2
        };
        // 

        var recordData = {
          "Distribution_Channel": "10/FOR DOMESTIC",
          "Status": status,
          "Division": this.division,
          "Inco_term": this.incoTerm,
          "Lorry_Type": this.lorryType,
          "Location_for_shipping": this.locationShips,
          "BU_Type": vm.LoginUserType,
          // "ORC1": orc1,
          // "ORC2": orc2,
          "ORC1_Value": this.ORC1_value,
          "ORC2_Value": this.ORC2_value,
          "PlantCode": vm.plant,
          "Price_List": this.pricelist,
          "Sales_Order_type": this.orderType,
          "Ship_to_party": StpVar,
          "Sold_to_party": BtpVar,
          "SO_reason_type": this.reasonType,
          "Sales_Office": saleOffice,
          "Remarks": this.Notes,
          "Purchase_No": vm.PurchNoC,
          "Weight_in_MT": vm.FooterWeightinMT,
          "Freight_per_ton": vm.FreightPerTon,
          "Total_Tax_Amount": vm.FooterTaxAmount,
          "Total_Freight": vm.FooterTotalFreight,
          "Total_In_Bill_Disc": vm.FooterInBillDiscount,
          "Total_List_Amount": vm.FooterListAmount,
          "Total_ORC2_Amount": vm.FooterORC2Amount,
          "Total_ORC1_Amount": vm.FooterORC1Amount,
          "Total_Order_Amount": vm.FooterOrderAmount,
          "Total_CE_Amount": vm.FooterCEAmount,
          "NSP_per_MT": vm.FooterNSPperMT,
          "Total_TOD_Amount": vm.FooterTODAmount,
        };
        console.log(recordData);

        ZOHO.CRM.API.insertRecord({ Entity: "Order_Management", APIData: recordData, Trigger: ["workflow"] }).then(async function (response) {
          console.log(response);
          var status = response.data[0].code;
          if (status == "SUCCESS") {
            var orderMainModuleId = response.data[0].details.id;
            var recordStatus = true;
            // 
            // To insert ORC Value in order managemnt Added by Anuj On 02-08-2023  
            // Changes done in Line no 785 to 799 and 734 to 737
            var req_data = {
              "parameters": { "data": [myObject], "trigger": ["approval","blueprint"] },
              "method": "PUT",
              "url": "https://www.zohoapis.in/crm/v2/Order_Management/"+ orderMainModuleId,
            };
            console.log(req_data);
            // 
            await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
              .then(function (response) {
                console.log(response)
                var status = response.details.statusMessage.data[0].code;
                if (status != "SUCCESS") {
                  recordStatus = false;
                }
              });
            // insert in order line item one by one.
            for (key in vm.Mainobject) {
              console.log(vm.Mainobject[key])

              if (vm.Mainobject[key].avaliableStatus == 0) {
                vm.Mainobject[key].avaliableStatus = "Available";
              }
              else {
                vm.Mainobject[key].avaliableStatus = "Not Available";
              }

              myObject = {};
              myObject.List_Price = parseFloat(vm.Mainobject[key].price);
              myObject.Quantity = parseFloat(vm.Mainobject[key].orderQuantity);
              myObject.Customer_Expected_Price = parseFloat(vm.Mainobject[key].cePrice);
              myObject.List_Amount = parseFloat(vm.Mainobject[key].totalListPrice);
              myObject.CE_Amount = parseFloat(vm.Mainobject[key].totalCEPrice);
              myObject.Order_Amount = parseFloat(vm.Mainobject[key].totalOrderAmount);
              myObject.Material_Code = { "id": vm.Mainobject[key].productId };
              myObject.Order_Management_ID = { "id": orderMainModuleId }
              myObject.Avaliable_Status = vm.Mainobject[key].avaliableStatus;
              myObject.TOD = vm.Mainobject[key].TOD;
              myObject.TOD_Amount = parseFloat(vm.Mainobject[key].Tod_Amount);
              myObject.Tod_Discount = vm.Mainobject[key].Total_Discont.toString();
              //follow calculation Details
              //Gross_Weight_Per_PC_Weight	
              myObject.BUN = vm.Mainobject[key].BUN.toString();

              myObject.CN_Discount_per_UoM = vm.Mainobject[key].cnDiscountPerUOm.toString();
              myObject.In_bill_discount = vm.Mainobject[key].InBillDiscount.toString();
              myObject.In_bill_discount_per_UOM = vm.Mainobject[key].InBillDiscountPer.toString();
              myObject.MM_Alternate_M2N = vm.Mainobject[key].MM_Alternate_M2N.toString();
              myObject.MM_Alternate_UOM = vm.Mainobject[key].mm_Alternate_UOM.toString();
              myObject.Net_Order_Value = vm.Mainobject[key].NetOderValue.toString();
              myObject.NSP = vm.Mainobject[key].NSP.toString();
              myObject.ORC_1_Amount = vm.Mainobject[key].ORC1Amount.toString();
              myObject.ORC_2_Amount = vm.Mainobject[key].ORC2Amount.toString();
              myObject.ORC1 = vm.Mainobject[key].ORC1_value.toString();
              myObject.ORC2 = vm.Mainobject[key].ORC2_value.toString();
              myObject.STR_Freight = vm.Mainobject[key].STR_Fright.toString();
              myObject.Tax = vm.Mainobject[key].TAX.toString();
              myObject.Tax_slab = vm.Mainobject[key].Tax_slab.toString();
              myObject.Tonnage = vm.Mainobject[key].Tonnage.toString();
              myObject.Gross_Weight_Per_PC_Weight = vm.Mainobject[key].GrossWeigtPerPice.toString();
              myObject.Total_Freight = vm.Mainobject[key].TotalFreight.toString();
              myObject.Total_CN_Discount = vm.Mainobject[key].TotalCNDiscount.toString();
              myObject.CN_Disc = vm.Mainobject[key].cnDiscountPercetage.toString();
              myObject.TOD_UOM_BP = vm.Mainobject[key].TodValuePerUOM.toString();
              myObject.Total_Discount = vm.Mainobject[key].TotalDiscount;
              myObject.Freight_Discount_Paid = vm.Mainobject[key].Freight.toString();
             if(vm.Mainobject[key].SupplyQty){
              myObject.SAP_Quantity = parseFloat(vm.Mainobject[key].SupplyQty);
             }
             if(vm.Mainobject[key].avaliableStatus){
              if(vm.Mainobject[key].avaliableStatus == 1){
                myObject.Red_Green_Indicator = "Green"; 
              }else{
                myObject.Red_Green_Indicator = "Red"; 
              }
  
              // myObject.Red_Green_Indicator = ""+ vm.Mainobject[key].avaliableStatus;
             }
             myObject.Required_Quantity = parseFloat(vm.Mainobject[key].orderQuantity);




              myObject.Approve_Status = lineitemStatus;
              console.log(myObject);

              await ZOHO.CRM.API.insertRecord({ Entity: "Order_Line_Items", APIData: myObject, Trigger: ["workflow"] }).then(function (response) {
                console.log(response);
              });
            }

            if (recordStatus == true) {
              swal({
                title: "Order Created Successfully",
                // text: "",
                icon: "success",
                buttons: true,
                dangerMode: true,
                buttons: {
                  confirm: "OK",
                  // cancel: 'No'
                },
              })
                .then((e) => {
                  if (e) {
                    //vm.reset()

                    //window.open("https://crmplus.zoho.in/everestindustrieslimited/index.do/cxapp/crm/org60012502525/tab/CustomModule15/"+orderMainModuleId,"_parent");
                    window.open(vm.URLDirect + "CustomModule15/" + orderMainModuleId, "_parent");
                    ZOHO.CRM.UI.Popup.closeReload();
                  }
                });
              //  vm.reset();
              //  //history.back();
              //  ZOHO.CRM.UI.Popup.closeReload();
              //  //window.open("https://crmplus.zoho.in/everestindustrieslimited/index.do/cxapp/crm/org60012502525/tab/CustomModule15/"+orderMainModuleId,"_parent");
              //  window.open(vm.URLDirect+"CustomModule15/"+orderMainModuleId,"_parent");
            }
            else {
              swal({
                title: "Something went Wrong, Please Contact IT Team",
                icon: "warning",
                button: "OK",
              });
              vm.reset();
            }
          }
        });
      }
    },
    searchdistributor(search, modal, orc = '') {
      // Added by Anuj on 21 Aug 23 
      // Added upto 905 to 921 for search based filter of BTP Account
      if (search.length > 3 || search == "") {
        if (modal == "Accounts") {
          if (orc != '') {
            ZOHO.CRM.API.searchRecord({ Entity: "Accounts", Type: "criteria", Query: "(Account_Name:starts_with:" + search + ")and (SAP_Code:starts_with:" + 27 +")" }).then(function (Accounts) {
              console.log("Accounts");
              console.log(Accounts);
              vm.orcList = [];
              if (Accounts.status !== 204) {
                Accounts.data.forEach((element) => {
                  text = element.Account_Name;
                  id = element.id;
                  SAP_Code = element.SAP_Code;
                  myobject = { "text": text +"/" + SAP_Code, "id": id }
                  vm.orcList.push(myobject);
                });
              }
            });
            //orc
            // ORC Changes done by Anuj on 04-08-2023
            // Change : SAP_Code is added in API requsest alongwith BTP Account name in ORC list
            // Changes done in line 911,918,933,934
            // if (search == "") {
            //   var req_data = {
            //     "parameters": { "select_query": "SELECT Account_Name,id,SAP_Code from Accounts where SAP_Code!=''" },
            //     "method": "POST",
            //     "url": "https://www.zohoapis.in/crm/v3/coql" //https://www.zohoapis.com/crm/v3/coql
            //   }
            // }
            // else {
            //   var req_data = {
            //     "parameters": { "select_query": "SELECT Account_Name,id,SAP_Code from Accounts where SAP_Code!='' and Account_Name or SAP_Code like'%" + search + "%'" },
            //     "method": "POST",
            //     "url": "https://www.zohoapis.in/crm/v3/coql" //https://www.zohoapis.com/crm/v3/coql
            //   }
            // }
            // ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
            //   .then(function (response) {
            //     console.log(response);
            //     if (response.code == "SUCCESS") {
            //       if (response.details.status == "true") {
            //         if (response.details.statusMessage.data) {
            //           vm.orcList = [];
            //           for (key in response.details.statusMessage.data) {
            //             text = response.details.statusMessage.data[key].Account_Name;
            //             id = response.details.statusMessage.data[key].id;
            //             sap_code = response.details.statusMessage.data[key].SAP_Code;
            //             myobject = { "text": text +"/ "+sap_code, "id": id }
            //             vm.orcList.push(myobject);
            //           }
            //         }
            //       }
            //     }
            //   });
          }
        }
      }
    },
    modulePrefill(moduleName, id) {

      ZOHO.CRM.API.getRecord({ Entity: "Accounts", RecordID: id })
        .then(async function (response) {
          console.error("account Module");
          console.log(response);
          var accountDetails = response.data[0].Account_Type;
          var Account_Name = response.data[0].Account_Name;
          var accountId = response.data[0].id;
          //var Distributor = response.data[0].Distributor;
          var Distributor = response.data[0].Parent_Account;
          SAP_Code_Status = response.data[0].SAP_Code_Status;
          SAP_Code = response.data[0].SAP_Code;
          var BU = response.data[0].BU_Type;
          console.log(SAP_Code_Status);
          console.log(SAP_Code);
          if (SAP_Code_Status == "Success" && (SAP_Code != "" || SAP_Code != null)) {
            vm.show = "false";
            document.getElementById("transscreen").style.display = "none";
            console.log(Distributor);
            vm.orderType = "ZFSM/DOMESTIC SALE"
            if (accountDetails != "Project Sale") {
              vm.reasonType = "Z21/RETAIL SALE";
              //$("#ORCHide").css("display","none");
            }
            else {
              vm.reasonType = "Z20/PROJECT SALE";
              //$("#ORCHide").css("display","block");
            }

            if (BU == "Roofing") {
              $("#BPMaterial").css("display", "none");

              vm.divisionList = ["10/ROOFING"];
              vm.division = "10/ROOFING";

            }
            else if (BU == "BP") {
              $("#BPMaterial").css("display", "block");

              vm.divisionList = ["20/BOARDS", "30/PANEL"];
              vm.division = "20/BOARDS";
            }

            if (vm.division == "10/ROOFING") {
              vm.filter = "10";
            }
            else if (vm.division == "20/BOARDS") {
              vm.filter = "20";
            }
            else if (vm.division == "30/PANEL") {
              vm.filter = "30";
            }

            // var req_data = {
            //   "parameters": { "select_query": "SELECT Plant_Code,Plant_Name from Material_Master where Plant_Code!='' and Division_Code='" + vm.filter + "' group by Plant_Code,Plant_Name" },
            //   "method": "POST",
            //   "url": "https://www.zohoapis.in/crm/v3/coql" //https://www.zohoapis.com/crm/v3/coql
            // }

            // await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
            //   .then(function (response) {
            //     console.error("plant Code");
            //     console.log(response);
            //     if (response.code == "SUCCESS") {
            //       if (response.details.status == "true") {
            //         if (response.details.statusMessage.data) {
            //           for (key in response.details.statusMessage.data) {
            //             var Plant_Code = response.details.statusMessage.data[key].Plant_Code;
            //             var Plant_Name = response.details.statusMessage.data[key].Plant_Name;
            //             vm.plantList.push(Plant_Code + "/ " + Plant_Name);
            //           }
            //         }
            //       }
            //     }
            //   });


            requestDataForSAP = {
              "Division_Code": vm.filter
            }
            var func_name = "PlanCodeDetails_1";
            var req_data = {
              "arguments": JSON.stringify(requestDataForSAP)
            };
            ZOHO.CRM.FUNCTIONS.execute(func_name, req_data)
              .then(function (response) {
                console.error("response");
                console.error(response);
                if (response.code == "success") {
                  if (response.details.output) {
                    dataDetails = JSON.parse(response.details.output)
                    for (key in dataDetails.data) {
                      var Plant_Code = dataDetails.data[key].Plant_Code;
                      var Plant_Name = dataDetails.data[key].Plant_Name;
                      vm.plantList.push(Plant_Code + "/ " + Plant_Name);
                    }
                  }
                }
              })

            // SAP Code is added alongwith Account name for STP and BTP for all type of account (Distributor,Stockist and dealer) at all places, added by anuj on 07 Sep 23
            if (accountDetails == "Distributor") {
              // need to check in account module where parent name contains for ship to party drop down
              // send value in sold to party
              // get value form ship to party dealers 
              vm.BtpVar = { "id": accountId, "text": Account_Name + "/" + SAP_Code };
              //conditon parent name = id and account type = dealer

              vm.distributorTypeList = [];
              myobject = { "text": Account_Name + "/"+ SAP_Code, "id": accountId }
              vm.distributorTypeList.push(myobject);

              // var queryParams = "((Parent_Account:equals:"+id+")and(Account_Type:equals:Dealer))";
              var queryParams = "((Parent_Account:equals:" + id + ")and(SAP_Code_Status:equals:Success))";
              await ZOHO.CRM.API.searchRecord({ Entity: "Accounts", Type: "criteria", Query: queryParams, page: 1, per_page: 100 })
                .then(function (response) {
                  console.error("account Module Distributor search");
                  console.log(response);

                  if (response.status !== 204) {

                    if (response.info.more_records) {
                      vm.overallObject.push(response.data);
                      // console.log("Overall object ",vm.overallObject);
                      vm.FunctionDistrubut(response.info.page + 1, id)
                    }
                    else {
                      response.data.forEach(element => {
                        text = element.Account_Name;
                        id = element.id;
                        myobject = { "text": text + "/" +SAP_Code, "id": id }
                        vm.distributorTypeList.push(myobject);
                      });
                      // Changes made by Anuj on 17 july 23
                      // for (i = 0; i < response.data; i++) {
                      //   text = response.data[i].Account_Name;
                      //   id = response.data[i].id;
                      //   myobject = { "text": text, "id": id }
                      //   vm.distributorTypeList.push(myobject);
                      // }

                    }
                  }
                })
            }
            else if (accountDetails == "Dealer") {
              // need to check the parent account
              vm.StpVar = { "id": accountId, "text": Account_Name + "/" + SAP_Code};
              // Changes done by anuj on 26 Sep 23 for SAP Code
              ZOHO.CRM.API.getRecord({ Entity: "Accounts", RecordID: Distributor.id })
                  .then(function (response) {
                    console.error("account Module");
                    console.log(response);
                    SAP_Code = response.data[0].SAP_Code || "";
                    // 
                    vm.BtpVar = { "id": Distributor.id, "text": Distributor.name + "/" + SAP_Code};
                  })
              // vm.BtpVar = { "id": Distributor.id, "text": Distributor.name + "/" + SAP_Code};
              Billing_City_Nams = response.data[0].Billing_City_Nams;
              vm.locationShips = Billing_City_Nams;
            }
            else if (accountDetails == "Stockist") {
              vm.distributorTypeList = [];
              vm.BtpVar = { "id": accountId, "text": Account_Name + "/" + SAP_Code };
              myobject = { "text": Account_Name + "/" + SAP_Code, "id": accountId };
              vm.distributorTypeList.push(myobject);
              //conditon parent name = id and account type = dealer
              // var queryParams = "((Parent_Account:equals:"+accountId+")and(Account_Type:equals:Dealer))";
              // SAP Code updated change for account type == "Stockist" changed by Anuj on 20 Sep 23 on line no 1130 
              var queryParams = "((Parent_Account:equals:" + id + ")and(SAP_Code_Status:equals:Success))";
              await ZOHO.CRM.API.searchRecord({ Entity: "Accounts", Type: "criteria", Query: queryParams, page: 1, per_page: 100 })
                .then(function (response) {
                  console.error("account Module Distributor search");
                  console.log(response);
                  if (response.status !== 204) {
                    response.data.forEach(element => {
                      SAP_Code = element.SAP_Code;
                      text = element.Account_Name;
                      id = element.id;
                      myobject = { "text": text+"/"+SAP_Code, "id": id }
                      vm.distributorTypeList.push(myobject);

                    });
                  }
                })
            }
            else {
              swal({
                title: "Order Only Created For Dealer, Distributor, Stockist",
                text: "  ",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                buttons: {
                  // confirm: "OK",
                  // cancel: 'No'
                },
              })
              vm.show = "true";
              document.getElementById("transscreen").style.display = "block";
            }

            // need to write the project sale and stockist
            var buType = response.data[0].BU_Type;
          }
          else {
            swal({
              title: "Without SAP Code, Order Can't Create",
              text: "    ",
              icon: "warning",
              buttons: true,
              dangerMode: true,
              buttons: {
                // confirm: "OK",
                // cancel: 'No'
              },
            })
            vm.show = "true";
            document.getElementById("transscreen").style.display = "block";
          }
        })
    },
    async FunctionDistrubut(pageno, id) {
      //var queryParams = "((Parent_Account:equals:"+id+"))";
      var queryParams = "((Parent_Account:equals:" + id + ")and(SAP_Code_Status:equals:Success))";
      await ZOHO.CRM.API.searchRecord({ Entity: "Accounts", Type: "criteria", Query: queryParams, page: pageno, per_page: 100 })
        .then(function (response) {
          console.error("account Module Distributor search");
          console.log(response);

          if (response.status !== 204) {

            if (response.info.more_records) {
              vm.overallObject.push(response.data);
              // console.log("Overall object ",vm.overallObject);
              vm.FunctionDistrubut(response.info.page + 1, id)
            }
            else {
              // overallObject.forEach(element => {
              //   text = element.Account_Name;
              //   id = element.id;
              //   myobject = { "text": text, "id": id }
              //   vm.distributorTypeList.push(myobject);
              // });
              // Changes made by Anuj on 17 july 23
              for (i = 0; i < vm.overallObject[0].length; i++) {
                allobject = vm.overallObject[0];
                // console.log("All Object ",allobject);
                text = allobject[i].Account_Name;
                id = allobject[i].id;
                myobject = { "text": text+"/"+SAP_Code, "id": id }
                vm.distributorTypeList.push(myobject);
              }
              for (j = 0; j < response.data; j++) {
                text = response.data[i].Account_Name;
                id = response.data[i].id;
                myobject = { "text": text+"/"+SAP_Code, "id": id }
                vm.distributorTypeList.push(myobject);
              }
            }
          }
        })
    },
    searchOrc(search) {
      console.log(search);
      vm.productOptionList = [];
      console.log("coming in");
      if (search.length > 3) {
        console.log(rowID);
        console.log(search);
        var queryParams = "(((Name:starts_with:" + search + ")or(Material_Description:starts_with:" + search + ")))";
        ZOHO.CRM.API.searchRecord({ Entity: "Material_Master", Type: "criteria", Query: queryParams, page: 1, per_page: 100 })
          .then(function (response) {
            console.log(response);
            var parts = [];
            vm.productOptionList = [];
            if (response.status !== 204) {
              response.data.forEach(element => {
                console.log(element);
                var myOption = {};
                myOption.displayName = element.Name + " - " + element.Material_Description;
                myOption.name = element.Material_Description;
                myOption.id = element.id;
                parts.push(myOption)
                vm.productOptionList.push(myOption.displayName);
              });
              vm.productMainList[rowID] = parts;
              console.log(rowID);
              vm.$forceUpdate();
            }
          })
      }
    },
    validation(param = '') {
      console.log(vm.Mainobject);
      console.log("asdf")
      //in any felid is empty tell alert message based on field id.
      //check the main object isnull tell them to perfill and to stop
      // orderType: null,
      Validatation = true;
      if (!this.orderType) {
        swal({
          title: "",
          text: "Please Choose Sales Order Type",
          icon: "warning",
          button: "OK",
        });
        Validatation = false;
      }
      else if (!this.reasonType) {
        swal({
          title: "",
          // text: "Please Choose SO Reason Type",
          text: "Please Choose Customer Group 1",
          icon: "warning",
          button: "OK",
        });
        Validatation = false;
      }
      else if (!this.division) {
        swal({
          title: "",
          text: "Please Choose Division",
          icon: "warning",
          button: "OK",
        });
        Validatation = false;
      }
      else if (!this.plant) {
        swal({
          title: "",
          //text: "Please choose Plant",
          text: "Please choose Source Of Supply",
          icon: "warning",
          button: "OK",
        });
        Validatation = false;
      }
      else if (!this.BtpVar) {
        swal({
          title: "",
          text: "Please Choose Sold to party",
          icon: "warning",
          button: "OK",
        });
        Validatation = false;
      }
      else if (!this.StpVar) {
        swal({
          title: "",
          text: "Please choose Ship to party",
          icon: "warning",
          button: "OK",
        });
        Validatation = false;
      }
      else if (!this.incoTerm) {
        swal({
          title: "",
          text: "Please Choose Inco Term",
          icon: "warning",
          button: "OK",
        });
        Validatation = false;
      }
      else if (!this.pricelist) {
        swal({
          title: "",
          text: "Please Choose Price List",
          icon: "warning",
          button: "OK",
        });
        Validatation = false;
      }
      else if (!this.lorryType) {
        swal({
          title: "",
          text: "Please Choose Lorry Type",
          icon: "warning",
          button: "OK",
        });
        Validatation = false;
      }

      //sub form validation missing.
      if (JSON.stringify(vm.Mainobject) === '{}') {
        swal({
          title: "",
          text: "Please add one line item for sumbit the order",
          icon: "warning",
          button: "OK",
        });
        Validatation = false;
      }
      else {
        //if any line item  part was empty show color
        var ifempty = false;
        var QuantityEmpty = false;
        var cePriceEmpty = false;
        var TodEmpty = false;
        var listPriceEmpty = false;
        console.log(vm.Mainobject);
        for (key in vm.Mainobject) {
          if (vm.Mainobject[key].productId == null || vm.Mainobject[key].productId == '') {
            Validatation = false;
            ifempty = true;
          }
          else if (vm.Mainobject[key].orderQuantity == null || vm.Mainobject[key].orderQuantity == '' || vm.Mainobject[key].orderQuantity == 0) {
            Validatation = false;
            ifempty = true;
            QuantityEmpty = true;

            $("#alertQuantity_" + key).html("Quantity is Empty");
            vm.hideAlertQuantity();
          }
          else if (vm.Mainobject[key].cePrice == null || vm.Mainobject[key].cePrice == '' || vm.Mainobject[key].cePrice == 0) {
            if (param != "") {
              Validatation = false;
              ifempty = true;
              cePriceEmpty = true;
              $("#alertCePrice_" + key).html("Check CE Price");
              vm.hideAlertQuantity();
            }
          }
          else if (vm.Mainobject[key].price == null || vm.Mainobject[key].price == '' || vm.Mainobject[key].price == 0) {
            if (param != "") {
              if (vm.orderType == "ZFCO/SAMPLE SALES/FOC") {
                Validatation = true;
                ifempty = false;
                listPriceEmpty = false;
              }
              else {
                Validatation = false;
                ifempty = true;
                listPriceEmpty = true;
              }
            }
          }
          else if (vm.Mainobject[key].TOD == null || vm.Mainobject[key].TOD == '') {
            Validatation = false;
            ifempty = true;
            TodEmpty = true;
            $("#alertTOD_" + key).html("TOD is Empty,Please Check");
            vm.hideAlertQuantity();
          }
          else if (vm.Mainobject[key].TOD != "") {

            if (vm.division == "10/ROOFING") {
              if (parseInt(vm.Mainobject[key].TOD) >= 10) {
                Validatation = false;
                ifempty = true;
                TodEmpty = true;
                $("#alertTOD_" + key).html("TOD is Greater Than 10");
                vm.hideAlertQuantity();
              }

            }
          }

        }


        if (ifempty == true) {
          if (QuantityEmpty) {
            swal({
              title: "",
              text: "Line Item Quantity is Empty, Please Check",
              icon: "warning",
              button: "OK",
            });
          }
          else if (cePriceEmpty) {
            swal({
              title: "",
              text: "Line Item CE Price, Please Check",
              icon: "warning",
              button: "OK",
            });
          }
          else if (TodEmpty) {
            swal({
              title: "",
              text: "Line Item TOD is Empty, Please Check",
              icon: "warning",
              button: "OK",
            });
          }
          else if (listPriceEmpty) {
            swal({
              title: "",
              text: "List Price is Empty or Zero, Please check",
              icon: "error",
              button: "OK",
            });
          }
          else {
            swal({
              title: "",
              text: "Line Item details are Empty, Please Check",
              icon: "warning",
              button: "OK",
            });
          }
        }
      }

      if (Validatation == true) {
        vm.show = "true";
        document.getElementById("transscreen").style.display = "block";

        console.log("calling check validation");
        this.CheckValidate(true, a = param);
      }
    },
    hideAlertQuantity() {
      setTimeout(() => {
        for (key in vm.Mainobject) {
          $("#alertQuantity_" + key).html("")
          $("#alertCePrice_" + key).html("")
          $("#alertTOD_" + key).html("")
        }
      }, 3000)

    },
    clearSearchDist() {
      // vm.distributorTypeList = [];
      // vm.contactList = [];
      // vm.plantList = [];
    },
    searchLineItemWithFilter(item) {
      console.log(item);
      vm.filterMaterial = null;
      vm.searchFilterItem = item;
      vm.roofMatGroup = null;
      vm.roofExtMatGroup = null;
      vm.filterMaterial - null;
      vm.filterQuantity = null;
      vm.filterCePrice = null;
      vm.filterTodLineItem = null;
      vm.$forceUpdate();
    },
    searchExtMaterial(parameter) {
      if (parameter == "PLANT") {

        vm.Mainobject = {};
        vm.rwoCount = 0;
        rowId = 1;
      }
      //getting header level
      console.log(parameter);
      if (vm.LoginUserType == "Roofing") {
        divisioncode = 10;
      }
      else if (vm.LoginUserType == "BP") {
        divisioncode = 20;
      }

      if (parameter == "group") {
        vm.pageCall = 1;
        vm.roofExtMatGroupList = [];
        vm.roofExtMatGroup = null;
        vm.filterMaterial = null;
        vm.partFilterList = [];
        vm.testObject = [];

        plant = vm.plant.split("/");
        // var req_data = {
        //   "parameters": { "select_query": "SELECT Ext_Material_Group from Material_Master where  Plant_Code='" + plant[0] + "' and (Division_Code='" + vm.filter + "' and Material_Group='" + this.roofMatGroup + "') group by Ext_Material_Group" },
        //   "method": "POST",
        //   "url": "https://www.zohoapis.in/crm/v3/coql"
        // }

        // ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
        //   .then(function (response) {
        //     console.error("get material extented");
        //     console.log(response);
        //     if (response.code == "SUCCESS") {
        //       if (response.details.status == "true") {
        //         if (response.details.statusMessage.data) {
        //           vm.roofExtMatGroupList = [];
        //           vm.roofExtMatGroup = null;
        //           for (key in response.details.statusMessage.data) {
        //             console.log(key);
        //             var materialGroup = response.details.statusMessage.data[key].Ext_Material_Group;
        //             console.log(materialGroup);
        //             vm.roofExtMatGroupList.push(materialGroup);
        //           }
        //           vm.$forceUpdate();
        //         }

        //       }
        //     }
        //   });

        console.log("step 3")
        requestDataForSAP = {
          "Plant_Code": plant[0],
          "Division_Code": vm.filter,
          "Material_Group": this.roofMatGroup,
        }
        var func_name = "roofExtMatGroupList_1";
        var req_data = {
          "arguments": JSON.stringify(requestDataForSAP)
        };
        ZOHO.CRM.FUNCTIONS.execute(func_name, req_data)
          .then(function (response) {
            console.error("response");
            console.error(response);
            if (response.code == "success") {
              if (response.details.output) {
                dataDetails = JSON.parse(response.details.output)
                vm.roofExtMatGroupList = [];
                vm.roofExtMatGroup = null;
                for (key in dataDetails.data) {
                  console.log(key);
                  if (dataDetails.data[key].Ext_Material_Group) {
                    var materialGroup = dataDetails.data[key].Ext_Material_Group;
                    console.log(materialGroup);
                    vm.roofExtMatGroupList.push(materialGroup);
                  }

                }
              }
            }
          })



      }
      else if (parameter == "extGroup") {

        if (vm.pageCall == 1) {
          vm.partFilterList = [];
          vm.filterMaterial = null;
          vm.testObject = [];
        }

        if (this.roofExtMatGroup == null || this.roofMatGroup == null) {
          vm.partFilterList = [];
          vm.filterMaterial = null;
          vm.testObject = [];
        }

        console.log(vm.testObject);

        plant = vm.plant.split("/");
        var queryParams = "((Division_Code:equals:" + vm.filter + ")and(Material_Group:equals:'" + this.roofMatGroup + "')and(Ext_Material_Group:equals:'" + this.roofExtMatGroup + "')and(Plant_Code:equals:'" + plant[0] + "'))";
        console.log(queryParams);

        ZOHO.CRM.API.searchRecord({ Entity: "Material_Master", Type: "criteria", Query: queryParams, page: vm.pageCall, per_page: 100 })
          .then(function (response) {
            console.log(response);
            console.log(vm.testObject);
            // vm.productOptionList = [];
            // vm.filterMaterial = null;
            if (response.status !== 204) {
              if (response.info.more_records == true) {
                response.data.forEach(element => {
                  vm.testObject.push(element)
                })
                vm.pageCall = vm.pageCall + 1;
                vm.searchExtMaterial("extGroup");
              }
              else {
                vm.partFilterList = [];
                response.data.forEach(element => {
                  vm.testObject.push(element)
                })

                vm.testObject.forEach(element => {
                  var myOption = {};
                  myOption.displayName = element.Material_Description + " - " + element.Name;
                  myOption.name = element.Material_Description;
                  myOption.id = element.id;
                  myOption.materialCode = element.Name;
                  vm.partFilterList.push(myOption);
                })
                vm.pageCall = 1;
                vm.$forceUpdate();
              }
            }
          })
      }
      else if (parameter == "plantCode") {
        vm.filter = vm.LoginUserType;
        if (vm.division == "10/ROOFING") {
          vm.filter = "10";
        }
        else if (vm.division == "20/BOARDS") {
          vm.filter = "20";
        }
        else if (vm.division == "30/PANEL") {
          vm.filter = "30";
        }
        plant = vm.plant.split("/");
        // var req_data = {
        //   "parameters": { "select_query": "SELECT Material_Group from Material_Master where Plant_Code='" + plant[0] + "' and Division_Code='" + vm.filter + "' group by Material_Group" },
        //   "method": "POST",
        //   "url": "https://www.zohoapis.in/crm/v3/coql" //https://www.zohoapis.com/crm/v3/coql
        // }

        // ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
        //   .then(function (response) {
        //     console.error("get material extented");
        //     console.log(response);
        //     if (response.code == "SUCCESS") {
        //       if (response.details.status == "true") {
        //         if (response.details.statusMessage.data) {
        //           vm.roofMatGroupList = [];
        //           for (key in response.details.statusMessage.data) {
        //             var materialGroup = response.details.statusMessage.data[key].Material_Group;
        //             vm.roofMatGroupList.push(materialGroup);
        //           }
        //         }
        //         else {
        //           if (vm.plant) {
        //             swal({
        //               title: "Plant " + vm.plant + " is not having Material Group and Extra Material Group",
        //               text: " ",
        //               icon: "warning",
        //               buttons: true,
        //               dangerMode: true,
        //               buttons: {
        //                 // confirm: "OK",
        //                 // cancel: 'No'
        //               },
        //             })
        //             vm.plant = "";
        //           }
        //         }
        //       }

        //     }
        //   });

        console.log("step 3")
        requestDataForSAP = {
          "Plant_Code": plant[0],
          "Division_Code": vm.filter,
          "Material_Group": null,
        }
        var func_name = "roofExtMatGroupList_1";
        var req_data = {
          "arguments": JSON.stringify(requestDataForSAP)
        };
        ZOHO.CRM.FUNCTIONS.execute(func_name, req_data)
          .then(function (response) {
            console.error("response");
            console.error(response);
            if (response.code == "success") {
              if (response.details.output) {
                dataDetails = JSON.parse(response.details.output)
                vm.roofMatGroupList = [];
                for (key in dataDetails.data) {
                  if (dataDetails.data[key].Material_Group) {
                    var materialGroup = dataDetails.data[key].Material_Group;
                    vm.roofMatGroupList.push(materialGroup);
                  }
                }
              }
            }
          })
      }
      else if (parameter = "PLANT") {
        if (vm.division == "10/ROOFING") {
          vm.filter = "10";
        }
        else if (vm.division == "20/BOARDS") {
          vm.filter = "20";
        }
        else if (vm.division == "30/PANEL") {
          vm.filter = "30";
        }

        // var req_data = {
        //   "parameters": { "select_query": "SELECT Plant_Code from Material_Master where Plant_Code!='' and Division_Code='"+vm.filter+"' group by Plant_Code" },
        //   "method": "POST",
        //   "url": "https://www.zohoapis.in/crm/v3/coql" //https://www.zohoapis.com/crm/v3/coql
        // }

        // ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
        // .then(function (response) {
        //     console.error("plant Code");
        //     console.log(response);
        //     if(response.code=="SUCCESS")
        //     {
        //       if(response.details.status=="true")
        //       {
        //         if(response.details.statusMessage.data)
        //         {
        //           vm.plantList = [];
        //           for (key in response.details.statusMessage.data)
        //           {
        //               var Plant_Code = response.details.statusMessage.data[key].Plant_Code;
        //               vm.plantList.push(Plant_Code);
        //           }
        //         }
        //       }
        //     }
        // });
        // var req_data = {
        //   "parameters": { "select_query": "SELECT Plant_Code,Plant_Name from Material_Master where Plant_Code!='' and Division_Code='" + vm.filter + "' group by Plant_Code,Plant_Name" },
        //   "method": "POST",
        //   "url": "https://www.zohoapis.in/crm/v3/coql" //https://www.zohoapis.com/crm/v3/coql
        // }

        // ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
        //   .then(function (response) {
        //     console.error("plant Code");
        //     console.log(response);
        //     if (response.code == "SUCCESS") {
        //       if (response.details.status == "true") {
        //         if (response.details.statusMessage.data) {
        //           for (key in response.details.statusMessage.data) {
        //             var Plant_Code = response.details.statusMessage.data[key].Plant_Code;
        //             var Plant_Name = response.details.statusMessage.data[key].Plant_Name;
        //             vm.plantList.push(Plant_Code + "/ " + Plant_Name);
        //           }
        //         }
        //       }
        //     }
        //   });
        console.error("step 1");
        requestDataForSAP = {
          "Division_Code": vm.filter
        }
        var func_name = "PlanCodeDetails_1";
        var req_data = {
          "arguments": JSON.stringify(requestDataForSAP)
        };
        ZOHO.CRM.FUNCTIONS.execute(func_name, req_data)
          .then(function (response) {
            console.error("response");
            console.error(response);
            if (response.code == "success") {
              if (response.details.output) {
                dataDetails = JSON.parse(response.details.output)
                for (key in dataDetails.data) {
                  var Plant_Code = dataDetails.data[key].Plant_Code;
                  var Plant_Name = dataDetails.data[key].Plant_Name;
                  vm.plantList.push(Plant_Code + "/ " + Plant_Name);
                }
              }
            }
          })
      }
    },
    searchFilterUpdate() {
      $("#filterAlert").html('');
      if (vm.filterMaterial == null) {
        $("#filterAlert").html("Please Choose Material code");
        setTimeout(() => {
          $("#filterAlert").html('')
        }, 3000);
      }
      else if (vm.filterQuantity == null || vm.filterQuantity == "e") {
        vm.filterQuantity = 1;
        $("#filterAlert").html("Please Enter The Quantity");
        setTimeout(() => {
          $("#filterAlert").html('')
        }, 3000);
      }
      else if (vm.filterCePrice == null || vm.filterCePrice == "e") {
        vm.filterCePrice = 1;
        $("#filterAlert").html("Please Enter The CE Price");
        setTimeout(() => {
          $("#filterAlert").html('')
        }, 3000);
      }
      else if (vm.filterTodLineItem == null || vm.filterTodLineItem === "") {
        vm.filterTodLineItem = 0;

        $("#filterAlert").html("Please Enter The TOD");
        setTimeout(() => {
          $("#filterAlert").html('')
        }, 3000);
      }
      else {
        //update in filter value
        //locking for a duplicate value if yes stop here or send to order line item:
        duplicate = false;
        for (const [key, value] of Object.entries(vm.Mainobject)) {
          //null check because after the close icon in line item its call the function
          console.log(value.productId)
          console.log(vm.filterMaterial.id);

          if (value.productId == vm.filterMaterial.id) {
            duplicate = true;
            break
          }
        }
        if (duplicate == false) {
          vm.Mainobject[vm.searchFilterItem].partList = [];
          var object = { "displayName": vm.filterMaterial.displayName, "id": vm.filterMaterial.id, "name": vm.filterMaterial.name, "materialCode": vm.filterMaterial.materialCode };

          vm.Mainobject[vm.searchFilterItem].part = object;
          vm.Mainobject[vm.searchFilterItem].partList.push(object);
          vm.Mainobject[vm.searchFilterItem].productId = vm.filterMaterial.id;
          vm.Mainobject[vm.searchFilterItem].descriptionName = vm.filterMaterial.name;
          vm.Mainobject[vm.searchFilterItem].orderQuantity = vm.filterQuantity;
          vm.Mainobject[vm.searchFilterItem].cePrice = vm.filterCePrice;
          vm.Mainobject[vm.searchFilterItem].TOD = vm.filterTodLineItem;
          //$("#row_qun"+vm.searchFilterItem).val(vm.filterQuantity);

          vm.roofExtMatGroupList = [];
          vm.roofExtMatGroup = null;
          vm.roofMatGroup = null;
          vm.filterQuantity = null;
          vm.searchFilterItem = null;
          vm.filterMaterial = null;
          vm.filterTodLineItem = null;
          vm.filterCePrice = null;
          vm.partFilterList = [];
          vm.testObject = [];
          vm.$forceUpdate();
          $("#searchLineItem .close").click()
        }
        else {
          $("#filterAlert").html("Duplicate Material Found Please Check");
        }
      }
    },
    filterIncoTerm() {
      $("#pricelist").css("display", "block");
      $("#pricelistLabel").css("display", "block");
      vm.lorryType = null;
      console.error("inco term");

      console.log(vm.incoTerm);
      if (vm.incoTerm == "FBC/ Freight Credit-for-DOM") {
        vm.pricelist = "10/FC STOCKIEST";
        vm.lorryType = "Z000/FRIEGHT CREDIT";
      }
      else if (vm.incoTerm == "FBX/ EX - Factory/Depot") {
        vm.pricelist = "11/FC STOCKIEST 2";
        vm.lorryType = "Z001/EX WORKS";
      }
      else {
        vm.pricelist = "";
        vm.pricelist = "";
      }
    },
    selectAddress() {
      // pre fill the loacation data
      // get record 
      accountIdModule = vm.StpVar.id;
      ZOHO.CRM.API.getRecord({ Entity: "Accounts", RecordID: accountIdModule })
        .then(function (response) {
          console.log(response);
          if (response.status != 204) {
            vm.locationShips = null;
            Billing_City_Nams = response.data[0].Billing_City_Nams
            vm.locationShips = Billing_City_Nams;
          }
        });
    }
  }
});

// vm.addItem();
ZOHO.embeddedApp.on("PageLoad", function (data) {
  console.log("PageLoad" + data);
  console.log(JSON.stringify(data));
  vm.dealerid = data.EntityId[0];


  //console.log(vm.dealerid);
  //  ZOHO.CRM.API.getRecord({Entity:"Configurations",RecordID:"306279000003401412"}).then(function(response){
  //    vm.incoTermList = JSON.parse(response.data[0].Option.replace(/\\/g, ''))
  //  })
  //  ZOHO.CRM.API.getRecord({Entity:"Configurations",RecordID:"306279000003401387"}).then(function(response){
  //    vm.Ordertypelist = JSON.parse(response.data[0].Option.replace(/\\/g, ''))
  //  })
  //  ZOHO.CRM.API.getRecord({Entity:"Configurations",RecordID:"306279000003401392"}).then(function(response){
  //    vm.reasonTypeList = JSON.parse(response.data[0].Option.replace(/\\/g, ''))
  //  })
  //  ZOHO.CRM.API.getRecord({Entity:"Configurations",RecordID:"306279000003401397"}).then(function(response){
  //    vm.divisionList = JSON.parse(response.data[0].Option.replace(/\\/g, ''))
  //  })
  //  ZOHO.CRM.API.getRecord({Entity:"Configurations",RecordID:"306279000003401402"}).then(function(response){
  //    vm.priceMasterList = JSON.parse(response.data[0].Option.replace(/\\/g, ''))
  //  })
  //  ZOHO.CRM.API.getRecord({Entity:"Configurations",RecordID:"306279000003401407"}).then(function(response){
  //    vm.lorryTypeList = JSON.parse(response.data[0].Option.replace(/\\/g, ''))
  //  })

  var queryParams = "((Name:equals:Order Management))";

  ZOHO.CRM.API.searchRecord({ Entity: "Configurations", Type: "criteria", Query: queryParams, page: 1, per_page: 100 })
    .then(function (response) {

      console.log(response);
      if (response.status !== 204) {
        //  vm.distributorTypeList = [];
        response.data.forEach(element => {
          text = element.Pick_List_2;
          if (text == "incoTermList") {
            vm.incoTermList = JSON.parse(element.Option.replace(/\\/g, ''))
          }
          else if (text == "lorryTypeList") {
            vm.lorryTypeList = JSON.parse(element.Option.replace(/\\/g, ''))
          }
          else if (text == "priceMasterList") {
            vm.priceMasterList = JSON.parse(element.Option.replace(/\\/g, ''))
          }
          else if (text == "divisionList") {
            //vm.divisionList = JSON.parse(element.Option.replace(/\\/g, ''))
          }
          else if (text == "reasonTypeList") {
            vm.reasonTypeList = JSON.parse(element.Option.replace(/\\/g, ''))
          }
          else if (text == "Ordertypelist") {
            vm.Ordertypelist = JSON.parse(element.Option.replace(/\\/g, ''))
          }
        });
      }
    })

  var queryParams = "((Name:equals:SanBoxProductionURL))";

  ZOHO.CRM.API.searchRecord({ Entity: "Configurations", Type: "criteria", Query: queryParams, page: 1, per_page: 100 })
    .then(function (response) {

      console.log(response);
      if (response.status !== 204) {
        //  vm.distributorTypeList = [];
        vm.URLDirect = response.data[0].onboard_URL;
      }
    })

  if (data.Entity) {
    vm.moduleName = data.Entity;
    vm.modulePrefill(vm.moduleName, data.EntityId[0]);
  }

})

ZOHO.embeddedApp.init().then(function (data) {

  console.error("data init")
  console.log(data);

  accountIdModule = vm.dealerid;
  // vm.addItem();
  console.error("init data");
  console.log(data);
  vm.show = "true";
  document.getElementById("transscreen").style.display = "block";


  ZOHO.CRM.CONFIG.getCurrentUser().then(function (data) {
    console.error("Current user");

    console.log(data);
    vm.LoginUserID = data.users[0].id;

    ZOHO.CRM.API.getUser({ ID: vm.LoginUserID })
      .then(function (specificUserdata) {
        console.error("specificUserdata");
        console.log(specificUserdata);

        vm.LoginUserType = specificUserdata.users[0].Type;
        vm.currentLoginRole = specificUserdata.users[0].role.name;
        if (vm.LoginUserType == "Roofing") {
          //  $("#BPMaterial").css("display","none");

          //   vm.divisionList = ["10/ROOFING"];
          //   vm.division = "10/ROOFING";

        }
        else if (vm.LoginUserType == "BP") {
          //  $("#BPMaterial").css("display","block");

          //   vm.divisionList = ["20/BOARDS","30/PANEL"];
          //   vm.division = "20/BOARDS";
        }
        else {
          swal({
            backdrop: true,
            allowOutsideClick: false,
            title: "PEB User Can't Create a Order",
            text: " ",
            icon: "error",
            buttons: true,
            dangerMode: true,
            buttons: {
              // confirm: "Ok",
              // cancel: 'No'
            },
          })
            .then((e) => {
              vm.show = "true";
              document.getElementById("transscreen").style.display = "block";
              ZOHO.CRM.UI.Popup.closeReload();
              //window.open("https://crmplus.zoho.in/everestindustrieslimited/index.do/cxapp/crm/org60012502525/tab/Accounts/"+vm.dealerid,"_system");
              window.open(vm.URLDirect + "Accounts/" + vm.dealerid, "_parent");
            });
        }

        // if(vm.division=="10/ROOFING")
        // {
        //   vm.filter = "10";
        // }
        // else if(vm.division=="20/BOARDS")
        // {
        //   vm.filter = "20";
        // }
        // else if(vm.division=="30/PANEL")
        // {
        //   vm.filter = "30";
        // }

        // var req_data = {
        //   "parameters": { "select_query": "SELECT Plant_Code,Plant_Name from Material_Master where Plant_Code!='' and Division_Code='"+vm.filter+"' group by Plant_Code,Plant_Name" },
        //   "method": "POST",
        //   "url": "https://www.zohoapis.in/crm/v3/coql" //https://www.zohoapis.com/crm/v3/coql
        // }

        // ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
        // .then(function (response) {
        //     console.error("plant Code");
        //     console.log(response);
        //     if(response.code=="SUCCESS")
        //     {
        //       if(response.details.status=="true")
        //       {
        //         if(response.details.statusMessage.data)
        //         {
        //           for (key in response.details.statusMessage.data)
        //           {
        //               var Plant_Code = response.details.statusMessage.data[key].Plant_Code;
        //               var Plant_Name = response.details.statusMessage.data[key].Plant_Name;
        //               vm.plantList.push(Plant_Code+"/ "+Plant_Name);
        //           }
        //         }
        //       }
        //     }
        // });

        //  var req_data = {
        //    "parameters": { "select_query": "SELECT Material_Group from Material_Master where Division='"+vm.LoginUserType+"' group by Material_Group" },
        //    "method": "POST",
        //    "url": "https://www.zohoapis.in/crm/v3/coql" //https://www.zohoapis.com/crm/v3/coql
        //  }

        //  ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
        //  .then(function (response) {
        //      console.error("get material extented");
        //      console.log(response);
        //      if(response.code=="SUCCESS")
        //      {
        //        if(response.details.status=="true")
        //        {
        //          if(response.details.statusMessage.data)
        //          {
        //            vm.roofMatGroupList = [];
        //            for (key in response.details.statusMessage.data)
        //            {
        //                var materialGroup = response.details.statusMessage.data[key].Material_Group;
        //                vm.roofMatGroupList.push(materialGroup);
        //            }
        //          }
        //        }
        //      }
        //  });

        //get configuration value
        console.error("configuration");
        var queryParams = "((Name:equals:Order Management)and(Product:equals:" + vm.LoginUserType + "))";

        ZOHO.CRM.API.searchRecord({ Entity: "Configurations", Type: "criteria", Query: queryParams, page: 1, per_page: 100 })
          .then(function (response) {
            console.log(response);
            if (response.status != 204) {
              response.data.forEach(element => {
                console.log(element);

                if (element.Configuration == "L1 Approve") {
                  vm.l1_role = element.URL;
                  if (vm.LoginUserType == "BP") {
                    //Percentage_Value
                    vm.l1Approve = element.Percentage_Value
                  }
                  else {
                    vm.l1Approve = element.Value_in_Rupees
                  }
                }
                else if (element.Configuration == "L2 Approve") {
                  vm.l2_role = element.URL;
                  if (vm.LoginUserType == "BP") {
                    //Percentage_Value
                    vm.l2Approve = element.Percentage_Value
                  }
                  else {
                    vm.l2Approve = element.Value_in_Rupees
                  }
                }
                else if (element.Configuration == "L3 Approve") {
                  vm.l3_role = element.URL;
                  if (vm.LoginUserType == "BP") {
                    //Percentage_Value
                    vm.l3Approve = element.Percentage_Value
                  }
                  else {
                    vm.l3Approve = element.Value_in_Rupees
                  }
                }
              });
            }
          });

        // var req_data = {
        //   "parameters": { "select_query": "SELECT Account_Name,id from Accounts where SAP_Code!=''and BU_Type=" + vm.LoginUserType },
        //   "method": "POST",
        //   "url": "https://www.zohoapis.in/crm/v3/coql" //https://www.zohoapis.com/crm/v3/coql
        // }

        // ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
        //   .then(function (response) {
        //     console.log(response);
        //     if (response.code == "SUCCESS") {
        //       if (response.details.status == "true") {
        //         if (response.details.statusMessage.data) {
        //           vm.orcList = [];
        //           for (key in response.details.statusMessage.data) {
        //             text = response.details.statusMessage.data[key].Account_Name;
        //             id = response.details.statusMessage.data[key].id;
        //             myobject = { "text": text, "id": id }
        //             vm.orcList.push(myobject);
        //           }
        //         }
        //       }
        //     }
        //   });

        //step 1
        console.error("step 1");
        requestDataForSAP = {
          "BU_Type": vm.LoginUserType
        }
        var func_name = "orcDetailsPOM_1";
        var req_data = {
          "arguments": JSON.stringify(requestDataForSAP)
        };
        // ORC Changes done by Anuj on 04-08-2023
        // Change:SAP_Code is added in API requsest alongwith BTP Account name in ORC list
        ZOHO.CRM.FUNCTIONS.execute(func_name, req_data)
          .then(function (response) {
            console.error("response");
            console.error(response);
            if (response.code == "success") {
              if (response.details.output) {
                dataDetails = JSON.parse(response.details.output)
                vm.orcList = [];
                for (key in dataDetails.data) {
                  text = dataDetails.data[key].Account_Name;
                  id = dataDetails.data[key].id;
                  sap_code = dataDetails.data[key].SAP_Code;
                  myobject = { "text": text + "/ "+ sap_code, "id": id }
                  vm.orcList.push(myobject);
                }
              }
            }
          })

      })
  });


  //orc prefill
  console.error("ORC Prefill");
  //  var queryParams = "(GST_Verification_Status:equals:Success)"
  //  ZOHO.CRM.API.searchRecord({ Entity:"Accounts", Type: "criteria", Query: queryParams, page: 1, per_page: 100 })
  //    .then(function (response) {
  //      console.log(response);
  //      if (response.status !== 204) {
  //        vm.orcList = [];
  //        response.data.forEach(element => {
  //          text = element.Account_Name;
  //          id = element.id;
  //          myobject = {"text":text,"id":id}
  //          vm.orcList.push(myobject);
  //        });
  //        // vm.$forceUpdate();
  //      }
  //    })


  // source of supply pre fill


  vm.$forceUpdate();
  ZOHO.CRM.UI.Resize({ height: "100%", width: "100%" }).then(function (data) {


  })
});