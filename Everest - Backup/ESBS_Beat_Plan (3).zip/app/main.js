
conn_name = "modulesall";
// Logged-in user's original BU (e.g. "PEB", before it is mapped to "BP"); Channel Partner "Name of ..." dropdowns only show Accounts with this BU_Type
UserBUType = null;
// Channel Partner Types that have their own dedicated "Name of ..." dropdown; every other type uses the shared OtherPartner dropdown
DedicatedPartnerTypes = ["Distributor", "Dealer", "Stockist", "Sub Dealer/Retailer", "Direct Customer", "EPC Contractor", "Architect/Consultant"];
vm = new Vue({
  el: "#app",

  components: { "v-select": VueSelect.VueSelect, Multiselect: window.VueMultiselect.default },
  data() {
    return {
      currentday: null,
      IntervalStart:null,
      IntervalEnd:null,
      ErrorMsg: null,
      showErrorMsg: false,
      AccountNameForOthers: null,
      Datevalue: null,
      showDel: false, 
      calView: null,
      redirurl: null,
      Weeknumber: null,
      defaultViewBu: null,
      CustomBtn: false,
      Datemin: null,
      Datemax: null,
      Meet: null,
      MeetOptions: [],
      InfluencerType: null,
      InfluencerOptions: [],
      Trainingtype: null,
      TrainingtypeOptions: ["Kaushal", "Pehchan"],
      title: null,
      showload: false,
      showplan: false,
      showplanrange: false,
      Projectsale: null,
      Region: null,
      Regionoptions: [],
      StartDate: null,
      EndDate: null,
      rejflag: 0,
      Adhocbtn: false,
      userstate: null,
      //New Popup fields
      Activity: null,
      Visit: null,
      typeofsitevisit: null,
      Distributor: null,
      SubDealerRetailer: null,
      Dealer: null,
      Stockist: null,
      DirectCustomer: null,
      ECPContractor: null,
      ArchitectConsultant: null,
      OtherPartner: null,
      PlannedSalesPlan: null,
      Planowner1: null,
      NameeofInfluencer: null,
      PurposeOfVisitInfluencer: null,
      NameofFactory: null,
      PurposeofVisitFactory: null,
      NameofChannelPartnerPehchan: null,
      NoofAttendants: null,
      NameofChannelPartnerKaushal: null,
      NameofKeyaccountIHP: null,
      NameofCompetitor: null,
      NameofKeyaccountSite: null,
      OpportunityName: null,
      Typeofactivity: null,
      Typeofdrive: null,
      NameofAccountComplaints: null,
      ComplaintID: null,
      Approvercomments: null,
      Redflag: null,
      Orangeflag: null,
      MeetingType: null,

      role: null,
      leavewfhlist: [],
      TypeOfEvent: null,
      Location: null,
      Description: null,
      Mode: null,
      todayweek: null,
      //picklist
      MeetingTypeOptions: ["Regular", "Ad hoc"],
      ModeOptions: ["Virtual", "Physical"],
      TypeOfEventOptions: [],
      ActivityOptions: [],
      VisitOptions: ["Direct Customer", "EPC Contractor", "Architect/Consultant", "End-User", "Consultant", "Architect", "Infra House/EPC", "Project Sale", "Contractor/Project Associate", "OEM", "Builder", "Installer", "Influencers", "Contractor", "Govt Dept", "Govt ( Railways/ PSU", "PEB Contractor", "Export/Import", "Distributor", "MES"],
      DealerOptions: [],
      StockistOptions: [],
      SubDealerRetailerOptions: [],
      ProjectsaleOptions: [],
      DistributorOptions: [],
      DirectCustomerOptions: [],
      ECPContractorOptions: [],
      ArchitectConsultantOptions: [],
      OtherPartnerOptions: [],
      NameofCompetitorOptions: [],
      NameeofInfluenceroptions: [],
      typeofsitevisitoptions: ["Warehouse",
        "Customer Factory",
        "Customer Plant",
        "Data Centres",
        "Solar Project",
        "Others"],
      PurposeOfVisitInfluenceroptions: ["Lead Generation", "Ongoing discussion/Follow-up"],
      NameofFactoryoptions: [],
      NameofChannelPartnerPehchanoptions: [],
      NameofChannelPartnerKaushaloptions: [],
      NameofKeyaccountIHPoptions: [],
      NameofKeyaccountSiteoptions: [],
      OpportunityNameoptions: [],
      Typeofactivityoptions: [],
      Typeofdriveoptions: ["Commercial", "Consultant Empaneling", "Key Account"],
      NameofAccountComplaintsoptions: [],
      ComplaintIDoptions: [],
      Holidayevents: [],
      //Popup Option
      // FactoryVisitOptions: ["a", "b", "c", "d", "e"],
      // InfluencersOptions: [],
      // ContactsOptions: [],
      // ProspectNameOptions: [],
      // InfluencerNameOptions: [],

      //Popup Buttons
      savebutton: false,
      updatebutton: false,
      updatebutton1: false,

      //datapicker
      monyear: null,
      BU: null,
      //testing
      // testing: null,



      //Status Fields
      Plan: null,
      PlanOptions: ["My Plan", "My Approval"],
      PendingApproval: null,
      PendingApprovalOptions: [],


      Planrange: null,
      PlanrangeOptions: ["First Half", "Second Half"],





      thisuser: null,
      CurrentUser: null,
      PlanApprovalId: null,
      owner: null,



      //plan approvsl
      Status: null,
      //show/hide
      showModal: false,
      validated: false,




      calEvent: null,
      BeatPlanId: null,
      ZohoAcc: null,
      ZohoCon: null,
      Colour: null,






    };
  }, watch: {
    async Activity(newvalue, oldvalue) {




      vm.Visit = null;
      vm.Trainingtype = null;
      vm.AccountNameForOthers = null;
      vm.PlannedSalesPlan = null;
      vm.NameeofInfluencer = null;
      vm.NameofCompetitor = null;
      vm.PurposeOfVisitInfluencer = null;
      vm.NameofFactory = null;
      vm.PurposeofVisitFactory = null;
      vm.NameofChannelPartnerPehchan = null;
      vm.NoofAttendants = null;
      vm.NameofChannelPartnerKaushal = null;
      vm.NameofKeyaccountIHP = null;
      vm.NameofKeyaccountSite = null;
      vm.OpportunityName = null;
      vm.Typeofactivity = null;
      vm.Typeofdrive = null;
      vm.NameofAccountComplaints = null;
      vm.ComplaintID = null;
      vm.Approvercomments = null;
      vm.Redflag = null;
      vm.Orangeflag = null;

      vm.VisitOptions = ["Direct Customer", "EPC Contractor", "Architect/Consultant", "End-User", "Consultant", "Architect", "Infra House/EPC", "Project Sale", "Contractor/Project Associate", "OEM", "Builder", "Installer", "Influencers", "Contractor", "Govt Dept", "Govt ( Railways/ PSU", "PEB Contractor", "Export/Import", "Distributor", "MES"];

      if (newvalue == 'Influencer Visit') {
        // moduleName = "Accounts";
        // criteria = "(Account_Type:equals:Influencers) and (Owner:equals:" + vm.CurrentUser + ")";
        // var flag = 1;
        // var i = 1;
        // let arr1 = [];
        // while (flag == 1) {
        //   await ZOHO.CRM.API.searchRecord({ Entity: moduleName, Type: "criteria", Query: criteria, per_page: 200, page: i })
        //     .then(async function (data) {
        //       console.log(data);
        //       if (data.info.more_records == false) {
        //         flag = 0;
        //       } else {
        //         i++;
        //       }
        //       arr2 = data.data;
        //       arr1 = arr1.concat(arr2);
        //     })
        // }
        // arr1.forEach(element => {
        //   element.AccPicklistName = element.Account_Name + " / " + element.id;
        // });
        // console.log(arr1)
        // vm.NameeofInfluenceroptions = arr1;
      } else if (newvalue == 'Factory or Depot Visit') {
        var req_data = {
          "parameters": { "select_query": "SELECT Plant_Code,Plant_Name from Material_Master where Plant_Code!='' group by Plant_Code,Plant_Name" },
          "method": "POST",
          "url": "https://www.zohoapis.in/crm/v5/coql"
        }

        var conn_name = "modulesall";
        await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
          .then(async function (data) {
            // console.log(data)


            let arr3 = data.details.statusMessage.data;
            // console.log(arr3);
            let arr8 = [];
            arr3.forEach(async element => {
              if (element.Plant_Name) {

                element.AccPicklistName = "" + element.Plant_Code + "/ " + element.Plant_Name;
                arr8.push(element)
              }
              // console.log(element)
            });
            console.log(arr8);
            vm.NameofFactoryoptions = arr8;
          })
      } else if (newvalue == 'Complaints Redressal' || newvalue == 'Site Visit' || newvalue == 'IHP') {
        let flag = 1;
        let i = 1;
        let arr3 = [];
        // while (flag == 1) {
        console.log(vm.CurrentUser)
        // Previous Owner-restricted preload (only showed Accounts owned by the current user - kept for reference):
        // let selectQuery = "SELECT Account_Name from Accounts where (Owner=" + vm.CurrentUser + ") and (BU_Type='" + vm.BU + "') LIMIT " + i + ",200";
        let selectQuery = "SELECT Account_Name from Accounts where (BU_Type='" + vm.BU + "') LIMIT " + i + ",200";
        console.log("[BeatPlan] IHP/Complaints/Site/Others preload query:", selectQuery);
        var req_data = {
          "parameters": { "select_query": selectQuery },
          "method": "POST",
          "url": "https://www.zohoapis.in/crm/v5/coql"
        }

        var conn_name = "modulesall";

        await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
          .then(async function (data) {
            console.log("[BeatPlan] IHP/Complaints/Site/Others preload raw response:", data);
            let statusMessage = data && data.details && data.details.statusMessage;
            if (!statusMessage || typeof statusMessage === "string") {
              console.log("[BeatPlan] IHP/Complaints/Site/Others preload returned an error/unexpected shape:", statusMessage);
              flag = 0;
              return;
            }
            if (statusMessage.info && statusMessage.info.more_records) {
              flag = 1;
              i++;
            } else {
              flag = 0;
            }
            let arr2 = statusMessage.data || [];
            arr2.forEach(async element => {
              if (element.SAP_Code == null || element.SAP_Code == "") {
                element.AccPicklistName = "" + element.Account_Name
              } else {
                element.AccPicklistName = "" + element.Account_Name + "/ " + element.SAP_Code;
              }
            });
            arr3 = arr3.concat(arr2);
          })
          .catch(function (err) {
            console.log("[BeatPlan] IHP/Complaints/Site/Others preload failed:", err);
          })
        // }
        console.log("[BeatPlan] IHP/Complaints/Site/Others preload result:", arr3)
        vm.NameofAccountComplaintsoptions = arr3;
        vm.NameofKeyaccountSiteoptions = arr3;
        vm.NameofKeyaccountIHPoptions = arr3;
        vm.NameofCompetitorOptions = arr3;
      }
    },
    async Visit(newvalue, oldvalue) {
      vm.Accounts = [];
      console.log("running")
      moduleName = "Accounts";
      if (newvalue == null) {

      } else {
        vm.picked = null;
        if (newvalue === 'Distributor') {
          if (!vm.DistributorOptions.length > 0) {
            console.log("d")
            criteria = "(Account_Type:equals:Distributor)";
            Type = "Distributor"
            vm.picklistoptions(criteria, moduleName, Type);
          }
        } else if (newvalue === 'Dealer') {
          if (!vm.DealerOptions.length > 0) {
            criteria = "(Account_Type:equals:Dealer)"
            Type = "Dealer"
            vm.picklistoptions(criteria, moduleName, Type);
          }
        } else if (newvalue === 'Stockist') {
          if (!vm.StockistOptions.length > 0) {
            criteria = "(Account_Type:equals:Stockist)"
            Type = "Stockist"
            vm.picklistoptions(criteria, moduleName, Type);
          }
        } else if (newvalue === 'Sub Dealer/Retailer') {
          if (!vm.StockistOptions.length > 0) {
            criteria = "(Account_Type:equals:Sub Dealer/Retailer)"
            Type = "Sub Dealer/Retailer"
            vm.picklistoptions(criteria, moduleName, Type);
          }
        } else if (newvalue === 'Direct Customer') {
          if (!vm.DirectCustomerOptions.length > 0) {
            criteria = "(Account_Type:equals:Direct Customer)"
            Type = "Direct Customer"
            vm.picklistoptions(criteria, moduleName, Type);
          }
        } else if (newvalue === 'EPC Contractor') {
          if (!vm.ECPContractorOptions.length > 0) {
            criteria = "(Account_Type:equals:EPC Contractor)"
            Type = "EPC Contractor"
            vm.picklistoptions(criteria, moduleName, Type);
          }
        } else if (newvalue === 'Architect/Consultant') {
          if (!vm.ArchitectConsultantOptions.length > 0) {
            criteria = "(Account_Type:equals:Architect/Consultant)"
            Type = "Architect/Consultant"
            vm.picklistoptions(criteria, moduleName, Type);
          }
        } else {
          vm.OtherPartnerOptions = [];
          vm.picklistoptions(null, "OtherPartner", newvalue);
        }

      }

    },
    async picked(newvalue, oldvalue) {
      vm.Accounts = [];
      vm.Contacts = [];
      Type = "Influencers"
      if (newvalue === 'firm') {
        if (!vm.InfluencersOptions.length > 0) {
          criteria = "(Account_Type:equals:Influencers)"
          moduleName = "Accounts";
          vm.picklistoptions(criteria, moduleName, Type);
        }
      } else if (newvalue === 'contact') {
        if (!vm.ContactsOptions.length > 0) {
          criteria = "(Contact_Type:equals:Influencers)"
          moduleName = "Contacts";
          vm.picklistoptions(criteria, moduleName, Type);
        }
      }
    },
    async Plan(newvalue, oldvalue) {

      if (newvalue === "My Plan" || newvalue === "My Approval") {

        // vm.showplanrange = false;
        // collection = document.getElementsByClassName('card-y1')[0];
        // collection.classList.remove("rotate-y");
        // vm.Planrange = "First Half";
        vm.Planrange = null;
        $('#calendar').fullCalendar('removeEvents');
        if (vm.BU == "BP") {
          vm.prevnextprefill();
        }
      } else {
        // vm.showplanrange = true;
        // vm.Planrange = "First Half";
        vm.Planrange = null;
        $('#calendar').fullCalendar('removeEvents');
        // vm.prevnextprefill();
      }
    },
    async Planrange(newvalue, oldvalue) {
      if (newvalue == "" || newvalue == null) {
        $('#calendar').fullCalendar('removeEvents');
      } else {
        if (vm.Plan == "My Plan" || vm.Plan == "My Approval") {
          $('#calendar').fullCalendar('removeEvents');
          vm.prevnextprefill();
        }
      }
    },

  },
  computed: {
    isApprovalEscalated() {
      if (this.BU != 'BP' || this.Status != 'Pending for Approval' || this.todayweek != this.Weeknumber) {
        return false;
      }
      let now = new Date();
      let day = now.getDay();
      let hour = now.getHours();
      return day > 1 || (day == 1 && hour >= 14);
    }
  },
  methods: {
    isOtherPartner(visit) {
      return !!visit && !DedicatedPartnerTypes.includes(visit);
    },
    async InfluencerPrefill() {
      vm.NameeofInfluencer = null;
      vm.NameeofInfluenceroptions = [];
      console.log(vm.InfluencerType);
      moduleName = "Accounts";
      criteria = "(Account_Type:equals:" + vm.InfluencerType + ")";
      if(vm.InfluencerType == "Infra House/EPC Contractor"){
        criteria = "(Account_Type:equals:PEB Contractor) or (Account_Type:equals:EPC Contractor)"
      }
      console.log(criteria)
      var flag = 1;
      var i = 0;
      let arr1 = [];
      while (flag == 1) {
        await ZOHO.CRM.API.searchRecord({ Entity: moduleName, Type: "criteria", Query: criteria, per_page: 200, page: i })
          .then(async function (data) {
            console.log(data);
            if (data.info.more_records == false) {
              flag = 0;
            } else {
              i++;
            }
            arr2 = data.data;
            arr1 = arr1.concat(arr2);
          })
      }
      arr1.forEach(element => {
        element.AccPicklistName = element.Account_Name + " / " + element.id;
      });
      console.log(arr1)
      vm.NameeofInfluenceroptions = arr1;
    },
    async showcomplaints() {
      recid = (vm.NameofAccountComplaints).id;
      var flag = 1;
      var i = 1;
      let arr1 = [];
      while (flag == 1) {
        await ZOHO.CRM.API.getRelatedRecords({ Entity: "Accounts", RecordID: recid, RelatedList: "Account_name1", page: i, per_page: 200 })
          .then(async function (data) {
            console.log(data)
            if (data.info.more_records == false) {
              flag = 0;
            } else {
              i++;
            }
            arr2 = data.data;
            arr1 = arr1.concat(arr2);
          })
      }
      console.log(arr1);
      vm.ComplaintIDoptions = arr1;

    },
    async showopportunity() {
      console.log("in")
      recid = vm.NameofKeyaccountSite.id
      console.log(recid);
      var flag = 1;
      var i = 1;
      let arr1 = [];
      while (flag == 1) {
        await ZOHO.CRM.API.getRelatedRecords({ Entity: "Accounts", RecordID: recid, RelatedList: "Deals", page: i, per_page: 200 })
          .then(async function (data) {
            console.log(data)
            if (data.info.more_records == false) {
              flag = 0;
            } else {
              i++;
            }
            arr2 = data.data;
            arr1 = arr1.concat(arr2);
          })
      }
      console.log(arr1);
      vm.OpportunityNameoptions = arr1;

    },
    async CallEvents() {

      vm.Status = "In Draft"
      $('#calendar').fullCalendar('removeEvents');
      if (vm.Plan != "My Plan") {
        var date = $("#calendar").fullCalendar('getDate');
        curmonth = date._d.toString();
        monthyear = curmonth.split(" ");
        console.log(monthyear);
        month = monthyear[1];
        year = monthyear[3];
        if (month == "Jan") {
          month = "January"
        } else if (month == "Feb") {
          month = "February"
        } else if (month == "Mar") {
          month = "March"
        } else if (month == "Apr") {
          month = "April"
        } else if (month == "May") {
          month = "May"
        } else if (month == "Jun") {
          month = "June"
        } else if (month == "Jul") {
          month = "July"
        } else if (month == "Aug") {
          month = "August"
        } else if (month == "Sep") {
          month = "September"
        } else if (month == "Oct") {
          month = "October"
        } else if (month == "Nov") {
          month = "November"
        } else if (month == "Dec") {
          month = "December"
        }
        var flag = 1;
        conn_name = "modulesall"
        pageNO = 0;
        let userarray = [];
        let distinctarr = [];
        while (flag == 1) {
          console.log(vm.CurrentUser)
          let params = { "select_query": "SELECT Name,Status,Owner,Approver_Lookup From Plan_Approval where ((Month=" + month + " and Year=" + year + ") and Plan_Range='" + vm.Planrange + "') and Approver_Lookup=" + vm.CurrentUser + "  LIMIT " + pageNO + ",200" }

          if (vm.BU == "BP" && vm.calView == "month") {
            params = { "select_query": "SELECT Name,Status,Owner,Approver_Lookup From Plan_Approval where (Month=" + month + " and Year=" + year + ") and Approver_Lookup=" + vm.CurrentUser + "  LIMIT " + pageNO + ",200" }
          }

          if (vm.BU == "BP" && vm.calView == "agendaWeek") {
            params = { "select_query": "SELECT Name,Status,Owner,Approver_Lookup From Plan_Approval where ((Month=" + month + " and Year=" + year + ") and Week='" + vm.Weeknumber + "') and Approver_Lookup=" + vm.CurrentUser + "  LIMIT " + pageNO + ",200" }
          }


          var req_data = {
            "parameters": params,
            "method": "POST",
            "url": "https://www.zohoapis.in/crm/v5/coql"
          }

          // var planapparray = [];
          await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
            .then(async function (data) {
              console.log(data);
              // planapparray.push(data)
              if (data.details.statusMessage != "") {
                console.log(data.details.statusMessage.info.more_records);
                if (data.details.statusMessage.info.more_records == false) {
                  flag = 0;
                } else {
                  pageNO = pageNO + 200
                }
                let arr = data.details.statusMessage.data;
                await arr.forEach(async (element, index) => {
                  // console.log(element["Owner.id"]);


                  if (vm.BU == "BP" && vm.calView == "agendaWeek") {

                    await ZOHO.CRM.API.getUser({ ID: element.Owner.id })
                      .then(async function (ownerdata) {
                        setTimeout(async () => {

                          element.ownername = ownerdata.users[0].full_name
                          distinctarr.push(element);
                          // if(arr.length == index+1){
                          //   await userarray.forEach(async element => {
                          //     console.log(element)
                          //     flag=0;
                          //     distinctarr.forEach(ele =>{
                          //       if(ele.Owner.id == element.Owner.id){
                          //         console.log("yes")
                          //         flag=1;
                          //       }
                          //     })
                          //     if(flag==0){
                          //       distinctarr.push(element)  
                          //     }
                          //   });
                          // }
                        }, 100);
                      })

                  } else {
                    await ZOHO.CRM.API.getUser({ ID: element.Owner.id })
                      .then(async function (ownerdata) {
                        setTimeout(async () => {


                          element.ownername = ownerdata.users[0].full_name
                          userarray.push(element);
                          if (arr.length == index + 1) {
                            await userarray.forEach(async element => {
                              console.log(element)
                              flag = 0;
                              distinctarr.forEach(ele => {
                                if (ele.Owner.id == element.Owner.id) {
                                  console.log("yes")
                                  flag = 1;
                                }
                              })
                              if (flag == 0) {
                                distinctarr.push(element)
                              }
                            });
                          }
                        }, 100);
                      })

                  }
                });

              } else {
                flag = 0;
              }
            })
        }
        console.log(userarray)
        console.log(distinctarr)
        // let distinctarr=[];








        vm.PendingApprovalOptions = distinctarr







      } else if (vm.Plan == "My Plan") {
        vm.CurrentUser = vm.thisuser
        vm.prefill();
      }
    },
    async showapproveevents() {
      vm.Holidayevents = [];
      console.log(vm.PendingApproval)
      vm.showload = true;
      if (vm.PendingApproval != "" && vm.PendingApproval != null) {
        $('#calendar').fullCalendar('removeEvents');
        flag = 1;
        let pageNO = 0;
        var i = 0
        while (flag == 1) {
          console.log(month)
          console.log(year)
          console.log(vm.PendingApproval.id)

          let Criteria;
          if (vm.BU == "BP" && vm.calView == "month") {
            Criteria = "SELECT Name,Meeting_Type,Approver_Comments,Redflag,Orangeflag,Date,Activity,Visit,Type,Account_Name,Account_Name.Account_Name,Planned_Sales_Plan_in_MT,Remarks,Purpose_of_Visit_Influencer,Name_of_Factory,Complaint_ID.Complaints_No	,Meet,Influencer_Type,Type_of_drive,Type_of_activity,Opportunity_Name,Opportunity_Name.Deal_Name as 'aqwdqwd',Purpose_of_Visit_Factory,No_of_Attendants,Training_Type,Location,Description,Mode,Type_of_Event,Account_Name_for_Others,Plan_Approval From Beat_Plan Where ((((Month=" + month + ") and (Year=" + year + ")) ) and (Owner=" + vm.PendingApproval.Owner.id + ")) and Meeting_Type='Regular' LIMIT " + pageNO + ",200"
            // and (Plan_Approval	!=null and Plan_Approval	!='')
            var req_data = {
              "parameters": { "select_query": Criteria },
              "method": "POST",
              "url": "https://www.zohoapis.in/crm/v5/coql"
            }

            await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
              .then(async function (data) {
                console.log(data);
                if (data.status != 204) {
                  console.log(data)
                  // if (data.info.more_records == false) {
                  if (data.details.statusMessage != "") {
                    if (data.details.statusMessage.info.more_records == false) {
                      flag = 0
                    } else {
                      pageNO = pageNO + 200;
                    }
                  }
                  // data.data.forEach(async element => {
                  let arr1 = data.details.statusMessage.data
                  console.log(arr1)
                  await arr1.forEach(async element => {
                    if (element.Plan_Approval != "" && element.Plan_Approval != null) {
                      console.log(element);
                      console.log(element.Remarks)

                      vm.StartDate = element.Date
                      vm.EndDate = element.Date
                      vm.Activity = element.Activity
                      vm.MeetingType = element.Meeting_Type
                      // vm.Visit = element.Visit
                      // vm.picked = element.Type
                      vm.ZohoBeatPlanId = element.id
                      vm.Redflag = element.Redflag
                      vm.Orangeflag = element.Orangeflag
                      vm.Visit = element.Visit
                      Accounts = element.Account_Name
                      vm.Approvercomments = element.Approver_Comments
                      vm.PlannedSalesPlan = element.Planned_Sales_Plan_in_MT
                      vm.PurposeOfVisitInfluencer = element.Purpose_of_Visit_Influencer
                      vm.NameofFactory = element.Name_of_Factory
                      vm.ComplaintID = element.Complaint_ID
                      vm.Typeofdrive = element.Type_of_drive
                      vm.Typeofactivity = element.Type_of_activity
                      vm.OpportunityName = element.Opportunity_Name
                      vm.PurposeofVisitFactory = element.Purpose_of_Visit_Factory
                      vm.NoofAttendants = element.No_of_Attendants
                      vm.Trainingtype = element.Training_Type
                      vm.AccountNameForOthers = element.Account_Name_for_Others
                      vm.Remarks = element.Remarks
                      console.log(element.Complaint_ID)
                      if (Accounts != null) {
                        Accounts.AccPicklistName = element['Account_Name.Account_Name'] + "/" + Accounts.id;
                      }
                      if (vm.OpportunityName != null) {
                        vm.OpportunityName.Deal_Name = vm.OpportunityName.name;
                      }
                      if (vm.ComplaintID != null) {

                        console.log(vm.ComplaintID.id);
                        console.log(vm.ComplaintID)

                        vm.ComplaintID.Complaints_No = element.ComplaintsNo;

                      }

                      if (vm.Activity == "Category Visit" || vm.Activity == "Prospect Visit" || vm.Activity == "On-Going Project Review" || vm.Activity == "Techno-Commercial Meet" || vm.Activity == "Finalization" || vm.Activity == "Pehchan Training" || vm.Activity == "Kaushal Training" || vm.Activity == "Training") {
                        if (vm.Visit == "Distributor") {
                          vm.Distributor = Accounts
                        } else if (vm.Visit == "Dealer") {
                          vm.Dealer = Accounts
                        } else if (vm.Visit == "Stockist") {
                          vm.Stockist = Accounts
                        } else if (vm.Visit == "Direct Customer") {
                          vm.DirectCustomer = Accounts
                        } else if (vm.Visit == "EPC Contractor") {
                          vm.ECPContractor = Accounts
                        } else if (vm.Visit == "Architect/Consultant") {
                          vm.ArchitectConsultant = Accounts
                        } else if (vm.isOtherPartner(vm.Visit)) {
                          vm.OtherPartner = Accounts
                        }
                      } else if (vm.Activity == "Influencer Visit") {
                        vm.NameeofInfluencer = Accounts
                      } else if (vm.Activity == "IHP") {
                        vm.NameofKeyaccountIHP = Accounts
                      } else if (vm.Activity == "Site Visit") {
                        vm.NameofKeyaccountSite = Accounts
                      } else if (vm.Activity == "Complaints Redressal") {
                        vm.NameofAccountComplaints = Accounts
                      }
                      console.log(Accounts)

                      if (vm.Activity == "Category Visit") {
                        vm.Colour = "#a3d9ff"
                      } else if (vm.Activity == "Prospect Visit") {
                        vm.Colour = "#ff9966"
                      } else if (vm.Activity == "On-Going Project Review") {
                        vm.Colour = "#ffb84d"
                      } else if (vm.Activity == "Techno-Commercial Meet") {
                        vm.Colour = "#b399ff"
                      } else if (vm.Activity == "Finalization") {
                        vm.Colour = "#66cc99"
                      } else if (vm.Activity == "Pehchan Training" || vm.Activity == "Training") {
                        vm.Colour = "#99ccff"
                      } else if (vm.Activity == "Kaushal Training") {
                        vm.Colour = "#6666ff"
                      } else if (vm.Activity == "Influencer Visit") {
                        vm.Colour = "#9fdfbf"
                      } else if (vm.Activity == "Factory or Depot Visit") {
                        vm.Colour = "#669999"
                      } else if (vm.Activity == "IHP") {
                        vm.Colour = "#999966"
                      } else if (vm.Activity == "Site Visit") {
                        vm.Colour = "#cc9900"
                      } else if (vm.Activity == "Strategic Drive") {
                        vm.Colour = "#cccc00"
                      } else if (vm.Activity == "Complaints Redressal") {
                        vm.Colour = "#cc2900"
                      } else if (vm.Activity == "WFH") {
                        vm.Colour = "#3cb44b"
                      } else if (vm.Activity == "Leave") {
                        vm.Colour = "#666699"
                      } else if (vm.Activity == "Fabricator Meet") {
                        vm.Colour = "#900C3F"
                      } else if (vm.Activity == "Events") {
                        vm.Colour = "#581845"
                      } else if (vm.Activity == "MIS/ Review/ Meet") {
                        vm.Colour = "#FF5733"
                      } else if (vm.Activity == "Project Hunting/ Follow Up" || vm.Activity == "Scouting/Follow-up") {
                        vm.Colour = "#FF7133"
                      } else if (vm.Activity == "Others") {
                        vm.Colour = "#313949"
                      }

                      // let acc=element['Account_Name.Account_Name']

                      if (vm.Activity == "Strategic Drive") {
                        title = vm.Typeofdrive;
                      } else if (vm.Activity == "Factory or Depot Visit") {
                        title = vm.NameofFactory;
                      } else if (vm.Activity == "Others") {
                        if (vm.AccountNameForOthers == null || vm.AccountNameForOthers == "") {
                          title = vm.Activity;
                        } else {
                          title = vm.AccountNameForOthers;
                        }
                      } else if (Accounts == null || Accounts == "") {
                        title = vm.Activity;
                      } else {
                        title = element['Account_Name.Account_Name']
                      }

                      var eventData = {
                        start: vm.StartDate,
                        end: vm.StartDate,
                        activity: vm.Activity,
                        title: title,
                        Visit: vm.Visit,
                        picked: vm.picked,
                        BeatPlanId: vm.ZohoBeatPlanId,
                        AccountId: Accounts,
                        PlannedSalesPlan: vm.PlannedSalesPlan,
                        Purpose_of_Visit_Influencer: vm.PurposeOfVisitInfluencer,
                        Name_of_Factory: vm.NameofFactory,
                        Complaint_ID: vm.ComplaintID,
                        Type_of_drive: vm.Typeofdrive,
                        Type_of_activity: vm.Typeofactivity,
                        Opportunity_Name: vm.OpportunityName,
                        Purpose_of_Visit_Factory: vm.PurposeofVisitFactory,
                        No_of_Attendants: vm.NoofAttendants,
                        Approver_Comments: vm.Approvercomments,
                        Remarks: vm.Remarks,
                        Account_Name_for_Others: vm.AccountNameForOthers,
                        color: vm.Colour,
                        approve: "Yes",
                        Orangeflag: vm.Orangeflag,
                        Redflag: element.Redflag,
                        Meeting_Type: vm.MeetingType
                      }
                      $("#calendar").fullCalendar("renderEvent", eventData, true); // stick? = true
                    }
                  });
                } else {
                  flag = 0;
                }

              })


          }
          else if ((vm.BU == "Roofing") || (vm.BU == "BP" && vm.calView == "agendaWeek")) {
            await ZOHO.CRM.API.getRelatedRecords({ Entity: "Plan_Approval", RecordID: vm.PendingApproval.id, RelatedList: "Beat_Plan", page: i, per_page: 200 })
              .then(async function (data) {
                console.log(data);
                if (data.status == "error") {
                  console.error("[BeatPlan] getRelatedRecords failed:", data);
                  flag = 0;
                } else if (data.status != 204 && data.info && data.info.more_records != undefined) {
                  console.log(data)
                  if (data.info.more_records == false) {
                    flag = 0
                  } else {
                    i++;
                  }
                  await data.data.forEach(async element => {
                    console.log(element);
                    console.log(element.Remarks)

                    vm.StartDate = element.Date
                    vm.EndDate = element.Date
                    vm.Activity = element.Activity
                    vm.MeetingType = element.Meeting_Type
                    // vm.Visit = element.Visit
                    // vm.picked = element.Type
                    vm.ZohoBeatPlanId = element.id
                    vm.Trainingtype = element.Training_Type
                    vm.AccountNameForOthers = element.Account_Name_for_Others
                    vm.Redflag = element.Redflag
                    vm.Orangeflag = element.Orangeflag
                    vm.Visit = element.Visit
                    Accounts = element.Account_Name
                    vm.Approvercomments = element.Approver_Comments
                    vm.PlannedSalesPlan = element.Planned_Sales_Plan_in_MT
                    vm.PurposeOfVisitInfluencer = element.Purpose_of_Visit_Influencer
                    vm.NameofFactory = element.Name_of_Factory
                    vm.ComplaintID = element.Complaint_ID
                    vm.Typeofdrive = element.Type_of_drive
                    vm.Typeofactivity = element.Type_of_activity
                    vm.OpportunityName = element.Opportunity_Name
                    vm.PurposeofVisitFactory = element.Purpose_of_Visit_Factory
                    vm.NoofAttendants = element.No_of_Attendants
                    vm.Remarks = element.Remarks
                    console.log(element.Complaint_ID)
                    if (Accounts != null) {
                      Accounts.AccPicklistName = Accounts.name + "/" + Accounts.id;
                    }
                    if (vm.OpportunityName != null) {
                      vm.OpportunityName.Deal_Name = vm.OpportunityName.name;
                    }
                    if (vm.ComplaintID != null) {

                      console.log(vm.ComplaintID.id);
                      console.log(vm.ComplaintID)

                      vm.ComplaintID.Complaints_No = element.ComplaintsNo;

                    }

                    if (vm.Activity == "Category Visit" || vm.Activity == "Prospect Visit" || vm.Activity == "On-Going Project Review" || vm.Activity == "Techno-Commercial Meet" || vm.Activity == "Finalization" || vm.Activity == "Pehchan Training" || vm.Activity == "Kaushal Training" || vm.Activity == "Training") {
                      if (vm.Visit == "Distributor") {
                        vm.Distributor = Accounts
                      } else if (vm.Visit == "Dealer") {
                        vm.Dealer = Accounts
                      } else if (vm.Visit == "Stockist") {
                        vm.Stockist = Accounts
                      } else if (vm.Visit == "Direct Customer") {
                        vm.DirectCustomer = Accounts
                      } else if (vm.Visit == "EPC Contractor") {
                        vm.ECPContractor = Accounts
                      } else if (vm.Visit == "Architect/Consultant") {
                        vm.ArchitectConsultant = Accounts
                      } else if (vm.isOtherPartner(vm.Visit)) {
                        vm.OtherPartner = Accounts
                      }
                    } else if (vm.Activity == "Influencer Visit") {
                      vm.NameeofInfluencer = Accounts
                    } else if (vm.Activity == "IHP") {
                      vm.NameofKeyaccountIHP = Accounts
                    } else if (vm.Activity == "Site Visit") {
                      vm.NameofKeyaccountSite = Accounts
                    } else if (vm.Activity == "Complaints Redressal") {
                      vm.NameofAccountComplaints = Accounts
                    }


                    if (vm.Activity == "Category Visit") {
                      vm.Colour = "#a3d9ff"
                    } else if (vm.Activity == "Prospect Visit") {
                      vm.Colour = "#ff9966"
                    } else if (vm.Activity == "On-Going Project Review") {
                      vm.Colour = "#ffb84d"
                    } else if (vm.Activity == "Techno-Commercial Meet") {
                      vm.Colour = "#b399ff"
                    } else if (vm.Activity == "Finalization") {
                      vm.Colour = "#66cc99"
                    } else if (vm.Activity == "Pehchan Training" || vm.Activity == "Training") {
                      vm.Colour = "#99ccff"
                    } else if (vm.Activity == "Kaushal Training") {
                      vm.Colour = "#6666ff"
                    } else if (vm.Activity == "Influencer Visit") {
                      vm.Colour = "#9fdfbf"
                    } else if (vm.Activity == "Factory or Depot Visit") {
                      vm.Colour = "#669999"
                    } else if (vm.Activity == "IHP") {
                      vm.Colour = "#999966"
                    } else if (vm.Activity == "Site Visit") {
                      vm.Colour = "#cc9900"
                    } else if (vm.Activity == "Strategic Drive") {
                      vm.Colour = "#cccc00"
                    } else if (vm.Activity == "Complaints Redressal") {
                      vm.Colour = "#cc2900"
                    } else if (vm.Activity == "WFH") {
                      vm.Colour = "#3cb44b"
                    } else if (vm.Activity == "Leave") {
                      vm.Colour = "#666699"
                    } else if (vm.Activity == "Fabricator Meet") {
                      vm.Colour = "#900C3F"
                    } else if (vm.Activity == "Events") {
                      vm.Colour = "#581845"
                    } else if (vm.Activity == "MIS/ Review/ Meet") {
                      vm.Colour = "#FF5733"
                    } else if (vm.Activity == "Project Hunting/ Follow Up" || vm.Activity == "Scouting/Follow-up") {
                      vm.Colour = "#FF7133"
                    } else if (vm.Activity == "Others") {
                      vm.Colour = "#313949"
                    }

                    // let acc=element['Account_Name.Account_Name']

                    if (vm.Activity == "Strategic Drive") {
                      title = vm.Typeofdrive;
                    } else if (vm.Activity == "Factory or Depot Visit") {
                      title = vm.NameofFactory;
                    } else if (vm.Activity == "Others") {
                      if (vm.AccountNameForOthers == null || vm.AccountNameForOthers == "") {
                        title = vm.Activity;
                      } else {
                        title = vm.AccountNameForOthers;
                      }
                    } else if (Accounts == null || Accounts == "") {
                      title = vm.Activity;
                    } else {
                      title = Accounts.name
                    }

                    var eventData = {
                      start: vm.StartDate,
                      end: vm.StartDate,
                      activity: vm.Activity,
                      title: title,
                      Visit: vm.Visit,
                      picked: vm.picked,
                      BeatPlanId: vm.ZohoBeatPlanId,
                      AccountId: Accounts,
                      PlannedSalesPlan: vm.PlannedSalesPlan,
                      Purpose_of_Visit_Influencer: vm.PurposeOfVisitInfluencer,
                      Name_of_Factory: vm.NameofFactory,
                      Complaint_ID: vm.ComplaintID,
                      Type_of_drive: vm.Typeofdrive,
                      Type_of_activity: vm.Typeofactivity,
                      Opportunity_Name: vm.OpportunityName,
                      Purpose_of_Visit_Factory: vm.PurposeofVisitFactory,
                      No_of_Attendants: vm.NoofAttendants,
                      Approver_Comments: vm.Approvercomments,
                      Remarks: vm.Remarks,
                      Account_Name_for_Others: vm.AccountNameForOthers,
                      color: vm.Colour,
                      approve: "Yes",
                      Orangeflag: vm.Orangeflag,
                      Redflag: element.Redflag,
                      Meeting_Type: vm.MeetingType
                    }
                    $("#calendar").fullCalendar("renderEvent", eventData, true); // stick? = true
                  });
                } else {
                  flag = 0;
                }
              })
          }

        }
        console.log(JSON.stringify(vm.PendingApproval.Owner.id))


        if (vm.BU == "BP" && vm.calView == "month") {
          var req_data = {
            "parameters": { "select_query": "SELECT Name,Status From Plan_Approval where (Month=" + month + " and Year=" + year + ") and Owner=" + vm.PendingApproval.Owner.id },
            "method": "POST",
            "url": "https://www.zohoapis.in/crm/v5/coql"
          }
        } else if (vm.BU == "BP" && vm.calView == "agendaWeek") {
          var req_data = {
            "parameters": { "select_query": "SELECT Name,Status From Plan_Approval where (Week=" + vm.Weeknumber + " and Year=" + year + ") and Owner=" + vm.PendingApproval.Owner.id },
            "method": "POST",
            "url": "https://www.zohoapis.in/crm/v5/coql"
          }
        } else if (vm.BU == "Roofing") {
          var req_data = {
            "parameters": { "select_query": "SELECT Name,Status From Plan_Approval where ((Month=" + month + " and Year=" + year + ") and Plan_Range= '" + vm.Planrange + "'  ) and Owner=" + vm.PendingApproval.Owner.id },
            "method": "POST",
            "url": "https://www.zohoapis.in/crm/v5/coql"
          }
        }



        await ZOHO.CRM.API.getRecord({
          Entity: "users", RecordID: vm.PendingApproval.Owner.id
        })
          .then(async function (data) {

            vm.Planownerstate = data.users[0].state
          })

        //holiday calendar
        if (vm.Planownerstate) {

          var date = $("#calendar").fullCalendar('getDate');

          console.log(date._d)

          curmonth = date._d.toString();
          monthyear = curmonth.split(" ");
          month = monthyear[1];
          year = monthyear[3];
          if (month == "Jan") {
            month = "January"
          } else if (month == "Feb") {
            month = "February"
          } else if (month == "Mar") {
            month = "March"
          } else if (month == "Apr") {
            month = "April"
          } else if (month == "May") {
            month = "May"
          } else if (month == "Jun") {
            month = "June"
          } else if (month == "Jul") {
            month = "July"
          } else if (month == "Aug") {
            month = "August"
          } else if (month == "Sep") {
            month = "September"
          } else if (month == "Oct") {
            month = "October"
          } else if (month == "Nov") {
            month = "November"
          } else if (month == "Dec") {
            month = "December"
          }

          var req_data = {
            "parameters": { "select_query": "SELECT Name,States,Date From Holiday_Master where (((States like '%" + vm.Planownerstate + "%') and Month='" + month + "')and Year ='" + year + "') limit 0,200" },
            "method": "POST",
            "url": "https://www.zohoapis.in/crm/v5/coql"
          }

          await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
            .then(async function (data) {
              if (data.details.statusMessage) {
                console.log(data.details.statusMessage.data)
                let arr1 = data.details.statusMessage.data;
                await arr1.forEach(async element => {
                  vm.Holidayevents.push(element)
                });
              }
              console.log(vm.Holidayevents)
            })
        }
        if (vm.Holidayevents) {

          vm.Holidayevents.forEach(element => {
            console.log(element)

            var eventData = {
              start: element.Date,
              end: element.Date,
              title: element.Name,
              rendering: 'background',

            };

            $("#calendar").fullCalendar("renderEvent", eventData, false);
          });
        }
        //uncommented
        if (vm.BU == "Roofing") {
          var req_data = {
            "parameters": { "select_query": "SELECT Name,Status From Plan_Approval where ((Month=" + month + " and Year=" + year + ") and Plan_Range= '" + vm.Planrange + "'  ) and Owner=" + vm.PendingApproval.Owner.id },
            "method": "POST",
            "url": "https://www.zohoapis.in/crm/v5/coql"
          }
        } else if (vm.BU == "BP" && vm.calView == "agendaWeek") {
          var req_data = {
            "parameters": { "select_query": "SELECT Name,Status From Plan_Approval where ((Month=" + month + " and Year=" + year + ") and Week= '" + vm.Weeknumber + "'  ) and Owner=" + vm.PendingApproval.Owner.id },
            "method": "POST",
            "url": "https://www.zohoapis.in/crm/v5/coql"
          }
        }
        if ((vm.BU == "Roofing") || (vm.BU == "BP" && vm.calView == "agendaWeek")) {
          await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
            .then(async function (data) {
              console.log(data)
              // vm.testing=data
              if (data.details.statusMessage != "") {
                vm.PlanApprovalId = data.details.statusMessage.data[0].id
                vm.Status = data.details.statusMessage.data[0].Status
              } else {
                vm.Status = "In Draft";
              }
            })
        }
      }
      setTimeout(() => {
        vm.showload = false;
      }, 2000);

    },
    async highlighttab(val) {
      // vm.showbargraph=false
      if (val == "Cal") {

        var element = document.getElementById(val);
        element.classList.add("active");

        var element = document.getElementById("Dash");
        element.classList.remove("active");
      } else if (val == "Dash") {

        var element = document.getElementById(val);
        element.classList.add("active");
        var element = document.getElementById("Cal");
        element.classList.remove("active");
      }
    },
    async pickSearch(moduleName, Type, search, loading) {
      if (search.length > 2) {
        let safeSearch = search.replace(/'/g, "");
        let coqlQuery;
        if (Type == "Competitor" || Type == "IHP" || Type == "Site Visit" || Type == "Complaints Redressal") {
          coqlQuery = "SELECT id, Account_Name, SAP_Code FROM Accounts WHERE Account_Name like '" + safeSearch + "%' LIMIT 200";
        } else if (Type == "Influencer") {
          if (vm.InfluencerType == "Infra House/EPC Contractor") {
            coqlQuery = "SELECT id, Account_Name, SAP_Code FROM Accounts WHERE (Account_Name like '" + safeSearch + "%') and ((Account_Type = 'PEB Contractor') or (Account_Type = 'EPC Contractor')) LIMIT 200";
          } else {
            coqlQuery = "SELECT id, Account_Name, SAP_Code FROM Accounts WHERE (Account_Name like '" + safeSearch + "%') and (Account_Type = '" + vm.InfluencerType + "') LIMIT 200";
          }
        } else {
          coqlQuery = "SELECT id, Account_Name, SAP_Code FROM Accounts WHERE ((Account_Name like '" + safeSearch + "%') and (Account_Type = '" + Type + "')) and (BU_Type = '" + UserBUType + "') LIMIT 200";
        }
        // and (Owner = '" + vm.thisuser + "')
        console.log("[BeatPlan] pickSearch Type=", Type, "query=", coqlQuery);

        let res = await ZOHO.CRM.CONNECTION.invoke("modulesall", {
          method: "POST",
          url: "https://www.zohoapis.in/crm/v5/coql",
          parameters: { select_query: coqlQuery },
          param_type: 2,
          headers: { "Content-Type": "application/json" }
        });
        console.log("[BeatPlan] pickSearch raw response=", res);

        let arr1 = (res.details && res.details.statusMessage && res.details.statusMessage.data) || [];
        console.log("[BeatPlan] pickSearch matched", arr1.length, "records for Type=", Type);

        arr1.forEach(element => {
          if (element.SAP_Code) {
            element.AccPicklistName = element.Account_Name + " / " + element.SAP_Code;
          } else {
            element.AccPicklistName = element.Account_Name
          }
        });
        console.log(arr1)

        if (moduleName == "Accounts" && Type == "Distributor") {
          vm.DistributorOptions = arr1;
        } else if (moduleName == "Accounts" && Type == "Dealer") {
          vm.DealerOptions = arr1;
        } else if (moduleName == "Accounts" && Type == "Stockist") {
          vm.StockistOptions = arr1;
        } else if (moduleName == "Accounts" && Type == "Sub Dealer/Retailer") {
          vm.SubDealerRetailerOptions = arr1;
        } else if (moduleName == "Accounts" && Type == "Direct Customer") {
          vm.DirectCustomerOptions = arr1;
        } else if (moduleName == "Accounts" && Type == "EPC Contractor") {
          vm.ECPContractorOptions = arr1;
        } else if (moduleName == "Accounts" && Type == "Architect/Consultant") {
          vm.ArchitectConsultantOptions = arr1;
        } else if (moduleName == "Accounts" && Type == "Project Sale") {
          vm.ProjectsaleOptions = arr1;
        } else if (moduleName == "Accounts" && (Type == "Competitor" || Type == "IHP" || Type == "Site Visit" || Type == "Complaints Redressal")) {
          vm.NameofCompetitorOptions = arr1;
          vm.NameofKeyaccountIHPoptions = arr1;
          vm.NameofKeyaccountSiteoptions = arr1;
          vm.NameofAccountComplaintsoptions = arr1;
        } else if (moduleName == "Accounts" && Type == "Influencer") {
          vm.NameeofInfluenceroptions = arr1;
        } else if (moduleName == "OtherPartner") {
          vm.OtherPartnerOptions = arr1;
        }
      }
    },
    async picklistoptions(criteria, moduleName, Type) {
      let coqlQuery = "SELECT id, Account_Name, SAP_Code FROM Accounts WHERE (Account_Type = '" + Type + "') and (BU_Type = '" + UserBUType + "') LIMIT 200";
      // and (Owner = '" + vm.thisuser + "')
      console.log("[BeatPlan] picklistoptions Type=", Type, "query=", coqlQuery);
      let res = await ZOHO.CRM.CONNECTION.invoke("modulesall", {
        method: "POST",
        url: "https://www.zohoapis.in/crm/v5/coql",
        parameters: { select_query: coqlQuery },
        param_type: 2,
        headers: { "Content-Type": "application/json" }
      });
      console.log(res);

      let arr1 = (res.details && res.details.statusMessage && res.details.statusMessage.data) || [];

      if (moduleName == "Accounts" && Type == "Distributor") {
        arr1.forEach(element => {
          if (element.SAP_Code) {
            element.AccPicklistName = element.Account_Name + " / " + element.SAP_Code;
          } else {
            element.AccPicklistName = element.Account_Name
          }
        });
        console.log(arr1)
        vm.DistributorOptions = arr1;
      } else if (moduleName == "Accounts" && Type == "Dealer") {
        arr1.forEach(element => {
          if (element.SAP_Code) {
            element.AccPicklistName = element.Account_Name + " / " + element.SAP_Code;
          } else {
            element.AccPicklistName = element.Account_Name
          }
        });
        console.log(arr1)
        vm.DealerOptions = arr1;
      } else if (moduleName == "Accounts" && Type == "Stockist") {
        arr1.forEach(element => {
          if (element.SAP_Code) {
            element.AccPicklistName = element.Account_Name + " / " + element.SAP_Code;
          } else {
            element.AccPicklistName = element.Account_Name
          }
        });
        console.log(arr1)
        vm.StockistOptions = arr1;
      } else if (moduleName == "Accounts" && Type == "Sub Dealer/Retailer") {
        arr1.forEach(element => {
          if (element.SAP_Code) {
            element.AccPicklistName = element.Account_Name + " / " + element.SAP_Code;
          } else {
            element.AccPicklistName = element.Account_Name
          }
        });
        console.log(arr1)
        vm.SubDealerRetailerOptions = arr1;
      } else if (moduleName == "Accounts" && Type == "Direct Customer") {
        arr1.forEach(element => {
          if (element.SAP_Code) {
            element.AccPicklistName = element.Account_Name + " / " + element.SAP_Code;
          } else {
            element.AccPicklistName = element.Account_Name
          }
        });
        console.log(arr1)
        vm.DirectCustomerOptions = arr1;
      } else if (moduleName == "Accounts" && Type == "EPC Contractor") {
        arr1.forEach(element => {
          if (element.SAP_Code) {
            element.AccPicklistName = element.Account_Name + " / " + element.SAP_Code;
          } else {
            element.AccPicklistName = element.Account_Name
          }
        });
        console.log(arr1)
        vm.ECPContractorOptions = arr1;
      } else if (moduleName == "Accounts" && Type == "Architect/Consultant") {
        arr1.forEach(element => {
          if (element.SAP_Code) {
            element.AccPicklistName = element.Account_Name + " / " + element.SAP_Code;
          } else {
            element.AccPicklistName = element.Account_Name
          }
        });
        console.log(arr1)
        vm.ArchitectConsultantOptions = arr1;
      } else if (moduleName == "OtherPartner") {
        arr1.forEach(element => {
          if (element.SAP_Code) {
            element.AccPicklistName = element.Account_Name + " / " + element.SAP_Code;
          } else {
            element.AccPicklistName = element.Account_Name
          }
        });
        console.log(arr1)
        vm.OtherPartnerOptions = arr1;
      }
    },
    async eventdetails(start, end, Fromtype) {
      vm.showErrorMsg = false;
      console.log(start + " " + end + " " + Fromtype)
      if (Fromtype == undefined) {
        vm.CustomBtn = false;
        vm.Datevalue = null;
        // console.log("")
      } else if (Fromtype == "Custombtn") {
        vm.Datevalue = null,
          vm.CustomBtn = true;
        var date = $("#calendar").fullCalendar('getDate');
        curmonth = date._d.toString();
        monthyear = curmonth.split(" ");
        month = monthyear[1];
        year = monthyear[3];
        if (month == "Jan") {
          month = "January"
          vm.Datemax = [year, "01", 31].join('-');
          vm.Datemin = [year, "01", "01"].join('-');
        } else if (month == "Feb") {
          month = "February"
          vm.Datemax = [year, "02", 29].join('-')
          vm.Datemin = [year, "02", "01"].join('-');
        } else if (month == "Mar") {
          month = "March"
          vm.Datemax = [year, "03", 31].join('-');
          vm.Datemin = [year, "03", "01"].join('-');
        } else if (month == "Apr") {
          month = "April"
          vm.Datemax = [year, "04", 30].join('-')
          vm.Datemin = [year, "04", "01"].join('-');
        } else if (month == "May") {
          month = "May"
          vm.Datemax = [year, "05", 31].join('-');
          vm.Datemin = [year, "05", "01"].join('-');
        } else if (month == "Jun") {
          month = "June"
          vm.Datemax = [year, "06", 30].join('-')
          vm.Datemin = [year, "06", "01"].join('-');
        } else if (month == "Jul") {
          month = "July"
          vm.Datemax = [year, "07", 31].join('-');
          vm.Datemin = [year, "07", "01"].join('-');
        } else if (month == "Aug") {
          month = "August"
          vm.Datemax = [year, "08", 31].join('-');
          vm.Datemin = [year, "08", "01"].join('-');
        } else if (month == "Sep") {
          month = "September"
          vm.Datemax = [year, "09", 30].join('-')
          vm.Datemin = [year, "09", "01"].join('-');
        } else if (month == "Oct") {
          month = "October"
          vm.Datemax = [year, "10", 31].join('-');
          vm.Datemin = [year, "10", "01"].join('-');
        } else if (month == "Nov") {
          month = "November"
          vm.Datemax = [year, "11", 30].join('-')
          vm.Datemin = [year, "11", "01"].join('-');
        } else if (month == "Dec") {
          month = "December"
          vm.Datemax = [year, "12", 31].join('-');
          vm.Datemin = [year, "12", "01"].join('-');
        }

        console.log("runing");

        if(vm.BU=="BP" && vm.calView== "agendaWeek" ){

           
          monthyear = (vm.IntervalStart.toString()).split(" ");
          console.log(monthyear);
          month = monthyear[1];
          year = monthyear[3];
          Startdate = monthyear[2];
          let m;
          if (month == "Jan") {
            m="01";
          } else if (month == "Feb") {
            m="02"
          } else if (month == "Mar") {
           m="03"
          } else if (month == "Apr") {
          m="04"
          } else if (month == "May") {
            m="05"
          } else if (month == "Jun") {
            m="06"
          } else if (month == "Jul") {
            m="07"
          } else if (month == "Aug") {
            m="08"
          } else if (month == "Sep") {
            m="09"
          } else if (month == "Oct") {
           m="10"
          } else if (month == "Nov") {
            m="11"
          } else if (month == "Dec") {
            m="12"
          }

          vm.Datemin = [year, m,Startdate ].join('-');

          
          monthyear = (vm.IntervalEnd.toString()).split(" ");
          console.log(monthyear);
          month = monthyear[1];
          year = monthyear[3];
          Enddate = monthyear[2];
          if (month == "Jan") {
            m="01";
          } else if (month == "Feb") {
            m="02"
          } else if (month == "Mar") {
           m="03"
          } else if (month == "Apr") {
          m="04"
          } else if (month == "May") {
            m="05"
          } else if (month == "Jun") {
            m="06"
          } else if (month == "Jul") {
            m="07"
          } else if (month == "Aug") {
            m="08"
          } else if (month == "Sep") {
            m="09"
          } else if (month == "Oct") {
           m="10"
          } else if (month == "Nov") {
            m="11"
          } else if (month == "Dec") {
            m="12"
          }

          vm.Datemax = [year, m,Enddate-1 ].join('-');
        }



      }

      vm.showDel = false

      if (vm.BU == "BP") {
        vm.ActivityOptions = ["Category Visit", "Prospect Visit", "On-Going Project Review", "Techno-Commercial Meet", "Finalization", "Training", "Influencer Visit", "Factory or Depot Visit", "IHP", "Site Visit", "Strategic Drive", "Complaints Redressal", "Events", "MIS/ Review/ Meet", "Scouting/Follow-up", "Others", "WFH", "Leave"]

        // Removed Project Hunting/ Follow Up mail from akanksha on Nov 7 2023
      } else if (vm.BU == "Roofing") {
        vm.ActivityOptions = ["Category Visit", "Prospect Visit", "On-Going Project Review", "Techno-Commercial Meet", "Finalization", "Training", "Influencer Visit", "Factory or Depot Visit", "Complaints Redressal", "Fabricator Meet", "Events", "MIS/ Review/ Meet", "Scouting/Follow-up", "Others", "WFH", "Leave"]
      }
      vm.validated = false,
        vm.savebutton = true;
      vm.updatebutton = false;
      vm.updatebutton1 = false;
      vm.showModal = true;

      vm.StartDate = null;
      vm.EndDate = null;
      vm.StartDate = start;
      vm.EndDate = end;
      vm.Remarks = null;

      vm.Activity = null;
      vm.Visit = null;
      vm.Distributor = null;
      vm.Dealer = null;
      vm.Stockist = null;
      vm.SubDealerRetailer = null;
      vm.DirectCustomer = null;
      vm.ECPContractor = null;
      vm.ArchitectConsultant = null;
      vm.OtherPartner = null;
      vm.PlannedSalesPlan = null;
      vm.NameofCompetitor = null;
      vm.NameeofInfluencer = null;
      vm.PurposeOfVisitInfluencer = null;
      vm.NameofFactory = null;
      vm.PurposeofVisitFactory = null;
      vm.NameofChannelPartnerPehchan = null;
      vm.NoofAttendants = null;
      vm.NameofChannelPartnerKaushal = null;
      vm.NameofKeyaccountIHP = null;
      vm.NameofKeyaccountSite = null;
      vm.OpportunityName = null;
      vm.Typeofactivity = null;
      vm.Typeofdrive = null;
      vm.NameofAccountComplaints = null;
      vm.ComplaintID = null;
      vm.Location = null;
      vm.Description = null;
      vm.Mode = null;
      vm.TypeOfEvent = null;
      vm.Approvercomments = null;
      vm.Redflag = null;
      vm.Orangeflag = null;

      vm.SubDealerRetailer = null;
      vm.typeofsitevisit = null;
      vm.Projectsale = null;
      vm.Region = null;
      vm.AccountNameForOthers = null;




    },
    async confirmsaveforleave() {

      if (vm.Activity == "Leave" || vm.Activity == "WFH") {
        vm.showModal = false
        Swal.fire({
          title: 'Are you sure to add Leave/WFH',
          text: "this will delete the existing events",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes'
        }).then((result) => {
          if (result.isConfirmed) {
           
            vm.saveaction();

          }
        })
      } else {
        if (vm.CustomBtn == true) {
          if (vm.Datevalue == null) {
            vm.showErrorMsg = true;
            vm.ErrorMsg = "Select the Date";
          } else {
            if (vm.Plan == "" || vm.Plan == null) {
              vm.ErrorMsg = "Plan is Empty";
              vm.showErrorMsg = true;
            } else {
              if ((vm.Planrange == "" || vm.Planrange == null) && (vm.BU == "Roofing")) {
                vm.ErrorMsg = "Plan Range is Empty";
                vm.showErrorMsg = true;
              } else {
                if (vm.Datevalue < vm.currentday) {
                  vm.ErrorMsg = "Previous Date is Selected";
                  vm.showErrorMsg = true;
                } else {

                  if(vm.BU=="Roofing"){
                    vm.MeetingType = "Regular"
                    let currentval = (vm.Datevalue.split("-"))[2]                  
                    if (vm.Planrange == "First Half") {
                      console.log(currentval)
                      if (currentval < "16") {
                        console.log("sd")
                        if (vm.Status != "In Draft" && vm.Status != "Rejected") {
                          vm.MeetingType = "Ad hoc"
                          vm.saveaction();
                          vm.showModal = false
                        } else {

                          let today = new Date();
                          let dd = String(today.getDate()).padStart(2, '0');
                          let mm = String(today.getMonth() + 1).padStart(2, '0');
                          let yyyy = today.getFullYear();
                          today = yyyy + '-' + mm + '-' + dd;

                          let mnth1 = vm.Datemin.toString().split("-");
                          let mnth = mnth1[1];
                          console.log(mnth);
                          console.log(mm);
                          console.log(dd);
                          console.log(vm.firsthalf+1);

                          if (mm == mnth) {
                            if (vm.Planrange == "First Half") {
                              if (dd < (vm.firsthalf + 1)) {
                                
                                vm.saveaction();
                                vm.showModal = false
                              } else {
                                vm.MeetingType = "Ad hoc"
                                vm.saveaction();
                                vm.showModal = false
                              }
                            } else if (vm.Planrange == "Second Half") {
                              if (dd < (vm.secondhalf + 1)) {
                                vm.saveaction();
                                vm.showModal = false
                              } else {
                                vm.MeetingType = "Ad hoc"
                                vm.saveaction();
                                vm.showModal = false
                              }
                            }
                          }  else if (mm != mnth) {
                            if (vm.Planrange == "First Half") {
                              vm.saveaction();
                                vm.showModal = false
                            } else if (vm.Planrange == "Second Half") {
                              vm.saveaction();
                              vm.showModal = false
                            }
                          }


                   



                          
                          
                        }
                      } else {
                        vm.ErrorMsg = "Select Dates from First Half";
                        vm.showErrorMsg = true;
                      }
                    } else if (vm.Planrange == "Second Half") {
                      if (currentval > 15 && currentval < 32) {
                        console.log("sd2")
                        if (vm.Status != "In Draft" && vm.Status != "Rejected") {
                          vm.MeetingType = "Ad hoc"
                          vm.saveaction();
                          vm.showModal = false
                        } else {
                          vm.saveaction();
                          vm.showModal = false
                        }
                      } else {
                        vm.ErrorMsg = "Select Dates from Second Half";
                        vm.showErrorMsg = true;
                      }




                    }
                  }else if(vm.BU == "BP"){
                    console.log(vm.leavewfhlist)
                    console.log(vm.Datevalue)
                    if ((vm.leavewfhlist).includes(vm.Datevalue)) {
                      swal("Permission Denied!", "Selected date contains Leave or WFH event", "error");
                    }
                    else if (vm.Status != "In Draft" && vm.Status != "Rejected") {
                      vm.MeetingType = "Ad hoc"
                      vm.saveaction();
                    } else{

                      console.log(vm.todayweek)
                      console.log(vm.Weeknumber)

                      let today = new Date();
                  let day1 = today.getDay();

                      if (vm.todayweek == vm.Weeknumber) {
                        console.log(day1)
                        if (day1 < 2) {
                          vm.MeetingType = "Regular"
                          vm.saveaction();
                          vm.showModal = false
                        } else {
                          vm.MeetingType = "Ad hoc"
                          vm.saveaction();
                          vm.showModal = false
                        }
                      } else if (vm.todayweek != vm.Weeknumber) {
                        vm.MeetingType = "Regular"
                        vm.saveaction();
                        vm.showModal = false
                      }
                    }

                    }
                }
              }
            }




          }
        } else {
          vm.saveaction();
          vm.showModal = false
        }



      }


    },
    async saveaction() {
      let leaveflag = 0;
      let Accounts = [];
      let leavedateformat;
      let m;
      let month;
      let year;
      console.log(vm.StartDate)

      if (vm.Datevalue != null) {
        console.log("in if confirion");

        leavedateformat = vm.Datevalue;
        vm.StartDate = vm.Datevalue;
        console.log(vm.StartDate)
        vm.showload = true;
        vm.Orangeflag = false
        vm.showModal = false;
        monthyear = (vm.StartDate.split("-"));

        


        month = monthyear[1];
        if (month == "01") {
          month = "January"
          m = "01";
        } else if (month == "02") {
          month = "February"
          m = "02";
        } else if (month == "03") {
          month = "March"
          m = "03";
        } else if (month == "04") {
          month = "April"
          m = "04";
        } else if (month == "05") {
          month = "May"
          m = "05";
        } else if (month == "06") {
          month = "June"
          m = "06"
        } else if (month == "07") {
          month = "July"
          m = "07"
        } else if (month == "08") {
          month = "August"
          m = "08"
        } else if (month == "09") {
          month = "September"
          m = "09"
        } else if (month == "10") {
          month = "October"
          m = "10"
        } else if (month == "11") {
          month = "November"
          m = "11"
        } else if (month == "12") {
          month = "December"
          m = "12"
        }
        year = monthyear[0];


      } else {



        vm.showload = true;

        vm.Orangeflag = false
        vm.showModal = false;
        monthyear = (vm.StartDate._d.toString()).split(" ");
        month = monthyear[1];
        if (month == "Jan") {
          month = "January"
          m = "01";
        } else if (month == "Feb") {
          month = "February"
          m = "02";
        } else if (month == "Mar") {
          month = "March"
          m = "03";
        } else if (month == "Apr") {
          month = "April"
          m = "04";
        } else if (month == "May") {
          month = "May"
          m = "05";
        } else if (month == "Jun") {
          month = "June"
          m = "06"
        } else if (month == "Jul") {
          month = "July"
          m = "07"
        } else if (month == "Aug") {
          month = "August"
          m = "08"
        } else if (month == "Sep") {
          month = "September"
          m = "09"
        } else if (month == "Oct") {
          month = "October"
          m = "10"
        } else if (month == "Nov") {
          month = "November"
          m = "11"
        } else if (month == "Dec") {
          month = "December"
          m = "12"
        }

        Accounts = [];

        year = monthyear[3];
        leavedateformat = year + "-" + m + "-" + monthyear[2];
      }


      if (vm.Activity == "Category Visit" || vm.Activity == "Prospect Visit" || vm.Activity == "On-Going Project Review" || vm.Activity == "Techno-Commercial Meet" || vm.Activity == "Finalization" || vm.Activity == "Pehchan Training" || vm.Activity == "Kaushal Training" || vm.Activity == "Training" || vm.Activity == "Fabricator Meet") {
        if (vm.Visit == "Distributor") {
          Accounts = vm.Distributor
        } else if (vm.Visit == "Dealer") {
          Accounts = vm.Dealer
        } else if (vm.Visit == "Stockist") {
          Accounts = vm.Stockist
        } else if (vm.Visit == "Sub Dealer/Retailer") {
          Accounts = vm.SubDealerRetailer
        } else if (vm.Visit == "Direct Customer") {
          Accounts = vm.DirectCustomer
        } else if (vm.Visit == "EPC Contractor") {
          Accounts = vm.ECPContractor
        } else if (vm.Visit == "Architect/Consultant") {
          Accounts = vm.ArchitectConsultant
        } else if (vm.isOtherPartner(vm.Visit)) {
          Accounts = vm.OtherPartner
        }
      } else if (vm.Activity == "Influencer Visit") {
        Accounts = vm.NameeofInfluencer
      } else if (vm.Activity == "IHP") {
        Accounts = vm.NameofKeyaccountIHP
      } else if (vm.Activity == "Site Visit") {
        Accounts = vm.NameofKeyaccountSite
      } else if (vm.Activity == "Complaints Redressal") {
        Accounts = vm.NameofAccountComplaints
      } else if (vm.Activity == "Project Hunting/ Follow Up" || vm.Activity == "Scouting/Follow-up") {
        Accounts = vm.Projectsale
      }

      if (vm.Status == "Rejected") {
        vm.Orangeflag = true
      }
      console.log("[BeatPlan] Save - Activity=", vm.Activity, "Visit=", vm.Visit, "Accounts before send=", Accounts);
      var func_name = "esbs_beatplancreaterecords";
      var req_data = {
        "arguments": JSON.stringify({
          "Date": vm.StartDate,
          "Month": month,
          "Year": year,
          "Week": vm.Weeknumber,
          "Plan_Range": vm.Planrange,
          "Owner": vm.CurrentUser,
          "Orangeflag": vm.Orangeflag,
          "Activity": vm.Activity,
          "Visit": vm.Visit,
          "Account_Name": Accounts,
          "PlannedSalesPlan": vm.PlannedSalesPlan,
          "Purpose_of_Visit_Influencer": vm.PurposeOfVisitInfluencer,
          "Name_of_Factory": vm.NameofFactory,
          "Complaint_ID": vm.ComplaintID,
          "Type_of_drive": vm.Typeofdrive,
          "Type_of_activity": vm.Typeofactivity,
          "Opportunity_Name": vm.OpportunityName,
          "Purpose_of_Visit_Factory": vm.PurposeofVisitFactory,
          "No_of_Attendants": vm.NoofAttendants,
          "Location": vm.Location,
          "Description": vm.Description,
          "Mode": vm.Mode,
          "Trainingtype": vm.Trainingtype,
          "Account_Name_for_Others": vm.AccountNameForOthers,
          "Type_of_Event": vm.TypeOfEvent,
          "Remarks": vm.Remarks,
          "Meeting_Type": vm.MeetingType,
          "Meet": vm.Meet,
          "Influencer_Type": vm.InfluencerType,
          "BU": vm.BU,
          "Region": vm.Region,
          "Type_of_Sitevisit": vm.typeofsitevisit
        }),
      };
      console.log(vm.Weeknumber)
      console.log("[BeatPlan] Save - req_data being sent to " + func_name + ":", req_data.arguments);
      await ZOHO.CRM.FUNCTIONS.execute(func_name, req_data)
        .then(async function (data) {
          console.log(data)
          arr = JSON.parse(data.details.output);
          console.log(arr);
          arr.forEach(async element => {

            if (element.LeaveWFH == true) {
              console.log(vm.StartDate)
              console.log(vm.CurrentUser);

              console.log(leavedateformat);

              var func_name = "esbs_beatplandeleteeventsonleave";
              var req_data = {
                "arguments": JSON.stringify({
                  "Owner": vm.CurrentUser,
                  "Date": leavedateformat,
                  "Meeting_Type": vm.MeetingType,
                })
              };
              await ZOHO.CRM.FUNCTIONS.execute(func_name, req_data)
                .then(async function (data) {
                  console.log(data)


                  if (data.details.output != "Adhoc") {
                    $('#calendar').fullCalendar('removeEvents');
                    leaveflag = 1;
                    vm.prefill();
                  }
                })
            }

            console.log(element);
            vm.ZohoBeatPlanId = element.BeatPlanid
            console.log(element.Account);
            vm.ZohoAcc = element.Account

            var eventData;


            if (vm.Activity == "Category Visit") {
              vm.Colour = "#a3d9ff"
            } else if (vm.Activity == "Prospect Visit") {
              vm.Colour = "#ff9966"
            } else if (vm.Activity == "On-Going Project Review") {
              vm.Colour = "#ffb84d"
            } else if (vm.Activity == "Techno-Commercial Meet") {
              vm.Colour = "#b399ff"
            } else if (vm.Activity == "Finalization") {
              vm.Colour = "#66cc99"
            } else if (vm.Activity == "Pehchan Training" || vm.Activity == "Training") {
              vm.Colour = "#99ccff"
            } else if (vm.Activity == "Kaushal Training") {
              vm.Colour = "#6666ff"
            } else if (vm.Activity == "Influencer Visit") {
              vm.Colour = "#9fdfbf"
            } else if (vm.Activity == "Factory or Depot Visit") {
              vm.Colour = "#669999"
            } else if (vm.Activity == "IHP") {
              vm.Colour = "#999966"
            } else if (vm.Activity == "Site Visit") {
              vm.Colour = "#cc9900"
            } else if (vm.Activity == "Strategic Drive") {
              vm.Colour = "#cccc00"
            } else if (vm.Activity == "Complaints Redressal") {
              vm.Colour = "#cc2900"
            } else if (vm.Activity == "WFH") {
              vm.Colour = "#3cb44b"
            } else if (vm.Activity == "Leave") {
              vm.Colour = "#666699"
            } else if (vm.Activity == "Fabricator Meet") {
              vm.Colour = "#900C3F"
            } else if (vm.Activity == "Events") {
              vm.Colour = "#581845"
            } else if (vm.Activity == "MIS/ Review/ Meet") {
              vm.Colour = "#FF5733"
            } else if (vm.Activity == "Project Hunting/ Follow Up" || vm.Activity == "Scouting/Follow-up") {
              vm.Colour = "#FF7133"
            } else if (vm.Activity == "Others") {
              vm.Colour = "#313949"
            }


            if (vm.Activity == "Strategic Drive") {
              title = vm.Typeofdrive;
            } else if (vm.Activity == "Factory or Depot Visit") {

              title = vm.NameofFactory.AccPicklistName;
            } else if (vm.Activity == "Others") {
              if (vm.AccountNameForOthers == null || vm.AccountNameForOthers == "") {
                title = vm.Activity;
              } else {
                title = vm.AccountNameForOthers;
              }
            } else if (vm.ZohoAcc == null || vm.ZohoAcc == "") {
              title = vm.Activity;
            } else {
              title = vm.ZohoAcc.Account_Name;
              console.log(vm.ZohoAcc.Account_Name)
            }
            let factname
            if (vm.NameofFactory) {
              factname = vm.NameofFactory.AccPicklistName
            } else {
              factname = vm.NameofFactory
            }

            if (leaveflag == 0) {
              eventData = {
                start: vm.StartDate,
                end: vm.EndDate,
                activity: vm.Activity,
                title: title,
                Visit: vm.Visit,
                picked: vm.picked,
                BeatPlanId: vm.ZohoBeatPlanId,
                AccountId: vm.ZohoAcc,
                PlannedSalesPlan: vm.PlannedSalesPlan,
                Purpose_of_Visit_Influencer: vm.PurposeOfVisitInfluencer,
                Name_of_Factory: factname,
                Complaint_ID: vm.ComplaintID,
                Type_of_drive: vm.Typeofdrive,
                Type_of_activity: vm.Typeofactivity,
                Opportunity_Name: vm.OpportunityName,
                Purpose_of_Visit_Factory: vm.PurposeofVisitFactory,
                No_of_Attendants: vm.NoofAttendants,
                Location: vm.Location,
                Trainingtype: vm.Trainingtype,
                Account_Name_for_Others: vm.AccountNameForOthers,
                Description: vm.Description,
                Mode: vm.Mode,
                Remarks: vm.Remarks,
                Type_of_Event: vm.TypeOfEvent,
                color: vm.Colour,
                approve: "No",
                Orangeflag: vm.Orangeflag,
                Meeting_Type: vm.MeetingType,
                Meet: vm.Meet,
                Influencer_Type: vm.InfluencerType,
                Region: vm.Region,
                typeofsitevisit: vm.typeofsitevisit,



                // rendering: 'background'

              };
              $("#calendar").fullCalendar("renderEvent", eventData, true); // stick? = true
            }
          });
          $("#calendar").fullCalendar("unselect");

        })
      setTimeout(() => {
        vm.showload = false;
      }, 1000);
    },
    async removeEvent() {
      let event = vm.calEvent

      console.log(event.start._i)

      let index = (vm.leavewfhlist).indexOf(event.start._i);
      console.log(index);
      (vm.leavewfhlist).splice(index, 1)
      $("#calendar").fullCalendar("removeEvents", event._id);
      var func_name = "esbs_beatplandeleterecords";
      var req_data = {
        "arguments": JSON.stringify({
          "id": event.BeatPlanId,
        }),
      };

      await ZOHO.CRM.FUNCTIONS.execute(func_name, req_data)
        .then(function (data) {
          console.log(data);
        })
      vm.showModal = false;
    },
    async editEvent(calEvent) {
      vm.CustomBtn = false;
      console.log(vm.BU)
      console.log(vm.calView)
      console.log(vm.Status)
      vm.showDel = true

      console.log(vm.showDel)
      vm.calEvent = calEvent
      console.log(calEvent)
      if (vm.Status == "Rejected" && vm.Plan == "My Plan") {
        vm.validated = false
      } else {
        vm.validated = true
      }
      console.log(vm.Status)
      console.log(vm.Plan)
      if (((vm.Status == "In Draft" || vm.Status == "Rejected") && (vm.Plan == "My Plan")) || ((vm.Status == "Pending for Approval") && (vm.Plan == "My Approval"))) {
        vm.updatebutton = true
      } else {
        vm.updatebutton = false
      }
      vm.updatebutton1 = true
      vm.savebutton = false,
        vm.StartDate = null;
      vm.Activity = null;
      vm.Visit = null;
      vm.Remarks = null;
      vm.MeetingType = null;
      vm.Description = null;
      vm.Contacts = null;
      vm.Distributor = null,
        vm.Dealer = null;
      vm.Stockist = null;
      vm.SubDealerRetailer = null;
      vm.DirectCustomer = null;
      vm.ECPContractor = null;
      vm.ArchitectConsultant = null;
      vm.OtherPartner = null;
      vm.Influencers = null;
      vm.ZohoBeatPlanId = null;
      vm.Redflag = null;
      vm.Orangeflag = null;
      vm.Meet = null;
      vm.InfluencerType = null;
      vm.Location = null;
      vm.Description = null;
      vm.Mode = null;
      vm.TypeOfEvent = null;
      vm.Trainingtype = null;
      vm.AccountNameForOthers = null;


      vm.Activity = calEvent.activity



      if (calEvent.picked != null) {
        vm.picked = calEvent.picked
      }
      console.log(calEvent.AccountId);
      setTimeout(() => {
        vm.MeetingType = calEvent.Meeting_Type
        vm.Visit = calEvent.Visit
        vm.Redflag = calEvent.Redflag
        vm.Remarks = calEvent.Remarks
        vm.PlannedSalesPlan = calEvent.PlannedSalesPlan
        vm.PurposeOfVisitInfluencer = calEvent.Purpose_of_Visit_Influencer
        let factname = calEvent.Name_of_Factory
        vm.NameofFactory = factname
        vm.ComplaintID = calEvent.Complaint_ID
        vm.Typeofdrive = calEvent.Type_of_drive
        vm.Typeofactivity = calEvent.Type_of_activity
        vm.OpportunityName = calEvent.Opportunity_Name
        vm.PurposeofVisitFactory = calEvent.Purpose_of_Visit_Factory
        vm.NoofAttendants = calEvent.No_of_Attendants
        vm.Remarks = calEvent.Remarks
        vm.Approvercomments = calEvent.Approver_Comments
        vm.Location = calEvent.Location
        vm.Description = calEvent.Description
        vm.Mode = calEvent.Mode
        vm.TypeOfEvent = calEvent.Type_of_Event
        vm.Meet = calEvent.Meet
        vm.InfluencerType = calEvent.Influencer_Type
        vm.showModal = true;
        vm.Trainingtype = calEvent.Trainingtype
        vm.AccountNameForOthers = calEvent.Account_Name_for_Others


        Accounts = calEvent.AccountId;
        if (vm.Activity == "Category Visit" || vm.Activity == "Prospect Visit" || vm.Activity == "On-Going Project Review" || vm.Activity == "Techno-Commercial Meet" || vm.Activity == "Finalization" || vm.Activity == "Pehchan Training" || vm.Activity == "Kaushal Training" || vm.Activity == "Training" || vm.Activity == "Fabricator Meet") {
          if (vm.Visit == "Distributor") {
            vm.Distributor = Accounts
          } else if (vm.Visit == "Dealer") {
            vm.Dealer = Accounts
          } else if (vm.Visit == "Stockist") {
            vm.Stockist = Accounts
          } else if (vm.Visit == "Sub Dealer/Retailer") {
            vm.SubDealerRetailer = Accounts
          } else if (vm.Visit == "Direct Customer") {
            vm.DirectCustomer = Accounts
          } else if (vm.Visit == "EPC Contractor") {
            vm.ECPContractor = Accounts
          } else if (vm.Visit == "Architect/Consultant") {
            vm.ArchitectConsultant = Accounts
          } else if (vm.isOtherPartner(vm.Visit)) {
            vm.OtherPartner = Accounts
          }
        } else if (vm.Activity == "Influencer Visit") {
          vm.NameeofInfluencer = Accounts
        } else if (vm.Activity == "IHP") {
          vm.NameofKeyaccountIHP = Accounts
        } else if (vm.Activity == "Site Visit") {
          vm.NameofKeyaccountSite = Accounts
        } else if (vm.Activity == "Complaints Redressal") {
          vm.NameofAccountComplaints = Accounts
        } else if (vm.Activity == "Factory or Depot Visit") {
          vm.NameofFactory = { "AccPicklistName": calEvent.Name_of_Factory, "name": calEvent.Name_of_Factory }
        }

      }, 500);

      vm.Colour = calEvent.color
      vm.ZohoBeatPlanId = calEvent.BeatPlanId
      vm.calEvent = calEvent


    },
    async updateaction(calEvent) {
      vm.showModal = false
      console.log('in updateaction')

      calEvent.BeatPlanId = vm.ZohoBeatPlanId
      calEvent.Redflag = vm.Redflag
      calEvent.Orangeflag = vm.Orangeflag
      calEvent.Remarks = vm.Remarks
      calEvent.PlannedSalesPlan = vm.PlannedSalesPlan
      calEvent.Purpose_of_Visit_Influencer = vm.PurposeOfVisitInfluencer
      calEvent.Name_of_Factory = vm.NameofFactory
      calEvent.Type_of_drive = vm.Typeofdrive
      calEvent.Type_of_activity = vm.Typeofactivity
      calEvent.Purpose_of_Visit_Factory = vm.PurposeofVisitFactory
      calEvent.No_of_Attendants = vm.NoofAttendants
      calEvent.Approver_Comments = vm.Approvercomments
      calEvent.Meet = vm.Meet
      calEvent.Influencer_Type = vm.InfluencerType
      calEvent.Location = vm.Location
      calEvent.Description = vm.Description
      calEvent.Mode = vm.Mode
      calEvent.Type_of_Event = vm.TypeOfEvent
      calEvent.Trainingtype = vm.Trainingtype
      calEvent.Account_Name_for_Others = vm.AccountNameForOthers
      calEvent.typeofsitevisit = vm.typeofsitevisit




      if (vm.Status == "Rejected" && vm.Plan == "My Plan") {
        vm.Orangeflag = true
        calEvent.Orangeflag = vm.Orangeflag
      } else {
        vm.Orangeflag = false
        calEvent.Orangeflag = vm.Orangeflag
      }

      let factoryname = vm.NameofFactory;
      if (factoryname != null && typeof factoryname == "object") {
        factoryname = factoryname.AccPicklistName;
      }
      var func_name = "esbs_beatplanupdaterecord";
      var req_data = {
        "arguments": JSON.stringify({
          "Beatplanid": calEvent.BeatPlanId,
          "Activity": vm.Activity,
          "Redflag": vm.Redflag,
          "Orangeflag": vm.Orangeflag,
          "PlannedSalesPlan": vm.PlannedSalesPlan,
          "Purpose_of_Visit_Influencer": vm.PurposeOfVisitInfluencer,
          "Name_of_Factory": factoryname,
          "Type_of_drive": vm.Typeofdrive,
          "Type_of_activity": vm.Typeofactivity,
          "Purpose_of_Visit_Factory": vm.PurposeofVisitFactory,
          "No_of_Attendants": vm.NoofAttendants,
          "Approver_Comments": vm.Approvercomments,
          "Meet": vm.Meet,
          "Influencer_Type": vm.InfluencerType,
          "Remarks": vm.Remarks,
          "Trainingtype": vm.Trainingtype,
          "Account_Name_for_Others": vm.AccountNameForOthers,
          "Location": vm.Location,
          "Description": vm.Description,
          "Mode": vm.Mode,
          "Type_of_Event": vm.TypeOfEvent,
          "Type_of_Sitevisit": vm.typeofsitevisit
        }),
      };
      console.log("[BeatPlan] Update - Activity=", vm.Activity, "Redflag=", vm.Redflag, "payload=", req_data.arguments);

      await ZOHO.CRM.FUNCTIONS.execute(func_name, req_data)
        .then(function (data) {
          console.log("[BeatPlan] Update - response:", data, "output=", data.details.output);

        })
      if (vm.Activity == "Others") {
        if (vm.AccountNameForOthers == null || vm.AccountNameForOthers == "") {
          calEvent.title = vm.Activity
        } else {
          calEvent.title = vm.AccountNameForOthers
        }
      }
      $("#calendar").fullCalendar("updateEvent", calEvent);
    },
    async reSubmitPlanApproval() {

      Swal.fire({
        title: '',
        text: "Do you want to resubmit the Beat Plan?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes'
      }).then(async (result) => {
        if (result.isConfirmed) {


          vm.showload = true;
          var date = $("#calendar").fullCalendar('getDate');
          curmonth = date._d.toString();
          monthyear = curmonth.split(" ");
          console.log(monthyear);
          month = monthyear[1];
          year = monthyear[3];
          if (month == "Jan") {
            month = "January"
          } else if (month == "Feb") {
            month = "February"
          } else if (month == "Mar") {
            month = "March"
          } else if (month == "Apr") {
            month = "April"
          } else if (month == "May") {
            month = "May"
          } else if (month == "Jun") {
            month = "June"
          } else if (month == "Jul") {
            month = "July"
          } else if (month == "Aug") {
            month = "August"
          } else if (month == "Sep") {
            month = "September"
          } else if (month == "Oct") {
            month = "October"
          } else if (month == "Nov") {
            month = "November"
          } else if (month == "Dec") {
            month = "December"
          }

          // var conn_name = "modulesall";
          var today = new Date();
          var dd = String(today.getDate()).padStart(2, '0');
          var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
          var yyyy = today.getFullYear();
          today = yyyy + '-' + mm + '-' + dd;
          var func_name = "esbs_planresubmit";
          var req_data = {
            "arguments": JSON.stringify({
              "Month": month,
              "Year": year,
              "Week": vm.Weeknumber,
              "BU": vm.BU,
              "Plan_Range": vm.Planrange,
              "Status": "Pending for Approval",
              "Date": today,
              "Owner": vm.CurrentUser
            })
          };
          console.log(req_data.arguments)
          await ZOHO.CRM.FUNCTIONS.execute(func_name, req_data)
            .then(async function (data) {
              console.log(data)
              if (data.details.output == "Success") {
                vm.Status = "Pending for Approval"
                $('#calendar').fullCalendar('removeEvents');
                vm.prefill();

              }

            })
          setTimeout(() => {
            vm.showload = false
          }, 2000);

        }
      })

    },
    async createPlanApproval() {

      var date = $("#calendar").fullCalendar('getDate');
      curmonth = date._d.toString();
      monthyear = curmonth.split(" ");
      month = monthyear[1];
      year = monthyear[3];
      if (month == "Jan") {
        month = "January"
      } else if (month == "Feb") {
        month = "February"
      } else if (month == "Mar") {
        month = "March"
      } else if (month == "Apr") {
        month = "April"
      } else if (month == "May") {
        month = "May"
      } else if (month == "Jun") {
        month = "June"
      } else if (month == "Jul") {
        month = "July"
      } else if (month == "Aug") {
        month = "August"
      } else if (month == "Sep") {
        month = "September"
      } else if (month == "Oct") {
        month = "October"
      } else if (month == "Nov") {
        month = "November"
      } else if (month == "Dec") {
        month = "December"
      }
      let conn_name = "modulesall"
      let pageNO = 0;

      if (vm.BU == "BP") {
        var req_data = {
          "parameters": { "select_query": "SELECT Name From Beat_Plan Where (((Year=" + year + ") and Week	= '" + vm.Weeknumber + "'  )and (Owner=" + vm.CurrentUser + "  and Meeting_Type	='Regular' )) LIMIT " + pageNO + ",200" },
          "method": "POST",
          "url": "https://www.zohoapis.in/crm/v5/coql"
        }

      } else if (vm.BU == "Roofing") {
        
        var req_data = {
          "parameters": { "select_query": "SELECT Name From Beat_Plan Where (((Month=" + month + " and Year=" + year + ") and (Owner=" + vm.CurrentUser + " and Meeting_Type	='Regular' ))) and Plan_Range= '" + vm.Planrange + "'  LIMIT " + pageNO + ",200" },
          "method": "POST",
          "url": "https://www.zohoapis.in/crm/v5/coql"
        }


        
      }

      await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
        .then(async function (data) {

          console.log(data);
          if (data.details.statusMessage != "") {
            Swal.fire({
              title: '',
              text: "Do you want to submit the beat for approval?",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes'
            }).then(async (result) => {
              if (result.isConfirmed) {
                vm.showload = true;
                var date = $("#calendar").fullCalendar('getDate');
                curmonth = date._d.toString();
                monthyear = curmonth.split(" ");
                console.log(monthyear);
                month = monthyear[1];
                year = monthyear[3];
                if (month == "Jan") {
                  month = "January"
                } else if (month == "Feb") {
                  month = "February"
                } else if (month == "Mar") {
                  month = "March"
                } else if (month == "Apr") {
                  month = "April"
                } else if (month == "May") {
                  month = "May"
                } else if (month == "Jun") {
                  month = "June"
                } else if (month == "Jul") {
                  month = "July"
                } else if (month == "Aug") {
                  month = "August"
                } else if (month == "Sep") {
                  month = "September"
                } else if (month == "Oct") {
                  month = "October"
                } else if (month == "Nov") {
                  month = "November"
                } else if (month == "Dec") {
                  month = "December"
                }

                // var conn_name = "modulesall";
                var today = new Date();
                var dd = String(today.getDate()).padStart(2, '0');
                var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
                var yyyy = today.getFullYear();
                today = yyyy + '-' + mm + '-' + dd;
                var func_name = "planapprovalcreate1";
                // console.log(vm.Planrange)
                var req_data = {
                  "arguments": JSON.stringify({
                    "Month": month,
                    "Year": year,
                    "Week": vm.Weeknumber,
                    "BU": vm.BU,
                    "Plan_Range": vm.Planrange,
                    "Status": "Pending for Approval",
                    "Date": today,
                    "Owner": vm.CurrentUser
                  })
                };
                // console.log(req_data.arguments)
                await ZOHO.CRM.FUNCTIONS.execute(func_name, req_data)
                  .then(async function (data) {
                    console.log(data)
                    if (data.details.output == "Success") {
                      vm.Status = "Pending for Approval"
                    }
                  })
                $('#calendar').fullCalendar('removeEvents');
                vm.prefill();
                setTimeout(() => {
                  vm.showload = false;
                }, 2000);
              }
            })
          } else {
            swal("Permission Denied!", "Add atleast an Event to Submit", "error");
          }


        })









    },
    async prefill() {
      vm.Holidayevents = [];
      console.log("in the prefill")
      vm.leavewfhlist = []
      var date = $("#calendar").fullCalendar('getDate');
      curmonth = date._d.toString();
      monthyear = curmonth.split(" ");
      month = monthyear[1];
      year = monthyear[3];
      if (month == "Jan") {
        month = "January"
      } else if (month == "Feb") {
        month = "February"
      } else if (month == "Mar") {
        month = "March"
      } else if (month == "Apr") {
        month = "April"
      } else if (month == "May") {
        month = "May"
      } else if (month == "Jun") {
        month = "June"
      } else if (month == "Jul") {
        month = "July"
      } else if (month == "Aug") {
        month = "August"
      } else if (month == "Sep") {
        month = "September"
      } else if (month == "Oct") {
        month = "October"
      } else if (month == "Nov") {
        month = "November"
      } else if (month == "Dec") {
        month = "December"
      }
      var flag = 1;
      conn_name = "modulesall"
      pageNO = 0;

      var req_data = {
        "parameters": { "select_query": "SELECT Name,Status From Plan_Approval where ((Month=" + month + " and Year=" + year + ") and Plan_Range= '" + vm.Planrange + "'  )and Owner=" + vm.CurrentUser },
        "method": "POST",
        "url": "https://www.zohoapis.in/crm/v5/coql"
      }
      if (vm.BU == "BP") {

        let view = $('#calendar').fullCalendar('getView').name
        if (view == "month") {
          var req_data = {
            "parameters": { "select_query": "SELECT Name,Status From Plan_Approval where (Month=" + month + " and Year=" + year + ") and Owner=" + vm.CurrentUser },
            "method": "POST",
            "url": "https://www.zohoapis.in/crm/v5/coql"
          }
        } else if (view == "agendaWeek") {
          var req_data = {
            "parameters": { "select_query": "SELECT Name,Status From Plan_Approval where (Week=" + vm.Weeknumber + " and Year=" + year + ") and Owner=" + vm.CurrentUser },
            "method": "POST",
            "url": "https://www.zohoapis.in/crm/v5/coql"
          }
        }

      }
      await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
        .then(async function (data) {
          console.log(data)
          if (data.details.statusMessage != "") {
            vm.PlanApprovalId = data.details.statusMessage.data[0].id
            vm.Status = data.details.statusMessage.data[0].Status
          } else {
            if (vm.rejflag == 0) {
              vm.Status = "In Draft";
            } else {
              vm.rejflag = 0;
            }
          }
        })

      while (flag == 1) {
        if (vm.BU == "Roofing") {
          var req_data = {
            "parameters": { "select_query": "SELECT Name,Meeting_Type,Approver_Comments,Redflag,Orangeflag,Date,Activity,Visit,Type,Account_Name,Account_Name.Account_Name,Planned_Sales_Plan_in_MT,Remarks,Purpose_of_Visit_Influencer,Name_of_Factory,Complaint_ID.Complaints_No	,Meet,Influencer_Type,Type_of_drive,Type_of_activity,Opportunity_Name,Opportunity_Name.Deal_Name as 'aqwdqwd',Purpose_of_Visit_Factory,Training_Type,No_of_Attendants,Location,Description,Mode,Type_of_Event,Account_Name_for_Others From Beat_Plan Where (((Month=" + month + " and Year=" + year + ") and Plan_Range= '" + vm.Planrange + "'  )and Owner=" + vm.CurrentUser + ") LIMIT " + pageNO + ",200" },
            "method": "POST",
            "url": "https://www.zohoapis.in/crm/v5/coql"
          }
        }

        if (vm.BU == "BP") {
          let view = $('#calendar').fullCalendar('getView').name

          if (view == "month") {
            var req_data = {
              "parameters": { "select_query": "SELECT Name,Meeting_Type,Approver_Comments,Redflag,Orangeflag,Date,Activity,Visit,Type,Account_Name,Account_Name.Account_Name,Planned_Sales_Plan_in_MT,Remarks,Purpose_of_Visit_Influencer,Name_of_Factory,Complaint_ID.Complaints_No	,Meet,Influencer_Type,Type_of_drive,Type_of_activity,Opportunity_Name,Opportunity_Name.Deal_Name as 'aqwdqwd',Purpose_of_Visit_Factory,Training_Type,No_of_Attendants,Location,Description,Mode,Type_of_Event,Account_Name_for_Others From Beat_Plan Where ((Month=" + month + " and Year=" + year + ")  and Owner=" + vm.CurrentUser + ") LIMIT " + pageNO + ",200" },
              "method": "POST",
              "url": "https://www.zohoapis.in/crm/v5/coql"
            }
          } else if (view == "agendaWeek") {
            var req_data = {
              "parameters": { "select_query": "SELECT Name,Meeting_Type,Approver_Comments,Redflag,Orangeflag,Date,Activity,Visit,Type,Account_Name,Account_Name.Account_Name,Planned_Sales_Plan_in_MT,Remarks,Purpose_of_Visit_Influencer,Name_of_Factory,Complaint_ID.Complaints_No	,Meet,Influencer_Type,Type_of_drive,Type_of_activity,Opportunity_Name,Opportunity_Name.Deal_Name as 'aqwdqwd',Purpose_of_Visit_Factory,Training_Type,No_of_Attendants,Location,Description,Mode,Type_of_Event,Account_Name_for_Others From Beat_Plan Where (((Year=" + year + ") and Week	= '" + vm.Weeknumber + "'  )and Owner=" + vm.CurrentUser + ") LIMIT " + pageNO + ",200" },
              "method": "POST",
              "url": "https://www.zohoapis.in/crm/v5/coql"
            }
          }
        }
        await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
          .then(async function (data) {

            console.log(data);
            vm.testing = data;
            if (data.details.statusMessage != "") {
              if (data.details.statusMessage.info.more_records == false) {
                flag = 0;
              } else {
                pageNO = pageNO + 200
              }
              arr = data.details.statusMessage.data
              // console.log(arr)
              if (arr != undefined) {
                await arr.forEach(async element => {

                  vm.StartDate = element.Date
                  vm.EndDate = element.Date
                  vm.Activity = element.Activity
                  vm.Visit = element.Visit
                  vm.picked = element.Type
                  vm.ZohoBeatPlanId = element.id
                  vm.Redflag = element.Redflag
                  vm.Orangeflag = element.Orangeflag
                  vm.Visit = element.Visit
                  Accounts = element.Account_Name
                  vm.Remarks = element.Remarks
                  vm.MeetingType = element.Meeting_Type
                  vm.PlannedSalesPlan = element.Planned_Sales_Plan_in_MT
                  vm.PurposeOfVisitInfluencer = element.Purpose_of_Visit_Influencer
                  vm.NameofFactory = element.Name_of_Factory
                  vm.ComplaintID = element['Complaint_ID.Complaints_No']
                  vm.Typeofdrive = element.Type_of_drive
                  vm.Typeofactivity = element.Type_of_activity
                  vm.OpportunityName = element['Opportunity_Name.Deal_Name']
                  vm.PurposeofVisitFactory = element.Purpose_of_Visit_Factory
                  vm.NoofAttendants = element.No_of_Attendants
                  vm.Meet = element.Meet
                  vm.InfluencerType = element.Influencer_Type
                  vm.Location = element.Location
                  vm.Description = element.Description
                  vm.Mode = element.Mode
                  vm.Trainingtype = element.Training_Type
                  vm.AccountNameForOthers = element.Account_Name_for_Others
                  vm.TypeOfEvent = element.Type_of_Event


                  if (vm.Activity == "Category Visit" || vm.Activity == "Prospect Visit" || vm.Activity == "On-Going Project Review" || vm.Activity == "Techno-Commercial Meet" || vm.Activity == "Finalization" || vm.Activity == "Pehchan Training" || vm.Activity == "Kaushal Training" || vm.Activity == "Training" || vm.Activity == "Fabricator Meet") {

                    if (vm.Visit == "Distributor") {
                      vm.Distributor = Accounts
                    } else if (vm.Visit == "Dealer") {
                      vm.Dealer = Accounts
                    } else if (vm.Visit == "Stockist") {
                      vm.Stockist = Accounts
                    } else if (vm.Visit == "Direct Customer") {
                      vm.DirectCustomer = Accounts
                    } else if (vm.Visit == "EPC Contractor") {
                      vm.ECPContractor = Accounts
                    } else if (vm.Visit == "Architect/Consultant") {
                      vm.ArchitectConsultant = Accounts
                    } else if (vm.isOtherPartner(vm.Visit)) {
                      vm.OtherPartner = Accounts
                    }
                  } else if (vm.Activity == "Influencer Visit") {
                    vm.NameeofInfluencer = Accounts
                  } else if (vm.Activity == "IHP") {
                    vm.NameofKeyaccountIHP = Accounts
                  } else if (vm.Activity == "Site Visit") {
                    vm.NameofKeyaccountSite = Accounts
                  } else if (vm.Activity == "Complaints Redressal") {
                    vm.NameofAccountComplaints = Accounts
                  }



                  if (vm.Activity == "Category Visit") {
                    vm.Colour = "#a3d9ff"
                  } else if (vm.Activity == "Prospect Visit") {
                    vm.Colour = "#ff9966"
                  } else if (vm.Activity == "On-Going Project Review") {
                    vm.Colour = "#ffb84d"
                  } else if (vm.Activity == "Techno-Commercial Meet") {
                    vm.Colour = "#b399ff"
                  } else if (vm.Activity == "Finalization") {
                    vm.Colour = "#66cc99"
                  } else if (vm.Activity == "Pehchan Training" || vm.Activity == "Training") {
                    vm.Colour = "#99ccff"
                  } else if (vm.Activity == "Kaushal Training") {
                    vm.Colour = "#6666ff"
                  } else if (vm.Activity == "Influencer Visit") {
                    vm.Colour = "#9fdfbf"
                  } else if (vm.Activity == "Factory or Depot Visit") {
                    vm.Colour = "#669999"
                  } else if (vm.Activity == "IHP") {
                    vm.Colour = "#999966"
                  } else if (vm.Activity == "Site Visit") {
                    vm.Colour = "#cc9900"
                  } else if (vm.Activity == "Strategic Drive") {
                    vm.Colour = "#cccc00"
                  } else if (vm.Activity == "Complaints Redressal") {
                    vm.Colour = "#cc2900"
                  } else if (vm.Activity == "WFH") {
                    vm.Colour = "#3cb44b"
                  } else if (vm.Activity == "Leave") {
                    vm.Colour = "#666699"
                  } else if (vm.Activity == "Fabricator Meet") {
                    vm.Colour = "#900C3F"
                  } else if (vm.Activity == "Events") {
                    vm.Colour = "#581845"
                  } else if (vm.Activity == "MIS/ Review/ Meet") {
                    vm.Colour = "#FF5733"
                  } else if (vm.Activity == "Project Hunting/ Follow Up" || vm.Activity == "Scouting/Follow-up") {
                    vm.Colour = "#FF7133"
                  } else if (vm.Activity == "Others") {
                    vm.Colour = "#313949"
                  }


                  if (vm.Activity == "Leave" || vm.Activity == "WFH") {
                    (vm.leavewfhlist).push(vm.StartDate);
                  }
                  let acc = element['Account_Name.Account_Name']
                  if (vm.Activity == "Strategic Drive") {
                    title = vm.Typeofdrive;
                  } else if (vm.Activity == "Factory or Depot Visit") {
                    title = vm.NameofFactory;
                  } else if (vm.Activity == "Others") {
                    if (vm.AccountNameForOthers == null || vm.AccountNameForOthers == "") {
                      title = vm.Activity;
                    } else {
                      title = vm.AccountNameForOthers;
                    }
                  } else if (acc == null || acc == "") {
                    title = vm.Activity;
                  } else {
                    title = acc
                  }

                  var eventData = {
                    start: vm.StartDate,
                    end: vm.StartDate,
                    activity: vm.Activity,
                    title: title,
                    Visit: vm.Visit,
                    picked: vm.picked,
                    BeatPlanId: vm.ZohoBeatPlanId,
                    AccountId: Accounts,
                    PlannedSalesPlan: vm.PlannedSalesPlan,
                    Purpose_of_Visit_Influencer: vm.PurposeOfVisitInfluencer,
                    Name_of_Factory: vm.NameofFactory,
                    Complaint_ID: vm.ComplaintID,
                    Type_of_drive: vm.Typeofdrive,
                    Type_of_activity: vm.Typeofactivity,
                    Opportunity_Name: vm.OpportunityName,
                    Purpose_of_Visit_Factory: vm.PurposeofVisitFactory,
                    No_of_Attendants: vm.NoofAttendants,
                    Location: vm.Location,
                    Description: vm.Description,
                    Mode: vm.Mode,
                    Meet: vm.Meet,
                    Influencer_Type: vm.InfluencerType,
                    Meeting_Type: vm.MeetingType,
                    Type_of_Event: vm.TypeOfEvent,
                    Trainingtype: vm.Trainingtype,
                    Account_Name_for_Others: vm.AccountNameForOthers,
                    color: vm.Colour,
                    Remarks: vm.Remarks,
                    approve: "No",
                    Orangeflag: vm.Orangeflag,
                    Redflag: element.Redflag,
                    Approver_Comments: element.Approver_Comments
                  };

                  if (element.Account_Name != null) {
                    vm.ZohoAcc = {
                      "id": element.Account_Name.id,
                      "Account_Name": element['Account_Name.Account_Name'],
                      "AccPicklistName": element['Account_Name.Account_Name'] + " / " + element.Account_Name.id
                    }
                    eventData["AccountId"] = vm.ZohoAcc
                  }

                  $("#calendar").fullCalendar("renderEvent", eventData, true); // stick? = true
                })
              }
            } else {
              flag = 0;
            }
          });
      }
      //holiday calendar
      if (vm.userstate) {

        var date = $("#calendar").fullCalendar('getDate');
        // alert("The current date of the calendar is " + date.toISOString());
        console.log(date._d)

        curmonth = date._d.toString();
        monthyear = curmonth.split(" ");
        month = monthyear[1];
        year = monthyear[3];
        if (month == "Jan") {
          month = "January"
        } else if (month == "Feb") {
          month = "February"
        } else if (month == "Mar") {
          month = "March"
        } else if (month == "Apr") {
          month = "April"
        } else if (month == "May") {
          month = "May"
        } else if (month == "Jun") {
          month = "June"
        } else if (month == "Jul") {
          month = "July"
        } else if (month == "Aug") {
          month = "August"
        } else if (month == "Sep") {
          month = "September"
        } else if (month == "Oct") {
          month = "October"
        } else if (month == "Nov") {
          month = "November"
        } else if (month == "Dec") {
          month = "December"
        }


        // var req_data = {
        //   "parameters": { "select_query": "SELECT Name,States,Date From Holiday_Master where (((States like '%"+vm.userstate +"%') and (Month='"+month +"')and Year ='"+year +"') limit 0,200" },
        //   "method": "POST",
        //   "url": "https://www.zohoapis.in/crm/v5/coql"
        // }


        // if(vm.BU == "BP"){
        var req_data = {
          "parameters": { "select_query": "SELECT Name,States,Date From Holiday_Master where (Month='" + month + "')and (Year ='" + year + "') limit 0,200" },
          "method": "POST",
          "url": "https://www.zohoapis.in/crm/v5/coql"
        }


        // }else if(vm.BU == "Roofing"){
        //   var req_data = {
        //     "parameters": { "select_query": "SELECT Name,States,Date From Holiday_Master where ((((States like '%"+vm.userstate +"%') and Month='"+month +"')and Year ='"+year +"')and Range='"+ vm.Planrange+"') limit 0,200" },
        //     "method": "POST",
        //     "url": "https://www.zohoapis.in/crm/v4/coql"
        //   }

        // }

        await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
          .then(async function (data) {
            console.log(data)
            if (data.details.statusMessage) {
              console.log(data.details.statusMessage.data)
              let arr1 = data.details.statusMessage.data;
              await arr1.forEach(async element => {
                vm.Holidayevents.push(element)
              });
            }
            console.log(vm.Holidayevents)
          })
      }
      if (vm.Holidayevents) {

        vm.Holidayevents.forEach(element => {
          console.log(element)

          var eventData = {
            start: element.Date,
            end: element.Date,
            title: element.Name,
            rendering: 'background',
            color: "#90EE90"
          };

          $("#calendar").fullCalendar("renderEvent", eventData, false);
        });
      }


    },
    async inputdrive() {
      // console.log("ins")
      vm.Region = null;
      if (vm.Typeofdrive == "Treasure hunt") {
        let i = 0
        let flag = 1
        // while (flag == 1) {
        var req_data = {
          "parameters": { "select_query": "SELECT District from Location_Master where Profile=BP group by District LIMIT " + i + ",200" },
          "method": "POST",
          "url": "https://www.zohoapis.in/crm/v5/coql"
        }

        await ZOHO.CRM.CONNECTION.invoke("modulesall", req_data)
          .then(async function (data) {
            console.log(data);
            console.log(data.details.statusMessage.info.more_records);
            // if (data.details.statusMessage.info.more_records == false) {
            //   flag = 0;
            // } else {
            //   i++;
            // }

            let arr1 = data.details.statusMessage.data

            await arr1.forEach(async element => {
              vm.Regionoptions.push(element.District)
            })


          })
      }
      // }
    },
    async searchregion(moduleName, Type, search, loading) {
      console.log(search);
      if (search.length > 2) {
        vm.Regionoptions = []
        var req_data = {
          "parameters": { "select_query": "SELECT District from Location_Master where (District like '" + search + "%' and Profile=BP) group by District LIMIT 0,200" },
          "method": "POST",
          "url": "https://www.zohoapis.in/crm/v5/coql"
        }

        await ZOHO.CRM.CONNECTION.invoke("modulesall", req_data)
          .then(async function (data) {
            console.log(data);
            console.log(data.details.statusMessage.info.more_records);

            let arr1 = data.details.statusMessage.data

            await arr1.forEach(async element => {
              vm.Regionoptions.push(element.District)
            })


          })
      }

    },
    async ApproveStatus() {

      Swal.fire({
        title: '',
        text: "Do you want to Approve the Beat Plan?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes'
      }).then(async (result) => {
        if (result.isConfirmed) {
          vm.showload = true

          let func_name = "esbs_planapprovalapprovestatus";
          let req_data1 = {
            "arguments": JSON.stringify({
              "PlanAppID": vm.PlanApprovalId
            })
          };
          await ZOHO.CRM.FUNCTIONS.execute(func_name, req_data1)
            .then(async function (data) {
              console.log(data)

              vm.Status = data.details.output;
              // setTimeout(() => {
              vm.showload = false
              // }, 2000);
            })

          // https://sandbox.zohoapis.in/crm/v2/functions/PlanApprovalApproveStatus/actions/execute?auth_type=oauth


          //       var req_data = {
          //         "parameters": { "data": [{ "Status": "Approved" }] },
          //         "method": "PUT",
          //         "url": "https://www.zohoapis.in/crm/v5/Plan_Approval/" + vm.PlanApprovalId
          //       }
          //       await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
          //         .then(async function (data) {
          //           console.log(data)

          //           let flag = 1;
          //           var i = 0
          //           while (flag == 1) {
          //             await ZOHO.CRM.API.getRelatedRecords({ Entity: "Plan_Approval", RecordID: vm.PendingApproval.id, RelatedList: "Beat_Plan", page: i, per_page: 200 })
          //               .then(async function (data) {

          //                 if (data.status != 204) {
          //                   console.log(data)
          //                   if (data.info.more_records == false) {
          //                     flag = 0
          //                   } else {
          //                     i++;
          //                   }
          //                   arr1 = data.data

          //                   arr1.forEach(async element => {
          //                     console.log(element);
          //                     let title;
          //                     if(element.Account_Name){
          // title = element.Activity + " - "+element.Account_Name.name 
          //                     }else{
          //                       title =element.Activity
          //                     }

          //                     // var mydate = new Date(element.Date+"T00:00:00+05:30");
          //                     // console.log();
          //                     var recordData = {
          //                       "What_Id": element.id,
          //                       "Owner": element.Owner.id,
          //                       "$se_module": "Beat_Plan",
          //                       "$send_notification":false,
          //                       "Event_Title": title,
          //                       "All_day": true,
          //                       "Start_DateTime": element.Date + "T00:00:00+05:30",
          //                       "End_DateTime": element.Date + "T00:00:00+05:30",
          //                     }
          //                     await ZOHO.CRM.API.insertRecord({ Entity: "Events", APIData: recordData }).then(function (data) {
          //                       console.log(data);
          //                     });
          //                   });
          //                 } else {
          //                   flag = 0;
          //                 }
          //               })
          //           }
          //           vm.Status = "Approved";
          //           setTimeout(() => {
          //             vm.showload=false  
          //           }, 2000);

          //         })


        }
      })



    },
    async RejectStatus() {

      Swal.fire({
        title: '',
        text: "Do you want to Reject the Beat Plan?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes'
      }).then(async (result) => {
        if (result.isConfirmed) {

          await ZOHO.CRM.API.getRelatedRecords({ Entity: "Plan_Approval", RecordID: vm.PlanApprovalId, RelatedList: "Beat_Plan", page: 1, per_page: 200 })
            .then(async function (data) {
              console.log(data);
              let flag = 1;
              while (flag == 1) {

                if (data.data) {
                  if (data.info.more_records == false) {

                    flag = 0;
                  } else {
                    pageNO = pageNO + 200
                  }
                  arr = data.data
                  console.log(arr)

                  let flag1 = true;
                  arr.forEach(async element => {
                    console.log(element)
                    console.log(element.Redflag);
                    console.log(flag1)
                    if (element.Redflag == true && flag1 == true) {
                      flag1 = false;
                    }

                  });

                  if (flag1 == true) {
                    swal("Permission Denied!", "Reject atleast one event", "error");
                  } else {

                    var req_data = {
                      "parameters": { "data": [{ "Status": "Rejected" }] },
                      "method": "PUT",
                      "url": "https://www.zohoapis.in/crm/v5/Plan_Approval/" + vm.PlanApprovalId
                    }
                    await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
                      .then(async function (data) {
                        console.log(data)
                        vm.Status = "Rejected"
                      });


                    let flag2 = false;
                    arr.forEach(async element => {
                      if (element.Orangeflag == true) {
                        console.log(element)
                        var req_data = {
                          "parameters": { "data": [{ "Orangeflag": false }] },
                          "method": "PUT",
                          "url": "https://www.zohoapis.in/crm/v5/Beat_Plan/" + element.id
                        }
                        await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
                          .then(async function (data) {
                            console.log(data)
                          });
                      }
                      flag2 = true;
                    });
                    vm.rejflag = 1;
                    // vm.prefill();
                  }
                } else {
                  flag = 0;
                }
              }
            })

        }
      })
    },
    async prevnextprefill() {

      if (vm.Plan == "My Plan") {
        vm.showload = true;
        setTimeout(() => {
          vm.showload = false;
        }, 2000);
        $('#calendar').fullCalendar('removeEvents');
        vm.prefill();
      } else if (vm.Plan == "My Approval") {

        vm.showload = true;
        setTimeout(() => {
          vm.showload = false;
        }, 200);
        $('#calendar').fullCalendar('removeEvents');
        vm.PendingApproval = null
        vm.PendingApprovalOptions = [];
        vm.CallEvents();
        console.log('in approval')
      }
    },
    rediretrec() {


      window.open(vm.redirurl + vm.ZohoBeatPlanId, "_blank");
      // window.open("https://crmsandbox.zoho.in/crm/everestindsandbox/tab/CustomModule6/"+ vm.ZohoBeatPlanId, "_blank");
    },
    ISO8601_week_no(dt) {
      var tdt = new Date(dt.valueOf());
      var dayn = (dt.getDay() + 6) % 7;
      tdt.setDate(tdt.getDate() - dayn + 3);
      var firstThursday = tdt.valueOf();
      tdt.setMonth(0, 1);
      if (tdt.getDay() !== 4) {
        tdt.setMonth(0, 1 + ((4 - tdt.getDay()) + 7) % 7);
      }
      return 1 + Math.ceil((firstThursday - tdt) / 604800000);
    },
    async Dateinput() {
      // console.log(vm.Datevalue);









    },

  },
});




//ZOHO
ZOHO.embeddedApp.on("PageLoad", async function (data) {

  vm.showload = true
  setTimeout(() => {
    vm.showload = false
  }, 3200);


  let date = new Date()
  let year = date.toLocaleString('default', { year: 'numeric' });
  let month = date.toLocaleString('default', {
    month: '2-digit',
  });
  let day = date.toLocaleString('default', { day: '2-digit' });

  vm.currentday = [year, month, day].join('-');




  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0');
  var yyyy = today.getFullYear();
  today = yyyy + '-' + mm + '-' + dd;
  let dt = new Date(yyyy, mm - 1, dd);
  vm.todayweek = vm.ISO8601_week_no(dt)



  await ZOHO.CRM.CONFIG.getCurrentUser().then(async function (data) {
    console.log("[BeatPlan] getCurrentUser resolved:", data);
    console.log(data.users[0]);
    vm.CurrentUser = data.users[0].id;


    await ZOHO.CRM.API.getRecord({
      Entity: "users", RecordID: vm.CurrentUser
    })
      .then(async function (data) {
        vm.userstate = data.users[0].state
      })





    vm.thisuser = vm.CurrentUser
    vm.role = data.users[0].role.name

    conn_name = "modulesall"
    var req_data = {
      "parameters": { "select_query": "SELECT Name,URL,Firsthalf_Deadline,Secondhalf_Deadline, Super_Approver_Role	,Approver_and_Planner	,Planner From Configurations where Name='Beat Plan Details'  LIMIT 0,200" },
      "method": "POST",
      "url": "https://www.zohoapis.in/crm/v5/coql"
    }

    await ZOHO.CRM.CONNECTION.invoke(conn_name, req_data)
      .then(async function (data) {

        details = data.details.statusMessage.data[0];
        console.log(details)
        vm.redirurl = details.URL
        Planner = (details.Planner).split(",");
        Super_Approver_Role = (details.Super_Approver_Role).split(",");
        Approver_and_Planner = (details.Approver_and_Planner).split(",");
        console.log(Planner);
        console.log(Super_Approver_Role);
        console.log(Approver_and_Planner);
        console.log(vm.role);
        // console.log(vm.Plan);
        if (Planner.includes(vm.role)) {
          vm.showplan = true;
          vm.Plan = "My Plan"
        } else if (Approver_and_Planner.includes(vm.role) || vm.role == "CEO") {
          vm.showplan = false;
          vm.Plan = "My Plan"
        } else if (Super_Approver_Role.includes(vm.role)) {
          vm.showplan = true;
          vm.Plan = "My Approval"
        }

        vm.firsthalf = (details.Firsthalf_Deadline);
        vm.secondhalf = (details.Secondhalf_Deadline);

        console.log("[BeatPlan] role=", vm.role, "Plan=", vm.Plan, "showplan=", vm.showplan);
      })
      .catch(function (err) {
        console.error("[BeatPlan] Configurations COQL query failed - vm.Plan/vm.showplan will stay unset:", err);
      })
  }).catch(function (err) {
    console.error("[BeatPlan] getCurrentUser failed - vm.role/vm.CurrentUser will stay unset:", err);
  });
  await ZOHO.CRM.API.getUser({ ID: vm.CurrentUser })
    .then(function (specificUserdata) {
      console.log("[BeatPlan] getUser resolved, Type(BU)=", specificUserdata.users[0].Type);
      vm.BU = specificUserdata.users[0].Type;
      UserBUType = specificUserdata.users[0].Type;
      console.log("[BeatPlan] UserBUType=", UserBUType);
      if (vm.BU == "PEB") {
        vm.BU = "BP";
      }
      if (vm.BU == "BP") {

        vm.TrainingtypeOptions = ["Kaushal", "Pehchan", "On-site training/OSD"]


        vm.MeetOptions = ["Contractor Meet", "Architect Meet", "Team Meet", "Builder Meet", "Govt Dept meet", "Others"]

        vm.InfluencerOptions = ["Architect", "Interior Designer", "Contractor/Project Associate", "Consultant", "Infra House/EPC Contractor", "End-User", "Project Sale", "Installer", "Govt Dept", "MES"]

        vm.Typeofdriveoptions = ["Commercial", "Consultant Empaneling", "Key Account"],
          vm.TypeOfEventOptions = ["Exhibitions", "Sales conference", "Others"]

        vm.Typeofactivityoptions = ["Shop Day", "Naka Day", "Mandi/Mela", "Mock-up", "Others"]
        vm.ActivityOptions = ["Category Visit", "Prospect Visit", "On-Going Project Review", "Techno-Commercial Meet", "Finalization", "Training", "Influencer Visit", "Factory or Depot Visit", "IHP", "Site Visit", "Strategic Drive", "Complaints Redressal", "Events", "MIS/ Review/ Meet", "Scouting/Follow-up", "Others", "WFH", "Leave"]
        // Project Hunting/ Follow Up removed mail from akanksha nov7 2023

      } else if (vm.BU == "Roofing") {

        vm.TrainingtypeOptions = ["Kaushal", "Pehchan", "On-site training/OSD"]

        vm.MeetOptions = ["Naka Meet", "Contractor Meet", "Architect Meet", "Distributor Meet", "Dealer Meet", "Sub-dealer/retailer meet", "Team Meet", "Builder Meet", "Product Launch Meet", "Govt Dept meet", "Others"]

        vm.InfluencerOptions = ["Installer", "Architect", "Interior Designer", "Consultant", "Builder", "Contractor", "OEM"],

          vm.TypeOfEventOptions = ["Exhibitions", "Sales conference", "Others"]

        vm.Typeofactivityoptions = ["Shop Day", "Mandi/Mela", "Mock-up", "Others"]

        vm.ActivityOptions = ["Category Visit", "Prospect Visit", "On-Going Project Review", "Techno-Commercial Meet", "Finalization", "Training", "Influencer Visit", "Factory or Depot Visit", "Complaints Redressal", "Fabricator Meet", "Events", "MIS/ Review/ Meet", "Scouting/Follow-up", "Others", "WFH", "Leave"]
      }
      console.log("[BeatPlan] PageLoad init complete - BU=", vm.BU, "role=", vm.role, "Plan=", vm.Plan, "showplan=", vm.showplan);
    })
    .catch(function (err) {
      console.error("[BeatPlan] getUser failed - vm.BU will stay null, calendar click will do nothing:", err);
    })
  if (vm.BU == "BP") {
    $('.fc-agendaWeek-button').trigger('click');
  }

})
ZOHO.embeddedApp.init();


//CALENDAR
$(document).ready(function () {

  


  $("#menu").on("click", function () {
    $("#menu").css("opacity", "0");
    $("#lgMenu").addClass("enter");
  });
  $("#exit").on("click", function () {
    $("#lgMenu").removeClass("enter");
    $("#menu").css("opacity", "1");
  });

  $("#calendar").fullCalendar({
    longPressDelay: 0,
    // initialDate: '2020-09-12',
    // can give header like this to give spacxe between buttons "prev,next today" ",agendaWeek,agendaDay,month"",
    // customButtons: {
    //   myCustomButton: {
    //     text: 'Add Event',
    //     click: function () {
    //       if (vm.Plan == "My Plan") {
    //         vm.MeetingType = ""
    //         if (vm.BU == "Roofing" && vm.calView == "month") {
    //           if (vm.Planrange == "" || vm.Planrange ==null) {

    //             swal("Permission Denied!", "Plan Range is Empty!", "error");
    //           }else{
    //             vm.MeetingType = ""
    //             vm.eventdetails("start", "end", "Custombtn");
    //           }             
    //         }
    //         if (vm.BU == "BP" && vm.calView == "agendaWeek") {
            
    //           vm.eventdetails("start", "end", "Custombtn");
    //         }
    //       } else if (vm.Plan == "My Approver") {
    //         swal("Permission Denied!", "Approver cannot create an event!", "error");
    //       } else{
    //         swal("Permission Denied!", "Plan is Empty!", "error");
    //       }

    //     }
    //   }
    // },
    header: {
      left: "agendaWeek,month",//agendaDay
      center: "",//title
      right: "prev,next myCustomButton"
    },
    weekNumberCalculation: "ISO",
    viewRender: function (view) {
      var title = view.title;
      vm.Weekstring = title;
      // console.log(view)
      let view1 = $('#calendar').fullCalendar('getView').name
      vm.calView = view1
      if (view1 == "agendaWeek") {
        vm.Weeknumber = "" + view.intervalStart.week()
        vm.title = title + "  (" + "week " + view.intervalStart.week() + ") "
        vm.IntervalStart=view.intervalStart._d;
        vm.IntervalEnd=view.intervalEnd._d;
      } else {
        vm.Weeknumber = null
        vm.title = title
      }
    },
    // hiddenDays: [ 0 ],
    // weekNumbers:true,
    // weekText:"",
    // weekNumberCalculation:"local",
    firstDay: 1,
    showNonCurrentDates: false,
    fixedWeekCount: true,
    aspectRatio: 1.15,
    defaultView: "month",
    // columnFormat: {
    //   month: 'ddd',
    //   week: 'ddd d/M',
    //   day: 'dddd d/M'
    // },
    navLinks: true, // can click day/week names to navigate views
    selectable: true,
    selectHelper: true,
    editable: false,
    eventLimit: true, // allow "more" link when too many events
    select: function (start, end) {
      // console.log(start,end);
      let view = $('#calendar').fullCalendar('getView').name
      console.log("[BeatPlan] date selected - BU=", vm.BU, "Plan=", vm.Plan, "Status=", vm.Status, "view=", view);
      if (vm.BU != "Roofing" && vm.BU != "BP") {
        console.warn("[BeatPlan] vm.BU is not 'Roofing' or 'BP' - dialog will NOT open. Check PageLoad logs above for getUser/getCurrentUser failures.");
      }
      vm.MeetingType = "Regular"
      if (vm.BU == "Roofing") {
        if (view == "month") {
          // console.log(start._d);
          monthyear = (start._d.toString()).split(" ");
          // console.log(monthyear)
          month = monthyear[1];
          if (month == "Jan") {
            month = "January"
            m = "01";
          } else if (month == "Feb") {
            month = "February"
            m = "02";
          } else if (month == "Mar") {
            month = "March"
            m = "03";
          } else if (month == "Apr") {
            month = "April"
            m = "04";
          } else if (month == "May") {
            month = "May"
            m = "05";
          } else if (month == "Jun") {
            month = "June"
            m = "06"
          } else if (month == "Jul") {
            month = "July"
            m = "07"
          } else if (month == "Aug") {
            month = "August"
            m = "08"
          } else if (month == "Sep") {
            month = "September"
            m = "09"
          } else if (month == "Oct") {
            month = "October"
            m = "10"
          } else if (month == "Nov") {
            month = "November"
            m = "11"
          } else if (month == "Dec") {
            month = "December"
            m = "12"
          }
          year = monthyear[3];
          leavedateformat = year + "-" + m + "-" + monthyear[2];


          if (vm.Plan == "My Approval") {
            // swal("Permission Denied!", "Approver cannot create an event!", "error");
          } else {
            if ((vm.leavewfhlist).includes(leavedateformat)) {
              swal("Permission Denied!", "Selected date contains Leave or WFH event", "error");
            } else if (vm.Status != "In Draft" && vm.Status != "Rejected") {
              // swal("Permission Denied!", "Beat Plan for this half is submitted!", "error");
              if (start.add('days', 1).date() != end.date()) {
                $("#calendar").fullCalendar("unselect");
              } else {
                start.add('days', -1).date()
                var date = new Date(start._d),
                  mnth = ("0" + (date.getMonth() + 1)).slice(-2),
                  day = ("0" + date.getDate()).slice(-2);
                selecteddate = [date.getFullYear(), mnth, day].join("-");

                var today = new Date();
                var dd = String(today.getDate()).padStart(2, '0');
                var mm = String(today.getMonth() + 1).padStart(2, '0');
                var yyyy = today.getFullYear();
                today = yyyy + '-' + mm + '-' + dd;

                if (selecteddate < today) {
                  swal("Permission Denied!", "You are not allowed to select the previous date!", "error");
                } else if (mm == mnth) {
                  if (vm.Planrange == "First Half") {
                    // if (dd < (vm.firsthalf + 1)) {
                    if (day > 0 && day < (vm.secondhalf - 1)) {
                      vm.MeetingType = "Ad hoc"
                      vm.eventdetails(start, end);
                    } else {
                      swal("Permission Denied!", "You are not allowed to add Ad hoc events for this Half", "error");
                    }
                    // } else {
                    //   swal("Permission Denied!", "You are not allowed to add Ad hoc events for this Half", "error");
                    // }
                  } else if (vm.Planrange == "Second Half") {
                    // if (dd < (vm.secondhalf + 1)) {
                    if (day > (vm.secondhalf - 2) && day < 32) {
                      vm.MeetingType = "Ad hoc"
                      vm.eventdetails(start, end);
                    } else {
                      swal("Permission Denied!", "You are not allowed to add Ad hoc events for this Half", "error");
                    }
                    // } else {
                    //   swal("Permission Denied!", "You are not allowed to add events after 17th!", "error");
                    // }
                  }
                } else if (mm != mnth) {
                  if (vm.Planrange == "First Half") {
                    // if (dd < (vm.firsthalf + 1)) {
                    if (day > 0 && day < (vm.secondhalf - 1)) {
                      vm.MeetingType = "Ad hoc"
                      vm.eventdetails(start, end);
                    } else {
                      swal("Permission Denied!", "You are not allowed to add Ad hoc events for this Half", "error");
                    }
                    // } else {
                    //   swal("Permission Denied!", "You are not allowed to add Ad hoc events for this Half", "error");
                    // }
                  } else if (vm.Planrange == "Second Half") {
                    // if (dd < (vm.secondhalf + 1)) {
                    if (day > (vm.secondhalf - 2) && day < 32) {
                      vm.MeetingType = "Ad hoc"
                      vm.eventdetails(start, end);
                    } else {
                      swal("Permission Denied!", "You are not allowed to add Ad hoc events for this Half", "error");
                    }
                    // } else {
                    //   swal("Permission Denied!", "You are not allowed to add events after 17th!", "error");
                    // }
                  }
                  // swal("Permission Denied!", "You are not allowed to add Ad hoc events for this month", "error");
                }
              }
              // 
            } else {
              if (vm.Plan == "" || vm.Plan == null) {
                swal("Permission Denied!", "Plan is empty!", "error");
              }
              else if (vm.Planrange == "" || vm.Planrange == null) {
                swal("Permission Denied!", "Plan range is empty!", "error");
              } else {
                if (start.add('days', 1).date() != end.date()) {
                  $("#calendar").fullCalendar("unselect");
                } else {
                  start.add('days', -1).date()
                  var date = new Date(start._d),
                    mnth = ("0" + (date.getMonth() + 1)).slice(-2),
                    day = ("0" + date.getDate()).slice(-2);
                  selecteddate = [date.getFullYear(), mnth, day].join("-");

                  var today = new Date();
                  var dd = String(today.getDate()).padStart(2, '0');
                  var mm = String(today.getMonth() + 1).padStart(2, '0');
                  var yyyy = today.getFullYear();
                  today = yyyy + '-' + mm + '-' + dd;

                  if (selecteddate < today) {
                    swal("Permission Denied!", "You are not allowed to select the previous date!", "error");
                  } else if (mm == mnth) {
                    if (vm.Planrange == "First Half") {
                      if (dd < (vm.firsthalf + 1)) {
                        if (day > 0 && day < (vm.secondhalf - 1)) {
                          vm.eventdetails(start, end);
                        } else {
                          swal("Permission Denied!", "You are not allowed to add events from Second Half", "error");
                        }
                      } else {
                        // swal("Permission Denied!", "You are not allowed to add events after 2nd!", "error");
                        vm.MeetingType = "Ad hoc"
                        vm.eventdetails(start, end);
                      }
                    } else if (vm.Planrange == "Second Half") {
                      if (dd < (vm.secondhalf + 1)) {
                        if (day > (vm.secondhalf - 2) && day < 32) {
                          vm.eventdetails(start, end);
                        } else {
                          swal("Permission Denied!", "You are not allowed to add events from the First Half", "error");
                        }
                      } else {
                        // swal("Permission Denied!", "You are not allowed to add events after 17th!", "error");
                        vm.MeetingType = "Ad hoc"
                        vm.eventdetails(start, end);
                      }
                    }
                  } else if (mm != mnth) {
                    if (vm.Planrange == "First Half") {
                      if (day < (vm.secondhalf - 1) && day > 0) {
                        vm.eventdetails(start, end);
                      } else {
                        swal("Permission Denied!", "You are not allowed to add events from Second Half", "error");
                      }
                    } else if (vm.Planrange == "Second Half") {
                      if (day < 32 && day > (vm.secondhalf - 2)) {
                        vm.eventdetails(start, end);
                      } else {
                        swal("Permission Denied!", "You are not allowed to add events from First Half", "error");
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      if (vm.BU == "BP") {
        if (view == "agendaWeek") {

          // console.log(start._d);
          monthyear = (start._d.toString()).split(" ");
          // console.log(monthyear)
          month = monthyear[1];
          if (month == "Jan") {
            month = "January"
            m = "01";
          } else if (month == "Feb") {
            month = "February"
            m = "02";
          } else if (month == "Mar") {
            month = "March"
            m = "03";
          } else if (month == "Apr") {
            month = "April"
            m = "04";
          } else if (month == "May") {
            month = "May"
            m = "05";
          } else if (month == "Jun") {
            month = "June"
            m = "06"
          } else if (month == "Jul") {
            month = "July"
            m = "07"
          } else if (month == "Aug") {
            month = "August"
            m = "08"
          } else if (month == "Sep") {
            month = "September"
            m = "09"
          } else if (month == "Oct") {
            month = "October"
            m = "10"
          } else if (month == "Nov") {
            month = "November"
            m = "11"
          } else if (month == "Dec") {
            month = "December"
            m = "12"
          }
          year = monthyear[3];
          leavedateformat = year + "-" + m + "-" + monthyear[2];


          if (vm.Plan == "My Approval") {
            // swal("Permission Denied!", "Approver cannot create an event!", "error");
          } else if (vm.Plan == "My Plan") {
            console.log(vm.Status);
            if ((vm.leavewfhlist).includes(leavedateformat)) {
              swal("Permission Denied!", "Selected date contains Leave or WFH event", "error");
            } else if (vm.Status != "In Draft" && vm.Status != "Rejected") {
              // swal("Permission Denied!", "Beat Plan for this half is submitted!", "error");
              if (start.add('days', 1).date() != end.date()) {
                $("#calendar").fullCalendar("unselect");
              } else {
                start.add('days', -1).date()
                var date = new Date(start._d),

                  mnth = ("0" + (date.getMonth() + 1)).slice(-2),
                  day = ("0" + date.getDate()).slice(-2);
                selecteddate = [date.getFullYear(), mnth, day].join("-");

                var today = new Date();

                let day1 = today.getDay();
                var dd = String(today.getDate()).padStart(2, '0');
                var mm = String(today.getMonth() + 1).padStart(2, '0');
                var yyyy = today.getFullYear();
                today = yyyy + '-' + mm + '-' + dd;




                if (selecteddate < today) {
                  swal("Permission Denied!", "You are not allowed to select the previous date!", "error");
                } else if (vm.todayweek == vm.Weeknumber) {
                  console.log(day1)
                  
                  vm.MeetingType = "Ad hoc"
                  vm.eventdetails(start, end);
                  
                } else if (vm.todayweek != vm.Weeknumber) {
                  vm.MeetingType = "Ad hoc"
                  vm.eventdetails(start, end);
                  // vm.eventdetails(start, end);
                }


              }
              // 
            } else {
              if (vm.Plan == "" || vm.Plan == null) {
                swal("Permission Denied!", "Plan is empty!", "error");
              }
              else {
                if (start.add('days', 1).date() != end.date()) {
                  $("#calendar").fullCalendar("unselect");
                } else {
                  start.add('days', -1).date()
                  var date = new Date(start._d),
                    mnth = ("0" + (date.getMonth() + 1)).slice(-2),
                    day = ("0" + date.getDate()).slice(-2);
                  selecteddate = [date.getFullYear(), mnth, day].join("-");

                  var today = new Date();
                  let day1 = today.getDay();
                  var dd = String(today.getDate()).padStart(2, '0');
                  var mm = String(today.getMonth() + 1).padStart(2, '0');
                  var yyyy = today.getFullYear();
                  today = yyyy + '-' + mm + '-' + dd;

                  // console.log(vm.todayweek);
                  // console.log(vm.Weeknumber);
                  if (selecteddate < today) {
                    swal("Permission Denied!", "You are not allowed to select the previous date!", "error");
                  } else if (vm.todayweek == vm.Weeknumber) {
                    console.log(day1)
                    if (day1 < 2) {
                      vm.eventdetails(start, end);
                    } else {
                      vm.MeetingType = "Ad hoc"
                      vm.eventdetails(start, end);
                    }
                  } else if (vm.todayweek != vm.Weeknumber) {
                    vm.eventdetails(start, end);
                  }

                }
              }
            }
          } else {
            swal("Permission Denied!", "Plan is empty!", "error");
          }
        }
      }


    },
    eventRender: function (event, element) {
      if (event.rendering == 'background') {
        element
          .find(".fc-bgevent").prevObject[0].innerHTML = event.title
      }
      if (event.Redflag == true) {
        element
          .find(".fc-content")
          .prepend("<i class='fas fa-bookmark' style='color: #e92525;'></i>");
      }
      if (event.Redflag == true && vm.Status == "Rejected") {
        element.addClass("rejectedevent");
        if (event.Approver_Comments == null || event.Approver_Comments == "") {
          element.attr("title", "Rejected");
        } else {
          element.attr("title", "Rejected: " + event.Approver_Comments);
        }
      }
      if (event.Orangeflag == true) {
        element
          .find(".fc-content")
          .prepend("<i class='fas fa-bookmark' style='color: orange;'></i>");
      }

      element
        .find(".fc-content");

    },
    eventClick: function (calEvent) {

      vm.showload = true;
      vm.editEvent(calEvent);
      setTimeout(() => {
        vm.showload = false;
      }, 500);
    },


  });

  $('body').on('click', 'button.fc-prev-button', function () {
    let view = $('#calendar').fullCalendar('getView').name
    // console.log(view)
    if (view == "month" || (view == "agendaWeek" && vm.BU == "BP")) {
      vm.showload = true;
      vm.Planrange = "";
      $('#calendar').fullCalendar('removeEvents');
      vm.prevnextprefill();

      setTimeout(() => {
        vm.showload = false
      }, 2000);
    }
  });
  $('body').on('click', 'button.fc-next-button', function () {
    let view = $('#calendar').fullCalendar('getView').name
    // console.log(view)
    if (view == "month" || (view == "agendaWeek" && vm.BU == "BP")) {
      vm.showload = true;
      vm.Planrange = "";
      $('#calendar').fullCalendar('removeEvents');
      vm.prevnextprefill();
      setTimeout(() => {
        vm.showload = false
      }, 2000);
    }

  });
  $('body').on('click', 'button.fc-agendaWeek-button', function () {
    let view = $('#calendar').fullCalendar('getView').name
    // console.log(view)
    if (view == "month" || (view == "agendaWeek" && vm.BU == "BP")) {
      vm.showload = true;
      vm.Planrange = "";
      $('#calendar').fullCalendar('removeEvents');
      vm.prevnextprefill();

      setTimeout(() => {
        vm.showload = false
      }, 2000);
    }
  });
  $('body').on('click', 'button.fc-month-button', function () {
    let view = $('#calendar').fullCalendar('getView').name
    console.log(view)
    if (view == "month" || (view == "agendaWeek" && vm.BU == "BP")) {
      vm.showload = true;
      vm.Planrange = "";
      $('#calendar').fullCalendar('removeEvents');
      vm.prevnextprefill();

      setTimeout(() => {
        vm.showload = false
      }, 2000);
    }

  });

  var element = document.getElementById("Cal");
  element.classList.add("active");

});
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
}
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
}



